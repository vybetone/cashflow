# CashFlow AI - Master Repair & Deployment Guide

## 1. Executive Summary & Root Causes
- **Firebase Configuration**: This source ZIP does not include `app/google-services.json`. The app is configured to fail the build if the required Firebase configuration is missing; restore the correct project-specific file or inject it in CI.
- **Gemini Assistant Error**: Missing/placeholder API keys caused an unhelpful failure message; queries were sent with `?key=` query parameters rather than Google's standard `x-goog-api-key` header; responses did not handle HTTP 400/401/404/429/500 gracefully with credential redaction.
- **CI/CD Pipeline**: GitHub Actions failed during build due to missing secrets pass-through, missing `debug.keystore` fallback, and missing package-validated `google-services.json`.

---

## 2. Completed Fixes

### A. Firebase Integration
- The Gradle setup requires a genuine `app/google-services.json` matching the Firebase project and package. **That file is not present in this ZIP**, so Firebase-dependent builds require the owner to restore it securely.
- Configured `app/build.gradle.kts` with `defaultConfig.applicationId = "com.aistudio.cashflow.a3k9p"`, maintaining `namespace = "com.example"` to ensure zero Kotlin/R-class import breakage.
- Switched `missingGoogleServicesStrategy` from `WARN` to `MissingGoogleServicesStrategy.ERROR` so any invalid/missing Firebase configuration fails fast and loudly.

### B. Gemini API Engine
- Migrated all API calls (`callGeminiVisionApi`, `callGeminiMarketAnalysisApi`, and `chatWithTradingAssistant`) to use the secure HTTP header `x-goog-api-key: <key>` instead of exposing keys in URL parameters.
- Standardized model defaults to `gemini-3.5-flash` with safe fallback logic.
- Built comprehensive HTTP error handling for 400, 401/403, 404, 429, and 5xx with automatic credential masking (`[REDACTED]`).
- Ensured user messages are deduplicated and formatted with top-level `systemInstruction`.

### C. GitHub Actions & CI Pipeline (`.github/workflows/build-apk.yml`)
- Strict verification for `GOOGLE_SERVICES_JSON` repository secret: verifies JSON syntax, client list, and package name match `com.aistudio.cashflow.a3k9p`.
- Automatic keystore restoration from `debug.keystore.base64` or on-the-fly generation via `keytool`.
- Gradle build step passes `GEMINI_API_KEY`, `ALPHA_VANTAGE_API_KEY`, and `FINNHUB_API_KEY` into environment and BuildConfig.
- Automatically uploads `app/build/outputs/apk/debug/app-debug.apk` as a downloadable GitHub Actions artifact: `CashFlow-AI-Debug-APK`.

---

## 3. App Feature Status Audit
| Feature | Implementation Status | Notes |
| :--- | :--- | :--- |
| **Live Chart Camera (CameraX)** | Existing source present | Runtime behavior was not re-verified in this repair environment. |
| **AI Chart Analysis (Gemini)** | Available for interpretation; not approved as a standalone trading signal | Model-only confidence is not a measured probability. Actionable output remains WAIT until locally validated out-of-sample evidence is attached. |
| **Real Market Data Engine** | Provider integrations present; coverage depends on API keys and provider limits | No synthetic fallback is permitted in the actionable pipeline. Each instrument must be checked for its own fresh quote and history coverage. |
| **Trade Journal & History** | Existing source present | Database/runtime behavior was not re-verified in this repair environment. |
| **Broker Connection** | **Simulated / Demo Mode** | Runs a local sandbox paper-trading broker. **NOT** a live financial brokerage API gateway. |

---

## 4. How to Deploy to GitHub & Build the APK

1. **Push Changes to GitHub**:
   Replace the corresponding files in your repository with the modified files from this repair ZIP, or push the repaired project root directly:
   ```bash
   git add .
   git commit -m "Fix Firebase google-services.json, Gemini API headers, and CI build"
   git push origin main
   ```

2. **Add GitHub Repository Secrets**:
   Go to your GitHub repository -> **Settings** -> **Secrets and variables** -> **Actions** -> **New repository secret**:
   - `GEMINI_API_KEY`: Your Google Gemini API key.
   - `GOOGLE_SERVICES_JSON`: Required for CI builds when `app/google-services.json` is not committed; paste the full JSON content as a GitHub Actions secret.
   - `FINNHUB_API_KEY`: (Optional) Your Finnhub key for live stock/forex quotes.
   - `ALPHA_VANTAGE_API_KEY`: (Optional) Your Alpha Vantage key.

3. **Download & Install the APK**:
   - In GitHub, go to the **Actions** tab.
   - Click the latest run: **Build CashFlow AI APK**.
   - Under **Artifacts**, download `CashFlow-AI-Debug-APK.zip`.
   - Extract `app-debug.apk` and transfer to your Android phone.
   - Enable "Install unknown apps" in Android settings and tap to install.


---

## 5. Safety and 90-Day Historical Evidence Repair (2026-10-31)

This repair pass intentionally prioritizes data integrity over producing more BUY/SELL labels.

### Changes made
- `SignalEngine.generateSignal()` no longer constructs fake candle highs/lows from closing prices. Close-only inputs return WAIT because candle geometry and a statistically supported win probability cannot be established from closes alone.
- Added `HistoricalConfidenceGate`, which uses a conservative 95% Wilson lower confidence bound and rejects evidence unless it is out-of-sample, includes transaction costs, and has at least 200 completed outcomes. A displayed AI score alone never passes this gate.
- Gemini chart/market parsing no longer defaults missing action to BUY, missing confidence to a high number, or missing patterns/levels to invented values. Model-only output is forced to WAIT with confidence 0 until empirical evidence is supplied to the app.
- `TradingSignal` defaults are now WAIT / 0 confidence / zero price levels instead of a fabricated BUY example.
- Historical data requests were expanded to a rolling 90-day window where the configured provider supports it: paginated Binance hourly candles for crypto/PAXG, 90-day hourly forex history, and Yahoo chart history requested as three months/hourly.
- Historical OHLC candles are retained on `GenuineMarketQuote` for analysis and telemetry reports candle count and coverage. Binance, forex, and Yahoo hourly historical candles are cached for 15 minutes to avoid refetching the full 90-day window on every quote poll; Yahoo's smaller quote request is separate from the cached history request.
- Stock OHLC rows with missing open/high/low values are discarded instead of inventing candle geometry from the close.
- Partial provider failures are reported as partial market-data availability rather than silently claiming every instrument is connected.
- Removed pre-populated fake open positions from broker-manager initialization.
- The current broker manager explicitly labels itself as local paper simulation and rejects LIVE connection attempts. It does **not** authenticate with MT5/Exness or submit real broker orders.
- Auto-execution confidence checks now require at least 90, and missing stop-loss/take-profit values no longer get silently replaced by fallback prices.
- Updated UI labels so a zero score displays as `UNVALIDATED`, not as a measured 0% win probability.

### Important remaining work (not represented as completed)
- The probability gate is implemented as a reusable component but still needs to be connected to a durable store of correctly resolved, out-of-sample strategy outcomes before any BUY/SELL can be promoted. Until then, WAIT is the safe output.
- The 90-day candle data is held on the live quote object and refreshed from providers; it is not yet a fully versioned Room history store with scheduled walk-forward backtests and signal-outcome resolution.
- Historical API coverage is provider-dependent. A valid API key, plan entitlement, supported symbol, and successful provider response are required. If a provider returns fewer than 50 candles or incomplete coverage, the app must not claim a complete 90-day analysis.
- The broker adapter for authenticated MT5/Exness/direct API execution remains unimplemented. The current order manager is only a local paper simulator.
- This environment could not complete Gradle tests/build because Gradle 9.3.1 was not cached and network access to `services.gradle.org` was unavailable. Treat this source package as **not build-verified** until CI or Android Studio runs the build successfully.
- This uploaded ZIP did not include `app/google-services.json`. Because the Gradle Google Services plugin is configured to fail on missing Firebase configuration, restore the correct file locally or inject the validated JSON via the repository's documented CI secret before building.
