package com.example

import com.example.data.BrokerAccountEntity
import com.example.data.BrokerConnectionManager
import com.example.data.BrokerPosition
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

/**
 * Regression tests for Broker Safety Guards:
 * Proves that invalid inputs (zero/negative/NaN/Infinite prices, inverted brackets, invalid volume)
 * are strictly rejected, paper trading is never falsely marked as live real-money execution,
 * and valid paper trades continue to function normally.
 */
@RunWith(RobolectricTestRunner::class)
@OptIn(ExperimentalCoroutinesApi::class)
class BrokerSafetyRegressionTest {

    private val testDispatcher = StandardTestDispatcher()
    private val testScope = TestScope(testDispatcher)
    private lateinit var brokerManager: BrokerConnectionManager

    @Before
    fun setUp() {
        brokerManager = BrokerConnectionManager(testScope)
        brokerManager.stopAllSimulation()
    }

    @After
    fun tearDown() {
        brokerManager.stopAllSimulation()
    }

    @Test
    fun testExecuteTrade_rejectsZeroOrNegativeEntryPrice() = testScope.runTest {
        var callbackSuccess = true
        var callbackMsg = ""
        var callbackPosition: BrokerPosition? = null

        // Zero entry price
        brokerManager.executeTrade(
            symbol = "BTC/USD",
            side = "BUY",
            entryPrice = 0.0,
            stopLoss = 79000.0,
            takeProfit = 82000.0,
            volume = 0.1
        ) { success, msg, pos ->
            callbackSuccess = success
            callbackMsg = msg
            callbackPosition = pos
        }
        advanceUntilIdle()

        assertFalse(callbackSuccess)
        assertNull(callbackPosition)
        assertTrue(callbackMsg.contains("Invalid entry price"))

        // Negative entry price
        brokerManager.executeTrade(
            symbol = "EUR/USD",
            side = "BUY",
            entryPrice = -1.0850,
            stopLoss = 1.0800,
            takeProfit = 1.0950,
            volume = 0.1
        ) { success, msg, pos ->
            callbackSuccess = success
            callbackMsg = msg
            callbackPosition = pos
        }
        advanceUntilIdle()

        assertFalse(callbackSuccess)
        assertNull(callbackPosition)
        assertTrue(callbackMsg.contains("Invalid entry price"))
    }

    @Test
    fun testExecuteTrade_rejectsNaNOrInfinitePrices() = testScope.runTest {
        var callbackSuccess = true
        var callbackMsg = ""

        // NaN entry price
        brokerManager.executeTrade(
            symbol = "BTC/USD",
            side = "BUY",
            entryPrice = Double.NaN,
            stopLoss = 79000.0,
            takeProfit = 82000.0,
            volume = 0.1
        ) { success, msg, _ ->
            callbackSuccess = success
            callbackMsg = msg
        }
        advanceUntilIdle()

        assertFalse(callbackSuccess)
        assertTrue(callbackMsg.contains("Invalid entry price"))

        // Infinite stop loss
        brokerManager.executeTrade(
            symbol = "BTC/USD",
            side = "BUY",
            entryPrice = 80000.0,
            stopLoss = Double.POSITIVE_INFINITY,
            takeProfit = 82000.0,
            volume = 0.1
        ) { success, msg, _ ->
            callbackSuccess = success
            callbackMsg = msg
        }
        advanceUntilIdle()

        assertFalse(callbackSuccess)
        assertTrue(callbackMsg.contains("Invalid stop-loss"))
    }

    @Test
    fun testExecuteTrade_rejectsZeroOrNegativeVolume() = testScope.runTest {
        var callbackSuccess = true
        var callbackMsg = ""

        brokerManager.executeTrade(
            symbol = "NVDA",
            side = "BUY",
            entryPrice = 125.0,
            stopLoss = 120.0,
            takeProfit = 135.0,
            volume = 0.0
        ) { success, msg, _ ->
            callbackSuccess = success
            callbackMsg = msg
        }
        advanceUntilIdle()

        assertFalse(callbackSuccess)
        assertTrue(callbackMsg.contains("Invalid volume"))

        brokerManager.executeTrade(
            symbol = "NVDA",
            side = "BUY",
            entryPrice = 125.0,
            stopLoss = 120.0,
            takeProfit = 135.0,
            volume = -0.5
        ) { success, msg, _ ->
            callbackSuccess = success
            callbackMsg = msg
        }
        advanceUntilIdle()

        assertFalse(callbackSuccess)
        assertTrue(callbackMsg.contains("Invalid volume"))
    }

    @Test
    fun testExecuteTrade_rejectsInvertedBuyBrackets() = testScope.runTest {
        var callbackSuccess = true
        var callbackMsg = ""

        // BUY with stopLoss above entryPrice
        brokerManager.executeTrade(
            symbol = "EUR/USD",
            side = "BUY",
            entryPrice = 1.0850,
            stopLoss = 1.0900, // Invalid: above entry
            takeProfit = 1.0950,
            volume = 0.1
        ) { success, msg, _ ->
            callbackSuccess = success
            callbackMsg = msg
        }
        advanceUntilIdle()

        assertFalse(callbackSuccess)
        assertTrue(callbackMsg.contains("Invalid BUY brackets"))

        // BUY with takeProfit below entryPrice
        brokerManager.executeTrade(
            symbol = "EUR/USD",
            side = "BUY",
            entryPrice = 1.0850,
            stopLoss = 1.0800,
            takeProfit = 1.0820, // Invalid: below entry
            volume = 0.1
        ) { success, msg, _ ->
            callbackSuccess = success
            callbackMsg = msg
        }
        advanceUntilIdle()

        assertFalse(callbackSuccess)
        assertTrue(callbackMsg.contains("Invalid BUY brackets"))
    }

    @Test
    fun testExecuteTrade_rejectsInvertedSellBrackets() = testScope.runTest {
        var callbackSuccess = true
        var callbackMsg = ""

        // SELL with stopLoss below entryPrice
        brokerManager.executeTrade(
            symbol = "EUR/USD",
            side = "SELL",
            entryPrice = 1.0850,
            stopLoss = 1.0800, // Invalid: below entry
            takeProfit = 1.0750,
            volume = 0.1
        ) { success, msg, _ ->
            callbackSuccess = success
            callbackMsg = msg
        }
        advanceUntilIdle()

        assertFalse(callbackSuccess)
        assertTrue(callbackMsg.contains("Invalid SELL brackets"))

        // SELL with takeProfit above entryPrice
        brokerManager.executeTrade(
            symbol = "EUR/USD",
            side = "SELL",
            entryPrice = 1.0850,
            stopLoss = 1.0900,
            takeProfit = 1.0950, // Invalid: above entry
            volume = 0.1
        ) { success, msg, _ ->
            callbackSuccess = success
            callbackMsg = msg
        }
        advanceUntilIdle()

        assertFalse(callbackSuccess)
        assertTrue(callbackMsg.contains("Invalid SELL brackets"))
    }

    @Test
    fun testExecuteTrade_rejectsUnsupportedAction() = testScope.runTest {
        var callbackSuccess = true
        var callbackMsg = ""

        brokerManager.executeTrade(
            symbol = "EUR/USD",
            side = "WAIT",
            entryPrice = 1.0850,
            stopLoss = 1.0800,
            takeProfit = 1.0950,
            volume = 0.1
        ) { success, msg, _ ->
            callbackSuccess = success
            callbackMsg = msg
        }
        advanceUntilIdle()

        assertFalse(callbackSuccess)
        assertTrue(callbackMsg.contains("Unsupported trade action"))
    }

    @Test
    fun testExecuteTrade_acceptsValidPaperTrade() = testScope.runTest {
        var callbackSuccess = false
        var callbackMsg = ""
        var callbackPosition: BrokerPosition? = null

        brokerManager.executeTrade(
            symbol = "BTC/USD",
            side = "BUY",
            entryPrice = 82500.0,
            stopLoss = 81000.0,
            takeProfit = 85500.0,
            volume = 0.25
        ) { success, msg, pos ->
            callbackSuccess = success
            callbackMsg = msg
            callbackPosition = pos
        }
        advanceUntilIdle()

        assertTrue(callbackSuccess)
        assertTrue(callbackMsg.contains("Successfully executed BUY on PAPER_TRADING"))
        assertNotNull(callbackPosition)
        assertEquals("BTC/USD", callbackPosition?.symbol)
        assertEquals(82500.0, callbackPosition?.openPrice ?: 0.0, 0.001)
        assertEquals(0.25, callbackPosition?.volume ?: 0.0, 0.001)
        assertTrue(callbackPosition?.ticketId?.startsWith("TKT-") == true)
    }

    @Test
    fun testLiveConnectionIsRejectedUntilRealAdapterExists() = testScope.runTest {
        val testAccount = BrokerAccountEntity(
            id = 1,
            brokerType = "METATRADER_5",
            accountName = "Primary MT5",
            accountId = "1092842",
            apiTokenOrPassword = "demo",
            serverOrEndpoint = "mt5.demo.server",
            environment = "LIVE",
            balance = 10000.0,
            equity = 10000.0,
            freeMargin = 10000.0,
            isConnected = false
        )

        var connectSuccess = false
        var connectMsg = ""

        brokerManager.connect(testAccount) { success, msg ->
            connectSuccess = success
            connectMsg = msg
        }
        advanceUntilIdle()

        assertFalse(connectSuccess)
        // Live mode must be rejected until a real authenticated broker adapter exists.
        assertEquals("ERROR", brokerManager.connectionStatus.value)
        assertTrue(connectMsg.contains("Broker execution is not configured for environment"))

        // Stop background heartbeat before testScope completes
        brokerManager.stopAllSimulation()
    }

    @Test
    fun testEntryPriceParsing_rejectsInvalidOrZeroPrices() {
        // Direct test of parsing logic used in executeSignalOnBroker
        fun parseValidPriceOrNull(raw: String): Double? {
            return try {
                val trimmed = raw.trim()
                if (trimmed.startsWith("-")) return null
                val cleaned = trimmed.replace(Regex("[^0-9.]"), "")
                val parsed = cleaned.toDoubleOrNull()
                if (parsed != null && parsed > 0.0 && !parsed.isNaN() && !parsed.isInfinite()) parsed else null
            } catch (_: Exception) {
                null
            }
        }

        assertNull(parseValidPriceOrNull(""))
        assertNull(parseValidPriceOrNull("N/A"))
        assertNull(parseValidPriceOrNull("$0.00"))
        assertNull(parseValidPriceOrNull("0.0"))
        assertNull(parseValidPriceOrNull("-1.0850"))

        val validForex = parseValidPriceOrNull("1.0855")
        assertNotNull(validForex)
        assertEquals(1.0855, validForex!!, 0.0001)

        val validCrypto = parseValidPriceOrNull("$82,450.50")
        assertNotNull(validCrypto)
        assertEquals(82450.50, validCrypto!!, 0.01)
    }

    @Test
    fun testExecuteTrade_rejectsDuplicateOrderWithinCooldown() = testScope.runTest {
        var firstSuccess = false
        var secondSuccess = true
        var secondMsg = ""

        // First trade
        brokerManager.executeTrade(
            symbol = "ETH/USD",
            side = "BUY",
            entryPrice = 3500.0,
            stopLoss = 3400.0,
            takeProfit = 3700.0,
            volume = 0.1
        ) { success, _, _ ->
            firstSuccess = success
        }
        advanceUntilIdle()
        assertTrue(firstSuccess)

        // Immediate second trade with exact same symbol and side
        brokerManager.executeTrade(
            symbol = "ETH/USD",
            side = "BUY",
            entryPrice = 3500.0,
            stopLoss = 3400.0,
            takeProfit = 3700.0,
            volume = 0.1
        ) { success, msg, _ ->
            secondSuccess = success
            secondMsg = msg
        }
        advanceUntilIdle()

        assertFalse("Duplicate order must be rejected within cooldown", secondSuccess)
        assertTrue(secondMsg.contains("Duplicate order detected"))
    }

    @Test
    fun testExecuteTrade_rejectsInsufficientFreeMargin() = testScope.runTest {
        val lowMarginAccount = BrokerAccountEntity(
            id = 2,
            brokerType = "PAPER_TRADING",
            accountName = "Low Margin",
            accountId = "VIRTUAL-LOW",
            apiTokenOrPassword = "pass",
            serverOrEndpoint = "sandbox",
            freeMargin = 5.0 // Insufficient for volume = 0.5 (needs 50.0)
        )

        brokerManager.connect(lowMarginAccount) { _, _ -> }
        advanceUntilIdle()
        brokerManager.stopAllSimulation()

        var tradeSuccess = true
        var tradeMsg = ""

        brokerManager.executeTrade(
            symbol = "BTC/USD",
            side = "BUY",
            entryPrice = 85000.0,
            stopLoss = 84000.0,
            takeProfit = 87000.0,
            volume = 0.5 // requires 0.5 * 100 = 50.0 margin > 5.0 free margin
        ) { success, msg, _ ->
            tradeSuccess = success
            tradeMsg = msg
        }
        advanceUntilIdle()

        assertFalse("Trade must be rejected when free margin is insufficient", tradeSuccess)
        assertTrue(tradeMsg.contains("Insufficient free margin"))
        brokerManager.stopAllSimulation()
    }

    @Test
    fun testExecuteTrade_rejectsWhenDailyLossCircuitBreakerTripped() = testScope.runTest {
        val todayStart = BrokerConnectionManager.getUtcDayStartTimestamp()
        val trippedAccount = BrokerAccountEntity(
            id = 10,
            brokerType = "PAPER_TRADING",
            accountName = "Tripped Account",
            accountId = "VIRTUAL-TRIPPED",
            apiTokenOrPassword = "token",
            serverOrEndpoint = "sandbox",
            dailyLossLimit = 300.0,
            dailyRealizedLoss = 350.0,
            dailyLossResetTimestamp = todayStart,
            isCircuitBreakerTripped = true
        )
        brokerManager.connect(trippedAccount) { _, _ -> }
        advanceUntilIdle()
        brokerManager.stopAllSimulation()

        var success = true
        var message = ""
        brokerManager.executeTrade(
            symbol = "EUR/USD",
            side = "BUY",
            entryPrice = 1.0850,
            stopLoss = 1.0800,
            takeProfit = 1.0950,
            volume = 0.05
        ) { ok, msg, _ ->
            success = ok
            message = msg
        }
        advanceUntilIdle()

        assertFalse("Trade must be rejected when circuit breaker is tripped", success)
        assertTrue(message.contains("Daily-loss circuit breaker is active"))
        brokerManager.stopAllSimulation()
    }

    @Test
    fun testClosePosition_tripsCircuitBreakerWhenDailyLossExceeded() = testScope.runTest {
        val todayStart = BrokerConnectionManager.getUtcDayStartTimestamp()
        val account = BrokerAccountEntity(
            id = 11,
            brokerType = "DERIV",
            accountName = "Risk Account",
            accountId = "CR-194821",
            apiTokenOrPassword = "token",
            serverOrEndpoint = "sandbox",
            dailyLossLimit = 20.0, // Limit is $20.00
            dailyRealizedLoss = 0.0,
            dailyLossResetTimestamp = todayStart,
            isCircuitBreakerTripped = false
        )
        brokerManager.connect(account) { _, _ -> }
        advanceUntilIdle()
        brokerManager.stopAllSimulation()

        // Explicitly set unrealizedPnL on POS-91824 to -$50.00 (loss > $20.00 limit)
        brokerManager.updatePositionPnLForTesting("POS-91824", -50.0)

        var closeSuccess = false
        var closedPnl = 0.0
        brokerManager.closePosition("POS-91824") { ok, pnl ->
            closeSuccess = ok
            closedPnl = pnl
        }
        advanceUntilIdle()

        assertTrue(closeSuccess)
        assertEquals(-50.0, closedPnl, 0.01)

        val updated = brokerManager.connectedAccount.value
        assertNotNull(updated)
        assertEquals(50.0, updated!!.dailyRealizedLoss, 0.01)
        assertTrue("Circuit breaker must trip when daily realized loss exceeds limit", updated.isCircuitBreakerTripped)

        // Verify subsequent trade is blocked
        var tradeBlocked = false
        brokerManager.executeTrade(
            symbol = "EUR/USD",
            side = "BUY",
            entryPrice = 1.0850,
            stopLoss = 1.0800,
            takeProfit = 1.0950,
            volume = 0.05
        ) { ok, msg, _ ->
            tradeBlocked = !ok
        }
        advanceUntilIdle()
        assertTrue("Subsequent trade must be blocked by tripped circuit breaker", tradeBlocked)
        brokerManager.stopAllSimulation()
    }

    @Test
    fun testClosePosition_winningTradeDoesNotErasePriorRealizedLoss() = testScope.runTest {
        val todayStart = BrokerConnectionManager.getUtcDayStartTimestamp()
        val account = BrokerAccountEntity(
            id = 12,
            brokerType = "DERIV",
            accountName = "Winning Check Account",
            accountId = "CR-194821",
            apiTokenOrPassword = "token",
            serverOrEndpoint = "sandbox",
            dailyLossLimit = 100.0,
            dailyRealizedLoss = 45.0,
            dailyLossResetTimestamp = todayStart,
            isCircuitBreakerTripped = false
        )
        brokerManager.connect(account) { _, _ -> }
        advanceUntilIdle()
        brokerManager.stopAllSimulation()

        // Set unrealizedPnL on POS-73910 to +35.00 (winning trade)
        brokerManager.updatePositionPnLForTesting("POS-73910", 35.0)

        var closeSuccess = false
        var closedPnl = 0.0
        brokerManager.closePosition("POS-73910") { ok, pnl ->
            closeSuccess = ok
            closedPnl = pnl
        }
        advanceUntilIdle()

        assertTrue(closeSuccess)
        assertEquals(35.0, closedPnl, 0.01)

        val updated = brokerManager.connectedAccount.value
        assertNotNull(updated)
        // Winning trades must NEVER erase prior daily realized loss
        assertEquals(45.0, updated!!.dailyRealizedLoss, 0.01)
        assertFalse(updated.isCircuitBreakerTripped)
        brokerManager.stopAllSimulation()
    }

    @Test
    fun testResetDailyLoss_clearsCircuitBreaker() = testScope.runTest {
        val todayStart = BrokerConnectionManager.getUtcDayStartTimestamp()
        val trippedAccount = BrokerAccountEntity(
            id = 13,
            brokerType = "PAPER_TRADING",
            accountName = "To Reset",
            accountId = "VIRTUAL-RESET",
            apiTokenOrPassword = "token",
            serverOrEndpoint = "sandbox",
            dailyLossLimit = 100.0,
            dailyRealizedLoss = 150.0,
            dailyLossResetTimestamp = todayStart,
            isCircuitBreakerTripped = true
        )
        brokerManager.connect(trippedAccount) { _, _ -> }
        advanceUntilIdle()
        brokerManager.stopAllSimulation()

        brokerManager.resetDailyLoss("Manual Test Reset")
        advanceUntilIdle()

        val resetAcc = brokerManager.connectedAccount.value
        assertNotNull(resetAcc)
        assertEquals(0.0, resetAcc!!.dailyRealizedLoss, 0.001)
        assertFalse(resetAcc.isCircuitBreakerTripped)

        // After reset, a trade must succeed
        var tradeSuccess = false
        brokerManager.executeTrade(
            symbol = "EUR/USD",
            side = "BUY",
            entryPrice = 1.0850,
            stopLoss = 1.0800,
            takeProfit = 1.0950,
            volume = 0.05
        ) { ok, _, _ ->
            tradeSuccess = ok
        }
        advanceUntilIdle()
        assertTrue("Trade must succeed after circuit breaker reset", tradeSuccess)
        brokerManager.stopAllSimulation()
    }

    @Test
    fun testRolloverDailyLoss_resetsOnNewUtcDay() {
        val day1Millis = 1776518400000L // 2026-04-18 00:00:00 UTC
        val day1Start = BrokerConnectionManager.getUtcDayStartTimestamp(day1Millis)

        val account = BrokerAccountEntity(
            id = 14,
            brokerType = "PAPER_TRADING",
            accountName = "Rollover Account",
            accountId = "VIRTUAL-ROLL",
            apiTokenOrPassword = "token",
            serverOrEndpoint = "sandbox",
            dailyLossLimit = 200.0,
            dailyRealizedLoss = 250.0,
            dailyLossResetTimestamp = day1Start,
            isCircuitBreakerTripped = true
        )

        // Same day: 2 hours later
        val sameDayLater = day1Millis + 7200000L
        val sameDayResult = BrokerConnectionManager.checkAndRolloverDailyLoss(account, sameDayLater)
        assertEquals(250.0, sameDayResult.dailyRealizedLoss, 0.001)
        assertTrue(sameDayResult.isCircuitBreakerTripped)

        // Next UTC day: 26 hours later
        val nextDayMillis = day1Millis + 93600000L
        val nextDayResult = BrokerConnectionManager.checkAndRolloverDailyLoss(account, nextDayMillis)
        assertEquals(0.0, nextDayResult.dailyRealizedLoss, 0.001)
        assertFalse(nextDayResult.isCircuitBreakerTripped)
        assertEquals(BrokerConnectionManager.getUtcDayStartTimestamp(nextDayMillis), nextDayResult.dailyLossResetTimestamp)
    }
}

