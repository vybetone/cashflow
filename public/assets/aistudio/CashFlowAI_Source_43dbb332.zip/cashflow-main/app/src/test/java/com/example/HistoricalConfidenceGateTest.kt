package com.example

import com.example.data.HistoricalConfidenceGate
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HistoricalConfidenceGateTest {
    @Test
    fun rejectsAiOnlyOrInSampleScores() {
        assertFalse(HistoricalConfidenceGate.evaluate(195, 5, false, true).eligible)
        assertFalse(HistoricalConfidenceGate.evaluate(195, 5, true, false).eligible)
    }

    @Test
    fun rejectsSmallSamplesEvenWithPerfectWinRate() {
        val result = HistoricalConfidenceGate.evaluate(20, 0, true, true)
        assertFalse(result.eligible)
        assertTrue(result.reason.contains("Insufficient"))
    }

    @Test
    fun requiresLowerConfidenceBoundToMeetNinetyPercent() {
        assertFalse(HistoricalConfidenceGate.evaluate(184, 16, true, true).eligible)
        assertTrue(HistoricalConfidenceGate.evaluate(990, 10, true, true).eligible)
    }
}
