package com.example.data

import android.graphics.Bitmap
import android.util.Base64
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

class GeminiTradingEngine(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
) {

    suspend fun analyzeChartImage(
        bitmap: Bitmap,
        source: String = "SCREEN_ANALYSIS",
        preferredModel: String = "gemini-3.5-flash",
        targetAsset: MarketAsset? = null
    ): TradingSignalEntity = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Throwable) {
            ""
        }

        // Phase 1A: Only attempt real Gemini API call if valid key is present
        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val apiResponse = callGeminiVisionApi(bitmap, apiKey, preferredModel)
                if (apiResponse != null) {
                    return@withContext apiResponse.copy(source = source)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // Phase 1A: Return explicit failure state instead of fallback
        // Users must know that analysis failed, not that it succeeded with fake data
        return@withContext createAnalysisFailureSignal(source)
    }

    private fun callGeminiVisionApi(
        bitmap: Bitmap,
        apiKey: String,
        modelName: String
    ): TradingSignalEntity? {
        val base64Image = bitmapToBase64(bitmap)
        val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent"

        val prompt = """
            You are CASH FLOW AI, an elite quantitative trading signal generator and senior chart technician.
            Analyze this live trading chart image in extreme technical detail.
            Look for:
            1. Candlestick patterns (Doji, Hammer, Engulfing, Morning Star, Pinbar, etc.)
            2. Trend direction and structure (Higher Highs/Higher Lows, Lower Highs/Lower Lows)
            3. Key Support and Resistance levels, Supply/Demand zones
            4. Moving Averages (EMA 9/20/50/200 crossovers or bounces)
            5. Oscillators (RSI divergence, MACD momentum)
            6. Risk-to-reward ratio and high-probability trade setups.

            Respond ONLY with a valid JSON object matching this exact schema:
            {
              "symbol": "BTC/USD or AAPL or EUR/USD or CHART_ASSET",
              "timeframe": "15m",
              "action": "WAIT",
              "confidenceScore": 0,
              "trendDirection": "BULLISH",
              "entryZone": "${'$'}96,200 - ${'$'}96,500",
              "stopLoss": "${'$'}95,400",
              "takeProfit": "${'$'}98,500",
              "riskRewardRatio": "1:2.6",
              "detectedPatterns": ["Bullish Engulfing", "20 EMA Support", "RSI Bullish Divergence"],
              "keyLevels": ["Support: ${'$'}95,400", "Resistance: ${'$'}98,500"],
              "reasoning": "Price tested a key demand zone at 95,400 with a strong bullish engulfing candle on high relative volume. 20 EMA is sloping upward with RSI recovering above 50, providin[...]
            }
         """.trimIndent()

        val jsonPayload = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", prompt)
                        })
                        put(JSONObject().apply {
                            put("inlineData", JSONObject().apply {
                                put("mimeType", "image/jpeg")
                                put("data", base64Image)
                            })
                        })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.2)
            })
        }

        val request = Request.Builder()
            .url(endpoint)
            .header("x-goog-api-key", apiKey)
            .post(jsonPayload.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string() ?: return null

        if (!response.isSuccessful) return null

        val responseJson = JSONObject(responseBody)
        val candidates = responseJson.optJSONArray("candidates") ?: return null
        if (candidates.length() == 0) return null

        val content = candidates.getJSONObject(0).optJSONObject("content") ?: return null
        val parts = content.optJSONArray("parts") ?: return null
        if (parts.length() == 0) return null

        val jsonText = parts.getJSONObject(0).optString("text")
        if (jsonText.isNullOrBlank()) return null

        val signalJson = JSONObject(jsonText)

        val symbol = signalJson.optString("symbol", "LIVE_CHART")
        val timeframe = signalJson.optString("timeframe", "15m")
        val action = signalJson.optString("action", "WAIT").uppercase()
        val confidence = signalJson.optInt("confidenceScore", 0)
        val trend = signalJson.optString("trendDirection", "UNKNOWN").uppercase()
        val entry = signalJson.optString("entryZone", "UNAVAILABLE")
        val sl = signalJson.optString("stopLoss", "UNAVAILABLE")
        val tp = signalJson.optString("takeProfit", "UNAVAILABLE")
        val rr = signalJson.optString("riskRewardRatio", "UNAVAILABLE")
        val reasoning = "AI candidate=$action (model score $confidence/100; not a measured win probability). " +
            signalJson.optString("reasoning", "Model response lacks validated evidence.") +
            " | Forced WAIT: local out-of-sample probability evidence has not been attached. " +
            "Visual entry/SL/TP suggestions are unverified and must not be executed."

        val patternsArray = signalJson.optJSONArray("detectedPatterns")
        val patternsList = mutableListOf<String>()
        if (patternsArray != null) {
            for (i in 0 until patternsArray.length()) {
                patternsList.add(patternsArray.getString(i))
            }
        }

        val levelsArray = signalJson.optJSONArray("keyLevels")
        val levelsList = mutableListOf<String>()
        if (levelsArray != null) {
            for (i in 0 until levelsArray.length()) {
                levelsList.add(levelsArray.getString(i))
            }
        }

        return TradingSignalEntity(
            symbol = symbol,
            timeframe = timeframe,
            action = "WAIT", // AI-only scores are not calibrated outcome probabilities; execution is blocked until local evidence gate is wired.
            confidenceScore = 0, // No empirical probability evidence has been attached to this model-only result.
            reasoning = reasoning,
            entryZone = "UNAVAILABLE — NOT VALIDATED",
            stopLoss = "UNAVAILABLE — NOT VALIDATED",
            takeProfit = "UNAVAILABLE — NOT VALIDATED",
            riskRewardRatio = "UNAVAILABLE",
            trendDirection = "UNVERIFIED: $trend",
            detectedPatterns = patternsList.joinToString(", ").ifBlank { "UNVERIFIED / NOT DETECTED" } + " (AI visual interpretation; unverified)",
            keyLevels = levelsList.joinToString(" | ").ifBlank { "UNAVAILABLE" } + " (unverified)",
            source = "SCREEN_ANALYSIS"
        )
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val stream = ByteArrayOutputStream()
        // Resize bitmap if too large to conserve payload size
        val maxDim = 1024
        val scaledBitmap = if (bitmap.width > maxDim || bitmap.height > maxDim) {
            val scale = maxDim.toFloat() / Math.max(bitmap.width, bitmap.height)
            Bitmap.createScaledBitmap(bitmap, (bitmap.width * scale).roundToInt(), (bitmap.height * scale).roundToInt(), true)
        } else {
            bitmap
        }
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 80, stream)
        return Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
    }

    /**
     * Phase 1A: Create explicit "analysis failed" signal.
     * This is returned when:
     * - API key is missing/invalid
     * - Gemini request fails
     * - Network error
     * - Response parse error
     *
     * Users can distinguish this from real analysis success.
     */
    private fun createAnalysisFailureSignal(source: String): TradingSignalEntity {
        return TradingSignalEntity(
            symbol = "ANALYSIS_FAILED",
            timeframe = "N/A",
            action = "WAIT",
            confidenceScore = 0,
            reasoning = "AI ANALYSIS UNAVAILABLE: Gemini API key missing or API request failed. Real price history and market data required for trading signals.",
            entryZone = "N/A",
            stopLoss = "N/A",
            takeProfit = "N/A",
            riskRewardRatio = "N/A",
            trendDirection = "UNKNOWN",
            detectedPatterns = "N/A",
            keyLevels = "N/A",
            source = source,
            tradeOutcome = "PENDING",
            actualProfitLoss = 0.0
        )
    }

    /**
     * Analyzes live genuine market data telemetry with Gemini AI.
     * When API key is missing or invalid, returns an explicit analysis failure signal.
     */
    suspend fun analyzeMarketDataWithAi(
        quote: GenuineMarketQuote,
        userInstructions: String? = null,
        preferredModel: String = "gemini-3.5-flash",
        brokerContext: String? = null
    ): TradingSignalEntity = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Throwable) {
            ""
        }

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val signal = callGeminiMarketAnalysisApi(quote, apiKey, preferredModel, userInstructions, brokerContext)
                if (signal != null) {
                    return@withContext signal
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // Return explicit failure when Gemini API is unconfigured or request fails
        return@withContext createAnalysisFailureSignal("AI_MARKET_TELEMETRY").copy(
            symbol = quote.asset.symbol
        )
    }

    private fun callGeminiMarketAnalysisApi(
        quote: GenuineMarketQuote,
        apiKey: String,
        modelName: String,
        userInstructions: String?,
        brokerContext: String?
    ): TradingSignalEntity? {
        val asset = quote.asset
        val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent"

        val prompt = """
            You are CASH FLOW AI, an elite institutional trading assistant and quantitative signal strategist.
            You are evaluating live genuine market telemetry for:
            Symbol: ${asset.symbol} (${asset.name})
            Category: ${asset.category.title}
            Current Price: ${quote.lastPrice} (${if (quote.isBidAskEstimated) "Estimated Indicative Bid: ${quote.bid}, Estimated Indicative Ask: ${quote.ask} [Non-Executable Indicative Spread]" else "Bid: ${quote.bid}, Ask: ${quote.ask}"}, Spread: ${quote.spreadPipsOrPoints})
            24h Change: ${quote.change24hPercent}%, 24h High: ${quote.high24h}, 24h Low: ${quote.low24h}, Volume: ${quote.volume24h}
            Technical Telemetry:
            - RSI (14): ${quote.rsi14}
            - EMAs: 20 EMA: ${quote.ema20}, 50 EMA: ${quote.ema50}, 200 EMA: ${quote.ema200?.toString() ?: "UNAVAILABLE (< 200 candles)"}
            - MACD (12,26,9): Line ${quote.macdLine}, Signal ${quote.macdSignal}, Histogram ${quote.macdHistogram}
            - Volatility (ATR): ${quote.atr}
            - Candlestick Geometry: ${quote.candlePattern}
            - Order Flow Bias: ${quote.orderFlowBias}
            - Key Support: ${quote.supportLevel} | Key Resistance: ${quote.resistanceLevel}
            ${if (userInstructions != null) "User Instructions / Focus: $userInstructions" else ""}
            ${if (brokerContext != null) "Connected Broker Context: $brokerContext" else ""}

            Task:
            Generate an evidence-based institutional trading signal. Calculate exact confluence, precise stop loss, take profit with minimum 1:2.0 risk-to-reward ratio, and 5 distinct evidence proof points.

            Respond ONLY with a valid JSON object matching this schema:
            {
              "symbol": "${asset.symbol}",
              "timeframe": "15m",
              "action": "WAIT", // BUY/SELL are candidates only; local statistical gate decides action
              "confidenceScore": 0, // never claim calibrated probability from model output
              "trendDirection": "BULLISH", // or "BEARISH" or "SIDEWAYS"
              "entryZone": "1.0860 - 1.0868",
              "stopLoss": "1.0830",
              "takeProfit": "1.0940",
              "riskRewardRatio": "1:2.67",
              "detectedPatterns": "RSI Oversold Bounce, 20 EMA Golden Support, Bullish Order Block",
              "keyLevels": "Support: 1.0830 | Resistance: 1.0940",
              "reasoning": "Detailed institutional confluence analysis showing why this trade is mathematically supported by RSI, EMA alignment, and liquidity dynamics."
            }
        """.trimIndent()

        val jsonPayload = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", prompt)
                        })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.2)
            })
        }

        val request = Request.Builder()
            .url(endpoint)
            .header("x-goog-api-key", apiKey)
            .post(jsonPayload.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string() ?: return null
        if (!response.isSuccessful) return null

        val responseJson = JSONObject(responseBody)
        val candidates = responseJson.optJSONArray("candidates") ?: return null
        if (candidates.length() == 0) return null

        val content = candidates.getJSONObject(0).optJSONObject("content") ?: return null
        val parts = content.optJSONArray("parts") ?: return null
        if (parts.length() == 0) return null

        val jsonText = parts.getJSONObject(0).optString("text")
        if (jsonText.isNullOrBlank()) return null

        val signalJson = JSONObject(jsonText)
        val symbol = signalJson.optString("symbol", asset.symbol)
        val timeframe = signalJson.optString("timeframe", "15m")
        val action = signalJson.optString("action", "WAIT").uppercase()
        val confidence = signalJson.optInt("confidenceScore", 0).coerceIn(0, 100)
        val trend = signalJson.optString("trendDirection", "UNKNOWN").uppercase()
        val entry = signalJson.optString("entryZone", "UNAVAILABLE")
        val sl = signalJson.optString("stopLoss", "UNAVAILABLE")
        val tp = signalJson.optString("takeProfit", "UNAVAILABLE")
        val rr = signalJson.optString("riskRewardRatio", "UNAVAILABLE")
        val reasoning = "AI candidate=$action (model score $confidence/100; not a measured win probability). " +
            signalJson.optString("reasoning", "Model response lacks validated evidence.") +
            " | Forced WAIT: local out-of-sample probability evidence has not been attached. " +
            "AI-suggested order levels are not validated and must not be executed."
        val patterns = signalJson.optString("detectedPatterns", "UNVERIFIED / NOT DETECTED")
        val levels = signalJson.optString("keyLevels", "UNAVAILABLE")

        return TradingSignalEntity(
            symbol = symbol,
            timeframe = timeframe,
            action = "WAIT", // Do not promote an AI score to a trade without statistically validated local evidence.
            confidenceScore = 0, // Model scores are not calibrated probabilities.
            reasoning = "[${asset.category.badgeLabel} AI CONFLUENCE] $reasoning",
            entryZone = "UNAVAILABLE — NOT VALIDATED",
            stopLoss = "UNAVAILABLE — NOT VALIDATED",
            takeProfit = "UNAVAILABLE — NOT VALIDATED",
            riskRewardRatio = "UNAVAILABLE",
            trendDirection = "UNVERIFIED: $trend",
            detectedPatterns = "$patterns (AI interpretation; unverified)",
            keyLevels = "$levels (unverified)",
            source = "AI_TRADING_ASSISTANT"
        )
    }

    suspend fun chatWithTradingAssistant(
        quote: GenuineMarketQuote,
        conversationHistory: List<AssistantChatMessage>,
        userMessage: String,
        preferredModel: String = "gemini-3.5-flash",
        apiKeyOverride: String? = null
    ): String = withContext(Dispatchers.IO) {
        val apiKey = apiKeyOverride ?: try {
            BuildConfig.GEMINI_API_KEY
        } catch (_: Throwable) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "AI Assistant unavailable: Please set a valid GEMINI_API_KEY in the Secrets panel to chat with Gemini on live telemetry."
        }

        val asset = quote.asset
        val systemPrompt = """
            You are CASH FLOW AI, a real-time quantitative trading assistant.
            You are currently analyzing live market telemetry for ${asset.symbol} (${asset.name}, ${asset.category.title}).
            Live Telemetry:
            - Price: ${quote.lastPrice} (${if (quote.isBidAskEstimated) "Est. Indicative Bid: ${quote.bid}, Est. Indicative Ask: ${quote.ask} [Non-Executable Indicative Spread]" else "Bid: ${quote.bid}, Ask: ${quote.ask}"})
            - 24h Change: ${quote.change24hPercent}% | 24h Range: [${quote.low24h} - ${quote.high24h}]
            - RSI(14): ${quote.rsi14} | MACD Hist: ${quote.macdHistogram}
            - EMAs: 20 EMA (${quote.ema20}), 50 EMA (${quote.ema50}), 200 EMA (${quote.ema200?.toString() ?: "UNAVAILABLE (< 200 candles)"})
            - Candle Geometry: ${quote.candlePattern} | Order Flow: ${quote.orderFlowBias}
            - Support: ${quote.supportLevel} | Resistance: ${quote.resistanceLevel}

            Provide concise, highly actionable, evidence-based trading guidance. Include exact numbers, risk management advice, stop loss/take profit recommendations, and broker execution readiness.
        """.trimIndent()

        val contentsArray = JSONArray()
        // Deduplicate: drop any trailing user message matching the current message
        val priorHistory = conversationHistory
            .dropLastWhile { it.isUser && it.text.trim() == userMessage.trim() }
            .takeLast(6)

        for (msg in priorHistory) {
            val role = if (msg.isUser) "user" else "model"
            contentsArray.put(JSONObject().apply {
                put("role", role)
                put("parts", JSONArray().apply {
                    put(JSONObject().apply { put("text", msg.text) })
                })
            })
        }

        // Add current user message exactly once
        contentsArray.put(JSONObject().apply {
            put("role", "user")
            put("parts", JSONArray().apply {
                put(JSONObject().apply { put("text", userMessage.trim()) })
            })
        })

        val jsonPayload = JSONObject().apply {
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().apply { put("text", systemPrompt) })
                })
            })
            put("contents", contentsArray)
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.4)
            })
        }

        fun executeModelCall(model: String): ChatCallResult {
            val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
            val request = Request.Builder()
                .url(endpoint)
                .header("x-goog-api-key", apiKey)
                .post(jsonPayload.toString().toRequestBody("application/json".toMediaType()))
                .build()

            return try {
                val response = client.newCall(request).execute()
                val responseBody = response.body?.string()
                if (response.isSuccessful && !responseBody.isNullOrBlank()) {
                    val respObj = JSONObject(responseBody)
                    val cand = respObj.optJSONArray("candidates")
                    val text = cand?.optJSONObject(0)
                        ?.optJSONObject("content")
                        ?.optJSONArray("parts")
                        ?.optJSONObject(0)
                        ?.optString("text")

                    if (!text.isNullOrBlank()) {
                        ChatCallResult.Success(text.trim())
                    } else {
                        ChatCallResult.HttpError(response.code, "Received empty or malformed candidate in response")
                    }
                } else {
                    val parsedError = parseGeminiErrorMessage(responseBody)
                    ChatCallResult.HttpError(response.code, parsedError ?: responseBody.orEmpty())
                }
            } catch (e: Exception) {
                ChatCallResult.NetworkFailure(e)
            }
        }

        var result = executeModelCall(preferredModel)

        // If user selected gemini-3.1-pro-preview and hit quota (429) or not found (404),
        // fallback to verified gemini-3.5-flash
        if (result is ChatCallResult.HttpError && (result.code == 429 || result.code == 404) && preferredModel != "gemini-3.5-flash") {
            val fallback = executeModelCall("gemini-3.5-flash")
            if (fallback is ChatCallResult.Success) {
                return@withContext fallback.text
            }
        }

        return@withContext when (result) {
            is ChatCallResult.Success -> result.text
            is ChatCallResult.NetworkFailure -> {
                val msg = result.exception.localizedMessage ?: "Connection timed out"
                "Network failure connecting to Gemini: $msg. Please verify your internet connection."
            }
            is ChatCallResult.HttpError -> {
                val safeMsg = result.rawError
                    .replace(Regex("key=[a-zA-Z0-9._-]+"), "key=[REDACTED]")
                    .replace(apiKey, "[REDACTED]")
                    .take(160)

                when (result.code) {
                    400 -> "Gemini API Bad Request (HTTP 400)${if (safeMsg.isNotBlank()) ": $safeMsg" else ". Invalid request payload format."}"
                    401, 403 -> "Gemini API authentication failed (HTTP ${result.code}): Unauthorized or invalid GEMINI_API_KEY. Please verify your key in the Secrets panel."
                    404 -> "Gemini model '$preferredModel' not found (HTTP 404). Please switch to gemini-3.5-flash in Settings."
                    429 -> "Gemini API rate limit or quota exceeded (HTTP 429). Please wait a moment or switch to gemini-3.5-flash in Settings."
                    in 500..599 -> "Gemini service temporarily unavailable (HTTP ${result.code}). Google's AI servers are experiencing downtime. Please retry shortly."
                    else -> {
                        if (safeMsg.contains("empty or malformed", ignoreCase = true)) {
                            "Received empty or malformed response from Gemini. Please retry your question."
                        } else {
                            "Gemini API returned error code ${result.code}${if (safeMsg.isNotBlank()) ": $safeMsg" else ". Please retry shortly."}"
                        }
                    }
                }
            }
        }
    }

    private fun parseGeminiErrorMessage(responseBody: String?): String? {
        if (responseBody.isNullOrBlank()) return null
        return try {
            val root = JSONObject(responseBody)
            val err = root.optJSONObject("error")
            err?.optString("message")?.takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }
    }

    private sealed class ChatCallResult {
        data class Success(val text: String) : ChatCallResult()
        data class HttpError(val code: Int, val rawError: String) : ChatCallResult()
        data class NetworkFailure(val exception: Exception) : ChatCallResult()
    }
}
