package com.example.data

data class TradingSignal(
    val symbol: String = "BTC/USD",
    val signalType: String = "WAIT", // "BUY", "SELL", "WAIT"
    val confidencePercentage: Int = 0, // 0 to 100; 0 means no validated probability evidence
    val entryPrice: Double = 0.0,
    val stopLoss: Double = 0.0,
    val takeProfit: Double = 0.0,
    val analysisReason: String = "WAIT — no statistically validated signal evidence available.",
    val timestamp: Long = System.currentTimeMillis(),
    val rsiValue: Double = 0.0,
    val macdSignal: String = "UNAVAILABLE",
    val emaTrend: String = "UNAVAILABLE",
    val candlePattern: String = "UNAVAILABLE",
    val momentumConfirmation: String = "UNAVAILABLE",
    val isStrongSignal: Boolean = confidencePercentage >= 90
)
