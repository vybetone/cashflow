package com.example.data

import kotlin.math.abs

class SignalEngine {

    /**
     * Calculates Relative Strength Index (RSI) for a list of close prices over specified period (default 14).
     */
    fun calculateRSI(prices: List<Double>, period: Int = 14): Double {
        if (period < 1 || prices.size < period + 1 ||
            prices.any { it <= 0.0 || it.isNaN() || it.isInfinite() }) return Double.NaN

        var gains = 0.0
        var losses = 0.0

        for (i in 1..period) {
            val change = prices[i] - prices[i - 1]
            if (change >= 0) gains += change else losses += abs(change)
        }

        var avgGain = gains / period
        var avgLoss = losses / period

        for (i in (period + 1) until prices.size) {
            val change = prices[i] - prices[i - 1]
            if (change >= 0) {
                avgGain = (avgGain * (period - 1) + change) / period
                avgLoss = (avgLoss * (period - 1)) / period
            } else {
                avgGain = (avgGain * (period - 1)) / period
                avgLoss = (avgLoss * (period - 1) + abs(change)) / period
            }
        }

        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return (100.0 - (100.0 / (1.0 + rs))).coerceIn(0.0, 100.0)
    }

    /**
     * Calculates Exponential Moving Average (EMA).
     */
    fun calculateEMA(prices: List<Double>, period: Int): Double {
        if (period < 1 || prices.size < period ||
            prices.any { it <= 0.0 || it.isNaN() || it.isInfinite() }) return Double.NaN

        val multiplier = 2.0 / (period + 1)
        var ema = prices.take(period).average()

        for (i in period until prices.size) {
            ema = (prices[i] - ema) * multiplier + ema
        }
        return ema
    }

    /**
     * Calculates MACD Line and Signal Line (12 Fast, 26 Slow, 9 Signal).
     */
    fun calculateMACD(prices: List<Double>): Pair<Double, Double> {
        if (prices.size < 34 || prices.any { it <= 0.0 || it.isNaN() || it.isInfinite() }) {
            return Pair(Double.NaN, Double.NaN)
        }

        val ema12 = calculateEMA(prices, 12)
        val ema26 = calculateEMA(prices, 26)
        val macdLine = ema12 - ema26

        // Calculate MACD history for signal line
        val macdHistory = mutableListOf<Double>()
        for (i in 26..prices.size) {
            val subList = prices.subList(0, i)
            val e12 = calculateEMA(subList, 12)
            val e26 = calculateEMA(subList, 26)
            macdHistory.add(e12 - e26)
        }

        val signalLine = if (macdHistory.isNotEmpty()) calculateEMA(macdHistory, 9) else 0.0
        return Pair(macdLine, signalLine)
    }

    /**
     * Detects Japanese Candlestick Patterns from OHLC lists.
     */
    fun detectCandlePattern(
        opens: List<Double>,
        highs: List<Double>,
        lows: List<Double>,
        closes: List<Double>
    ): String {
        val n = closes.size
        if (n < 2 || opens.size != n || highs.size != n || lows.size != n ||
            (opens + highs + lows + closes).any { it <= 0.0 || it.isNaN() || it.isInfinite() }) {
            return "INSUFFICIENT OR INVALID OHLC DATA"
        }

        val currOpen = opens[n - 1]
        val currClose = closes[n - 1]
        val currHigh = highs[n - 1]
        val currLow = lows[n - 1]

        val prevOpen = opens[n - 2]
        val prevClose = closes[n - 2]

        val currBody = abs(currClose - currOpen)
        val currRange = currHigh - currLow

        val isCurrBullish = currClose > currOpen
        val isPrevBearish = prevClose < prevOpen
        val isPrevBullish = prevClose > prevOpen

        // Bullish Engulfing
        if (isCurrBullish && isPrevBearish && currClose >= prevOpen && currOpen <= prevClose) {
            return "BULLISH ENGULFING"
        }

        // Bearish Engulfing
        if (!isCurrBullish && isPrevBullish && currClose <= prevOpen && currOpen >= prevClose) {
            return "BEARISH ENGULFING"
        }

        // Hammer / Pin Bar
        val lowerWick = if (isCurrBullish) currOpen - currLow else currClose - currLow
        if (currRange > 0 && lowerWick / currRange >= 0.6 && currBody / currRange <= 0.3) {
            return "BULLISH HAMMER PINBAR"
        }

        // Shooting Star
        val upperWick = if (isCurrBullish) currHigh - currClose else currHigh - currOpen
        if (currRange > 0 && upperWick / currRange >= 0.6 && currBody / currRange <= 0.3) {
            return "BEARISH SHOOTING STAR"
        }

        // Doji
        if (currRange > 0 && currBody / currRange <= 0.1) {
            return "INDECISION DOJI"
        }

        return if (isCurrBullish) "BULLISH MOMENTUM CANDLE" else "BEARISH MOMENTUM CANDLE"
    }

    /**
     * Evaluates volume/price momentum confirmation.
     */
    fun evaluateMomentum(prices: List<Double>, rsi: Double): String {
        if (prices.size < 5 || prices.any { it <= 0.0 || it.isNaN() || it.isInfinite() }) return "INSUFFICIENT DATA"
        val recentChange = (prices.last() - prices[prices.size - 5]) / prices[prices.size - 5] * 100.0

        return when {
            recentChange > 1.2 && rsi < 65 -> "STRONG BULLISH MOMENTUM SURGE"
            recentChange < -1.2 && rsi > 35 -> "STRONG BEARISH MOMENTUM DUMP"
            else -> "CONSOLIDATION MOMENTUM"
        }
    }

    /**
     * Produces an actionable signal only after verified OHLC and empirical probability
     * evidence are wired into this engine. The current safe behavior is WAIT for closes-only
     * inputs because indicator confluence is not a calibrated win probability.
     */
    fun generateSignal(symbol: String = "BTC/USD", priceHistory: List<Double>? = null): TradingSignal {
        val asset = MarketUniverse.findAssetBySymbol(symbol)
        if (priceHistory == null || priceHistory.size < 200 ||
            priceHistory.any { it <= 0.0 || it.isNaN() || it.isInfinite() }) {
            return createUnavailableWaitSignal(
                asset,
                "Genuine market data unavailable or insufficient: require at least 200 valid closes."
            )
        }

        // Close-only history cannot establish candle geometry or a statistically validated
        // probability of success. Do not manufacture OHLC values from closes.
        return createUnavailableWaitSignal(
            asset,
            "WAIT — actual OHLC candles and validated out-of-sample probability evidence are required. " +
                "Close-only data cannot justify an actionable BUY/SELL signal."
        )
    }

    /**
     * Strict gate for a future signal implementation. This method intentionally does not
     * infer probability from indicator confluence. A strategy must be backed by independent,
     * out-of-sample outcome evidence before an actionable signal can be emitted.
     */
    fun isEvidenceQualified(
        observedWins: Int,
        observedLosses: Int,
        outOfSampleOnly: Boolean,
        costsIncluded: Boolean,
        minimumLowerConfidenceBound: Double = 0.90
    ): Boolean {
        return HistoricalConfidenceGate.evaluate(
            wins = observedWins,
            losses = observedLosses,
            outOfSampleOnly = outOfSampleOnly,
            costsIncluded = costsIncluded,
            minimumLowerBound = minimumLowerConfidenceBound
        ).eligible
    }

    private fun createUnavailableWaitSignal(
        asset: MarketAsset,
        reason: String = "Genuine market data unavailable: Insufficient or invalid price history for technical analysis."
    ): TradingSignal {
        return TradingSignal(
            symbol = asset.symbol,
            signalType = "WAIT",
            confidencePercentage = 0,
            entryPrice = 0.0,
            stopLoss = 0.0,
            takeProfit = 0.0,
            analysisReason = reason,
            timestamp = System.currentTimeMillis(),
            rsiValue = 0.0,
            macdSignal = "INSUFFICIENT DATA",
            emaTrend = "INSUFFICIENT DATA",
            candlePattern = "Awaiting Real Market Data",
            momentumConfirmation = "NO DATA",
            isStrongSignal = false
        )
    }

    @Deprecated("Synthetic price generation removed from production signal paths", ReplaceWith("emptyList()"))
    fun generatePriceSeriesForAsset(asset: MarketAsset): List<Double> {
        return emptyList()
    }

    private fun generateDefaultPriceSeries(): List<Double> {
        return emptyList()
    }
}
