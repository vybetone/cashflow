package com.example.data

import kotlin.math.sqrt

/**
 * Conservative empirical gate for a claimed >=90% success probability.
 *
 * Uses a Wilson score lower bound (95% two-sided z=1.96), not an AI-generated score.
 * Evidence is rejected unless it is out-of-sample and includes transaction costs.
 * This does not make future outcomes certain; it is a minimum evidence screen.
 */
data class HistoricalConfidenceResult(
    val eligible: Boolean,
    val sampleSize: Int,
    val observedWinRate: Double?,
    val lowerConfidenceBound: Double?,
    val reason: String
)

object HistoricalConfidenceGate {
    const val DEFAULT_MINIMUM_SAMPLE_SIZE = 200
    private const val Z_95 = 1.96

    fun evaluate(
        wins: Int,
        losses: Int,
        outOfSampleOnly: Boolean,
        costsIncluded: Boolean,
        minimumLowerBound: Double = 0.90,
        minimumSampleSize: Int = DEFAULT_MINIMUM_SAMPLE_SIZE
    ): HistoricalConfidenceResult {
        val n = wins + losses
        if (wins < 0 || losses < 0 || n < 0) {
            return rejected(n.coerceAtLeast(0), "Invalid outcome counts.")
        }
        if (minimumLowerBound !in 0.0..1.0 || minimumSampleSize < 1) {
            return rejected(n, "Invalid confidence-gate configuration.")
        }
        if (!outOfSampleOnly) return rejected(n, "Evidence is not strictly out-of-sample.")
        if (!costsIncluded) return rejected(n, "Spread, commission, and slippage are not included.")
        if (n < minimumSampleSize) {
            return rejected(n, "Insufficient independent outcomes: $n/$minimumSampleSize required.")
        }

        val p = wins.toDouble() / n.toDouble()
        val z2 = Z_95 * Z_95
        val denominator = 1.0 + z2 / n
        val center = p + z2 / (2.0 * n)
        val margin = Z_95 * sqrt((p * (1.0 - p) / n) + (z2 / (4.0 * n * n)))
        val lower = ((center - margin) / denominator).coerceIn(0.0, 1.0)
        val eligible = lower >= minimumLowerBound

        return HistoricalConfidenceResult(
            eligible = eligible,
            sampleSize = n,
            observedWinRate = p,
            lowerConfidenceBound = lower,
            reason = if (eligible) {
                "Evidence gate passed: 95% Wilson lower bound meets the configured threshold."
            } else {
                "Evidence gate failed: 95% Wilson lower bound ${(lower * 100.0).format1()}% is below ${(minimumLowerBound * 100.0).format1()}%."
            }
        )
    }

    private fun rejected(n: Int, reason: String) = HistoricalConfidenceResult(
        eligible = false,
        sampleSize = n,
        observedWinRate = null,
        lowerConfidenceBound = null,
        reason = reason
    )

    private fun Double.format1(): String = String.format(java.util.Locale.US, "%.1f", this)
}
