# Cash Flow AI — Repair Status (2026-10-31)

## What this package changes
- Prevents close-only prices from being turned into fabricated candlestick highs/lows.
- Defaults signals to WAIT / 0 confidence and requires a conservative statistical evidence gate.
- Adds a Wilson lower-bound gate requiring at least 200 out-of-sample outcomes and transaction costs.
- Requests a rolling 90-day hourly OHLC history where providers support it and caches expensive history pulls.
- Retains OHLC history on the current market quote and reports coverage.
- Removes fake seeded broker positions and rejects LIVE/unknown environments until a real authenticated broker adapter exists.
- Enforces a hard minimum score threshold of 90 for any auto-execution path and blocks missing SL/TP fallbacks.
- Adds/updates regression tests for these safety rules.

## What is not finished
- The historical probability gate is not yet connected to a durable, correctly resolved outcome dataset. Until this is implemented and validated, AI-only results are forced to WAIT.
- 90-day history is currently held in the quote object/cache; a durable versioned Room history store and scheduled walk-forward backtester are still required.
- No real MT5/Exness order execution adapter is implemented. The broker manager is a local paper simulator only.
- Provider support, plan limits, API keys, and symbol coverage vary. Incomplete history must remain unavailable.
- This source ZIP does not include `app/google-services.json`; restore the correct Firebase configuration before building.
- Full Gradle build/tests could not run in this environment because Gradle 9.3.1 was not cached and `services.gradle.org` could not be reached. Only the standalone Kotlin confidence gate and signal-engine source compilation were verified.

## Before a real-money release
1. Wire the evidence gate to a durable, audited, out-of-sample outcome store.
2. Build and run all unit/instrumentation tests in CI with Firebase and provider secrets configured.
3. Test data coverage and symbol mapping per market.
4. Implement and security-review a supported broker adapter.
5. Keep real-money execution disabled until broker responses, actual fills, positions, and risk controls are verified.
