# CashFlow AI — Current Build and Verification Notes

This source package contains the simulation-removal and real-frame capture changes documented in `SOURCE_UPDATE_REPORT.md`.

## Current capability boundary

- CameraX captures a genuine camera frame and routes it through the existing chart-analysis pipeline.
- Android screen analysis requires a real MediaProjection permission result; no generated chart fallback is used.
- Missing/stale market data and incomplete AI responses do not become actionable BUY/SELL signals.
- Broker connection and order execution remain fail-closed. MT5 demo integration requires a separately deployed and verified terminal-side bridge; this package does not pretend that an account number or server label is a connection.
- The Room schema is unchanged. Existing user records are preserved.

## Build and test

From the project root, run:

```bash
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

The Gradle wrapper is executable in this package. In the environment used to prepare this update, these tasks could not be completed because Gradle 9.3.1 was not cached and `services.gradle.org` could not be resolved. Treat the app build as unverified until AI Studio or a machine with the required Gradle/Android SDK dependencies runs both commands successfully.

## Safe release process

1. Keep the original source archive as a backup.
2. Review the changed files and run the tests/build before producing an APK.
3. Do not commit, push, or merge unless explicitly requested.
4. Do not enable real-money or automated trading until a genuine MT5 terminal bridge and risk controls pass end-to-end demo testing.
