# CashFlow AI — MT5 Demo Integration Status

## Current implementation boundary

- CashFlow AI does **not** claim to connect to the MetaQuotes trade server from Android.
- A login number, a server name such as `MetaQuotes-Demo`, and a password are not an authenticated broker session.
- The app rejects connection attempts and order requests until a real, authenticated adapter is installed. No local order ticket or synthetic ping is created.
- Keep the account environment set to **DEMO / PRACTICE** while integration is being built. Live orders remain disabled.

## Official integration constraints

MetaTrader's official Python integration communicates with a running MetaTrader 5 desktop terminal and exposes account, quote, order and position operations through that terminal: https://www.mql5.com/en/docs/python_metatrader5

Automated trading logic for the terminal is implemented as an MQL5 Expert Advisor (EA): https://www.metatrader5.com/en/terminal/help/algotrading/autotrading

An EA can make HTTP requests only to URLs explicitly allowed in the terminal's Expert Advisors settings; `WebRequest` is synchronous and is available to EAs/scripts, not indicators: https://www.mql5.com/en/docs/network/webrequest

## Required next step before MT5 can be called integrated

Select and deploy a real terminal-side bridge (EA plus an authenticated transport/backend). It must expose verifiable account identity, environment (`DEMO`), account equity/balance, executable quotes, open positions, order acknowledgements, and reconciliation after timeouts. The Android app must verify the bridge identity and demo environment before sending any order. Until that end-to-end path exists and is tested against an actual MT5 demo terminal, this build intentionally refuses broker connection and execution.

No broker credentials, account IDs, endpoint URLs, or successful order responses are fabricated in this source.
