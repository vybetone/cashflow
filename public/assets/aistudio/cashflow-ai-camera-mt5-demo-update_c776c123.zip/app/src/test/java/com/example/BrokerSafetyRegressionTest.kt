package com.example

import com.example.data.BrokerAccountEntity
import com.example.data.BrokerConnectionManager
import com.example.data.BrokerPosition
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

/**
 * Regression tests for the production fail-closed broker boundary.
 * No test expects an invented account, ping, position, ticket, or successful order.
 */
@RunWith(RobolectricTestRunner::class)
@OptIn(ExperimentalCoroutinesApi::class)
class BrokerSafetyRegressionTest {
    private val testDispatcher = StandardTestDispatcher()
    private val testScope = TestScope(testDispatcher)
    private lateinit var brokerManager: BrokerConnectionManager

    @Before
    fun setUp() {
        brokerManager = BrokerConnectionManager(testScope)
    }

    @Test
    fun rejectsZeroNegativeNanAndInfiniteEntryPrices() = testScope.runTest {
        val invalidPrices = listOf(0.0, -1.0, Double.NaN, Double.POSITIVE_INFINITY)
        invalidPrices.forEach { price ->
            var success = true
            var message = ""
            var position: BrokerPosition? = null
            brokerManager.executeTrade("EUR/USD", "BUY", price, 0.9, 1.2, 0.1) { ok, msg, pos ->
                success = ok
                message = msg
                position = pos
            }
            advanceUntilIdle()
            assertFalse(success)
            assertNull(position)
            assertTrue(message.contains("Invalid entry price"))
        }
    }

    @Test
    fun rejectsInvalidVolumeAndBrackets() = testScope.runTest {
        var message = ""
        brokerManager.executeTrade("EUR/USD", "BUY", 1.1, 1.0, 1.2, 0.0) { _, msg, _ -> message = msg }
        advanceUntilIdle()
        assertTrue(message.contains("Invalid volume"))

        brokerManager.executeTrade("EUR/USD", "BUY", 1.1, 1.2, 1.3, 0.1) { _, msg, _ -> message = msg }
        advanceUntilIdle()
        assertTrue(message.contains("Invalid BUY brackets"))

        brokerManager.executeTrade("EUR/USD", "SELL", 1.1, 1.0, 0.9, 0.1) { _, msg, _ -> message = msg }
        advanceUntilIdle()
        assertTrue(message.contains("Invalid SELL brackets"))
    }

    @Test
    fun rejectsUnsupportedAction() = testScope.runTest {
        var message = ""
        brokerManager.executeTrade("EUR/USD", "WAIT", 1.1, 1.0, 1.2, 0.1) { _, msg, _ -> message = msg }
        advanceUntilIdle()
        assertTrue(message.contains("Unsupported trade action"))
    }

    @Test
    fun validOrderIsRejectedUntilVerifiedMt5BridgeExists() = testScope.runTest {
        var success = true
        var message = ""
        var position: BrokerPosition? = null
        brokerManager.executeTrade("EUR/USD", "BUY", 1.1, 1.0, 1.2, 0.1) { ok, msg, pos ->
            success = ok
            message = msg
            position = pos
        }
        advanceUntilIdle()
        assertFalse(success)
        assertNull(position)
        assertTrue(message.contains("no verified broker execution adapter"))
        assertTrue(brokerManager.openPositions.value.isEmpty())
    }

    @Test
    fun mt5AccountIdAloneDoesNotEstablishConnection() = testScope.runTest {
        val account = BrokerAccountEntity(
            id = 1,
            brokerType = "METATRADER_5",
            accountName = "MT5 Practice",
            accountId = "12345678",
            apiTokenOrPassword = "",
            serverOrEndpoint = "MetaQuotes-Demo",
            environment = "DEMO",
            balance = 0.0,
            equity = 0.0,
            freeMargin = 0.0
        )
        var success = true
        var message = ""
        brokerManager.connect(account) { ok, msg ->
            success = ok
            message = msg
        }
        advanceUntilIdle()
        assertFalse(success)
        assertEquals("ERROR", brokerManager.connectionStatus.value)
        assertNull(brokerManager.connectedAccount.value)
        assertTrue(message.contains("no verified MT5 terminal bridge"))
        assertTrue(brokerManager.openPositions.value.isEmpty())
    }

    @Test
    fun pingDoesNotInventLatency() {
        var ping = 0L
        brokerManager.testPing(
            BrokerAccountEntity(
                brokerType = "METATRADER_5",
                accountName = "MT5 Practice",
                accountId = "12345678",
                apiTokenOrPassword = "",
                serverOrEndpoint = "MetaQuotes-Demo",
                environment = "DEMO"
            )
        ) { ping = it }
        assertEquals(-1L, ping)
        assertEquals(0L, brokerManager.currentPingMs.value)
    }

    @Test
    fun dailyLossRolloverStillResetsOnNewUtcDay() {
        val day1Millis = 1776518400000L
        val day1Start = BrokerConnectionManager.getUtcDayStartTimestamp(day1Millis)
        val account = BrokerAccountEntity(
            id = 14,
            brokerType = "METATRADER_5",
            accountName = "Practice Account",
            accountId = "12345678",
            apiTokenOrPassword = "",
            serverOrEndpoint = "",
            dailyLossLimit = 200.0,
            dailyRealizedLoss = 250.0,
            dailyLossResetTimestamp = day1Start,
            isCircuitBreakerTripped = true
        )
        val sameDay = BrokerConnectionManager.checkAndRolloverDailyLoss(account, day1Millis + 7_200_000L)
        assertEquals(250.0, sameDay.dailyRealizedLoss, 0.001)
        assertTrue(sameDay.isCircuitBreakerTripped)

        val nextDayMillis = day1Millis + 93_600_000L
        val nextDay = BrokerConnectionManager.checkAndRolloverDailyLoss(account, nextDayMillis)
        assertEquals(0.0, nextDay.dailyRealizedLoss, 0.001)
        assertFalse(nextDay.isCircuitBreakerTripped)
        assertEquals(BrokerConnectionManager.getUtcDayStartTimestamp(nextDayMillis), nextDay.dailyLossResetTimestamp)
    }
}
