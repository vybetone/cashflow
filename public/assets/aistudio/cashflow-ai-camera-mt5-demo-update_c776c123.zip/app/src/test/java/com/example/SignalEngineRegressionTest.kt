package com.example

import com.example.data.GenuineMarketQuote
import com.example.data.MarketUniverse
import com.example.data.SignalEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/** Regression tests: close-only data cannot be promoted into fake OHLC patterns or price levels. */
class SignalEngineRegressionTest {
    private lateinit var signalEngine: SignalEngine

    @Before
    fun setUp() {
        signalEngine = SignalEngine()
    }

    @Test
    fun missingOrInvalidHistoryReturnsWaitWithNoTradeLevels() {
        val noHistory = signalEngine.generateSignal("BTC/USD", null)
        assertEquals("WAIT", noHistory.signalType)
        assertEquals(0, noHistory.confidencePercentage)
        assertEquals(0.0, noHistory.entryPrice, 0.0001)
        assertEquals(0.0, noHistory.stopLoss, 0.0001)
        assertEquals(0.0, noHistory.takeProfit, 0.0001)

        val invalid = signalEngine.generateSignal("EUR/USD", listOf(1.08, 1.09, 0.0, Double.NaN))
        assertEquals("WAIT", invalid.signalType)
        assertEquals(0, invalid.confidencePercentage)
        assertEquals(0.0, invalid.entryPrice, 0.0001)
    }

    @Test
    fun closeHistoryWithoutVerifiedQuoteCannotProduceActionableSignal() {
        val history = buildHistory()
        val signal = signalEngine.generateSignal("BTC/USD", history)
        assertEquals("WAIT", signal.signalType)
        assertEquals(0, signal.confidencePercentage)
        assertEquals(0.0, signal.entryPrice, 0.0001)
        assertTrue(signal.analysisReason.contains("Genuine quote required"))
    }

    @Test
    fun staleOrInvalidQuoteCannotProduceActionableSignal() {
        val history = buildHistory()
        val staleQuote = makeQuote(history).copy(isStale = true)
        val signal = signalEngine.generateSignal("BTC/USD", history, staleQuote)
        assertEquals("WAIT", signal.signalType)
        assertEquals(0, signal.confidencePercentage)
        assertEquals(0.0, signal.entryPrice, 0.0001)
    }

    @Test
    fun validQuoteNeverClaimsSyntheticCandlePattern() {
        val history = buildHistory()
        val quote = makeQuote(history)
        val signal = signalEngine.generateSignal("BTC/USD", history, quote)
        assertEquals("OHLC CANDLE PATTERN UNAVAILABLE", signal.candlePattern)
        assertFalse(signal.analysisReason.contains("BULLISH ENGULFING"))
        if (signal.signalType == "WAIT") {
            assertEquals(0.0, signal.entryPrice, 0.0001)
            assertEquals(0.0, signal.stopLoss, 0.0001)
            assertEquals(0.0, signal.takeProfit, 0.0001)
        } else {
            assertTrue(signal.entryPrice > 0.0)
            assertTrue(signal.stopLoss > 0.0)
            assertTrue(signal.takeProfit > 0.0)
            val risk = kotlin.math.abs(signal.entryPrice - signal.stopLoss)
            val reward = kotlin.math.abs(signal.takeProfit - signal.entryPrice)
            assertTrue(risk > 0.0)
            assertEquals(2.0, reward / risk, 0.02)
        }
    }

    @Test
    fun removedSyntheticPriceSeriesAlwaysReturnsEmptyList() {
        @Suppress("DEPRECATION")
        val prices = signalEngine.generatePriceSeriesForAsset(MarketUniverse.EUR_USD)
        assertTrue(prices.isEmpty())
    }

    private fun buildHistory(): List<Double> {
        var price = 64_000.0
        return (0 until 80).map { i ->
            price += when (i % 5) {
                0, 1, 2 -> 45.0
                3 -> -35.0
                else -> -25.0
            }
            price
        }
    }

    private fun makeQuote(history: List<Double>): GenuineMarketQuote {
        val asset = MarketUniverse.BTC_USD
        val last = history.last()
        return GenuineMarketQuote(
            asset = asset,
            lastPrice = last,
            bid = last - 1.0,
            ask = last + 1.0,
            spreadPipsOrPoints = 2.0,
            change24hPercent = 0.0,
            high24h = last + 500.0,
            low24h = last - 500.0,
            volume24h = "test fixture",
            rsi14 = 50.0,
            macdLine = 0.0,
            macdSignal = 0.0,
            macdHistogram = 0.0,
            ema20 = last,
            ema50 = last,
            ema200 = null,
            atr = 100.0,
            candlePattern = "OHLC unavailable in close-only fixture",
            supportLevel = last - 200.0,
            resistanceLevel = last + 200.0,
            orderFlowBias = "BALANCED_RANGE",
            recentCloses = history,
            lastUpdatedTimestamp = System.currentTimeMillis(),
            isBidAskEstimated = false,
            isStale = false
        )
    }
}
