package com.example.data

data class TradingSignal(
    val symbol: String = "UNKNOWN",
    val signalType: String = "WAIT", // "BUY", "SELL", "WAIT"
    val confidencePercentage: Int = 0, // Evidence/confluence score; not a win probability
    val entryPrice: Double = 0.0,
    val stopLoss: Double = 0.0,
    val takeProfit: Double = 0.0,
    val analysisReason: String = "No verified market data has been analyzed. Waiting for a genuine quote and valid history.",
    val timestamp: Long = System.currentTimeMillis(),
    val rsiValue: Double = 0.0,
    val macdSignal: String = "INSUFFICIENT DATA",
    val emaTrend: String = "INSUFFICIENT DATA",
    val candlePattern: String = "OHLC CANDLE PATTERN UNAVAILABLE",
    val momentumConfirmation: String = "NO DATA",
    val isStrongSignal: Boolean = confidencePercentage >= 90
)
