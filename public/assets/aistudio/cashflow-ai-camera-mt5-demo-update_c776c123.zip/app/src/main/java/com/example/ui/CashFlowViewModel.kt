package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.BrokerAccountEntity
import com.example.data.BrokerConnectionManager
import com.example.data.BrokerExecutionLog
import com.example.data.BrokerPosition
import com.example.data.BudgetEntity
import com.example.data.CashFlowRepository
import com.example.data.MarketAsset
import com.example.data.MarketCategory
import com.example.data.MarketUniverse
import com.example.data.SignalRepository
import com.example.data.TradingSignal
import com.example.data.TradeJournalEntity
import com.example.data.AssistantChatMessage
import com.example.data.GenuineMarketQuote
import com.example.data.MarketConnectionState
import com.example.data.RealMarketDataEngine
import com.example.data.TradingSignalEntity
import com.example.data.TransactionCategory
import com.example.data.TransactionEntity
import com.example.data.TransactionType
import com.example.data.ContinuousLearningDao
import com.example.data.SignalPerformanceOutcomeEntity
import com.example.data.ImprovementProposalEntity
import com.example.data.ObservationSource
import com.example.data.ProposalStatus
import com.example.data.RemoteConfigPayload
import com.example.data.QuantitativeEvaluationEngine
import com.example.data.EvaluationReport
import com.example.data.CandidateComparisonResult
import com.example.data.SecureRemoteConfigManager
import com.example.data.ConfigValidationResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class CashFlowViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CashFlowRepository
    private val aiSignalRepository: SignalRepository = SignalRepository()
    private val brokerConnectionManager: BrokerConnectionManager = BrokerConnectionManager(viewModelScope)
    private val marketDataEngine: RealMarketDataEngine = RealMarketDataEngine(viewModelScope)
    private val continuousLearningDao: ContinuousLearningDao
    private val evaluationEngine: QuantitativeEvaluationEngine = QuantitativeEvaluationEngine()
    private val remoteConfigManager: SecureRemoteConfigManager = SecureRemoteConfigManager()

    private val _activeRemoteConfig = MutableStateFlow(remoteConfigManager.getActiveConfig())
    val activeRemoteConfig: StateFlow<RemoteConfigPayload> = _activeRemoteConfig.asStateFlow()

    private val _evaluationReport = MutableStateFlow<EvaluationReport?>(null)
    val evaluationReport: StateFlow<EvaluationReport?> = _evaluationReport.asStateFlow()

    val allProposals: StateFlow<List<ImprovementProposalEntity>>
    val allPerformanceOutcomes: StateFlow<List<SignalPerformanceOutcomeEntity>>

    private val _evaluationStatusText = MutableStateFlow<String?>("Awaiting evaluation run")
    val evaluationStatusText: StateFlow<String?> = _evaluationStatusText.asStateFlow()

    private val _updateCheckStatusText = MutableStateFlow<String?>("Update status has not been verified.")
    val updateCheckStatusText: StateFlow<String?> = _updateCheckStatusText.asStateFlow()

    val liveMarketQuotes: StateFlow<Map<String, GenuineMarketQuote>> = marketDataEngine.marketQuotes
    val marketConnectionState: StateFlow<MarketConnectionState> = marketDataEngine.connectionState
    val isMarketDataLoading: StateFlow<Boolean> = marketDataEngine.isLoading
    val marketDataErrorMessage: StateFlow<String?> = marketDataEngine.lastErrorMessage

    fun refreshMarketData() {
        marketDataEngine.refreshNow()
    }

    val highConfidenceAiSignal: StateFlow<TradingSignal?> = aiSignalRepository.latestHighConfidenceSignal

    val allSignals: StateFlow<List<TradingSignalEntity>>
    val allJournalTrades: StateFlow<List<TradeJournalEntity>>
    val totalJournalPnL: StateFlow<Double?>
    val winCount: StateFlow<Int>
    val totalClosedTradesCount: StateFlow<Int>

    val allTransactions: StateFlow<List<TransactionEntity>>
    val allBudgets: StateFlow<List<BudgetEntity>>

    val allBrokerAccounts: StateFlow<List<BrokerAccountEntity>>
    val activeBrokerAccount: StateFlow<BrokerAccountEntity?>
    val brokerConnectionStatus: StateFlow<String> = brokerConnectionManager.connectionStatus
    val brokerPingMs: StateFlow<Long> = brokerConnectionManager.currentPingMs
    val openBrokerPositions: StateFlow<List<BrokerPosition>> = brokerConnectionManager.openPositions
    val brokerExecutionLogs: StateFlow<List<BrokerExecutionLog>> = brokerConnectionManager.executionLogs

    private val _brokerFeedbackMessage = MutableStateFlow<String?>(null)
    val brokerFeedbackMessage: StateFlow<String?> = _brokerFeedbackMessage.asStateFlow()

    fun clearBrokerFeedbackMessage() {
        _brokerFeedbackMessage.value = null
    }

    // Confirmed Trade Universe (1 FOREX, 2 GOLD, 3 CRYPTO, 4 STOCKS, 5 ALL OF THEM)
    private val _selectedMarketCategory = MutableStateFlow(MarketCategory.ALL_MARKETS)
    val selectedMarketCategory: StateFlow<MarketCategory> = _selectedMarketCategory.asStateFlow()

    private val _selectedMarketAsset = MutableStateFlow(MarketUniverse.EUR_USD)
    val selectedMarketAsset: StateFlow<MarketAsset> = _selectedMarketAsset.asStateFlow()

    private val _autoTradeMarketUniverse = MutableStateFlow(MarketCategory.ALL_MARKETS)
    val autoTradeMarketUniverse: StateFlow<MarketCategory> = _autoTradeMarketUniverse.asStateFlow()

    fun setMarketCategory(category: MarketCategory) {
        _selectedMarketCategory.value = category
        val categoryAssets = MarketUniverse.getAssetsForCategory(category)
        if (categoryAssets.isNotEmpty() && _selectedMarketAsset.value !in categoryAssets) {
            _selectedMarketAsset.value = categoryAssets.first()
        }
    }

    fun setSelectedMarketAsset(asset: MarketAsset) {
        _selectedMarketAsset.value = asset
        _selectedMarketCategory.value = asset.category
        recalculateHighConfidenceSignal(asset.symbol)
    }

    fun setAutoTradeMarketUniverse(category: MarketCategory) {
        _autoTradeMarketUniverse.value = category
        val account = activeBrokerAccount.value
        if (account != null) {
            _brokerFeedbackMessage.value = "Auto-Trade filter updated: ${category.badgeLabel}"
        }
    }

    val currentMarketQuote: StateFlow<GenuineMarketQuote> = combine(
        marketDataEngine.marketQuotes,
        _selectedMarketAsset
    ) { quotes, asset ->
        quotes[asset.symbol] ?: marketDataEngine.getQuoteForSymbol(asset.symbol)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        marketDataEngine.getQuoteForSymbol("EUR/USD")
    )

    private val _latestEvidenceSignal = MutableStateFlow<TradingSignalEntity?>(null)
    val latestEvidenceSignal: StateFlow<TradingSignalEntity?> = _latestEvidenceSignal.asStateFlow()

    private val _isAiAssistantRunning = MutableStateFlow(false)
    val isAiAssistantRunning: StateFlow<Boolean> = _isAiAssistantRunning.asStateFlow()

    private val _aiAssistantStatusText = MutableStateFlow<String?>("Ready for Gemini quantitative analysis")
    val aiAssistantStatusText: StateFlow<String?> = _aiAssistantStatusText.asStateFlow()

    private val _assistantChatMessages = MutableStateFlow<List<AssistantChatMessage>>(
        listOf(
            AssistantChatMessage(
                isUser = false,
                text = "👋 Welcome to CASH FLOW AI Real Trading Assistant!\n\nI monitor genuine live market telemetry across:\n1 FOREX (EUR/USD, GBP/USD, USD/JPY)\n2 GOLD (XAU/USD)\n3 CRYPTO (BTC/USD, ETH/USD)\n4 STOCKS (NVIDIA, TESLA, APPLE)\n5 ALL OF THEM\n\nTap 'GENERATE EVIDENCE-BASED SIGNAL' to run quantitative Gemini AI confluence reasoning on live market data, or ask me any question. High-probability setups can be executed directly to your connected broker API."
            )
        )
    )
    val assistantChatMessages: StateFlow<List<AssistantChatMessage>> = _assistantChatMessages.asStateFlow()

    private val _selectedTab = MutableStateFlow(0)
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _signalFilter = MutableStateFlow("ALL") // "ALL", "BUY", "SELL", "WAIT"
    val signalFilter: StateFlow<String> = _signalFilter.asStateFlow()

    private val _isAnalyzingChart = MutableStateFlow(false)
    val isAnalyzingChart: StateFlow<Boolean> = _isAnalyzingChart.asStateFlow()

    private val _chartFrameStatusText = MutableStateFlow("Ready. Capture a real chart frame before analysis.")
    val chartFrameStatusText: StateFlow<String> = _chartFrameStatusText.asStateFlow()

    fun reportChartFrameError(message: String) {
        _chartFrameStatusText.value = message
    }

    private val _latestActiveSignal = MutableStateFlow<TradingSignalEntity?>(null)
    val latestActiveSignal: StateFlow<TradingSignalEntity?> = _latestActiveSignal.asStateFlow()

    private val _appThemeMode = MutableStateFlow(com.example.ui.theme.AppThemeMode.DARK)
    val appThemeMode: StateFlow<com.example.ui.theme.AppThemeMode> = _appThemeMode.asStateFlow()

    fun setAppThemeMode(mode: com.example.ui.theme.AppThemeMode) {
        _appThemeMode.value = mode
    }

    private val _preferredModel = MutableStateFlow("gemini-3.5-flash")
    val preferredModel: StateFlow<String> = _preferredModel.asStateFlow()

    private val _autoCaptureIntervalSeconds = MutableStateFlow(5)
    val autoCaptureIntervalSeconds: StateFlow<Int> = _autoCaptureIntervalSeconds.asStateFlow()

    private val _isScreenCaptureActive = MutableStateFlow(false)
    val isScreenCaptureActive: StateFlow<Boolean> = _isScreenCaptureActive.asStateFlow()

    private val _showAddJournalDialog = MutableStateFlow(false)
    val showAddJournalDialog: StateFlow<Boolean> = _showAddJournalDialog.asStateFlow()

    private val _selectedTypeFilter = MutableStateFlow<TransactionType?>(null)
    val selectedTypeFilter: StateFlow<TransactionType?> = _selectedTypeFilter.asStateFlow()

    private val _selectedCategoryFilter = MutableStateFlow<TransactionCategory?>(null)
    val selectedCategoryFilter: StateFlow<TransactionCategory?> = _selectedCategoryFilter.asStateFlow()

    private val _showAddTransactionSheet = MutableStateFlow(false)
    val showAddTransactionSheet: StateFlow<Boolean> = _showAddTransactionSheet.asStateFlow()

    private val _transactionToEdit = MutableStateFlow<TransactionEntity?>(null)
    val transactionToEdit: StateFlow<TransactionEntity?> = _transactionToEdit.asStateFlow()

    private val _showAddBudgetDialog = MutableStateFlow(false)
    val showAddBudgetDialog: StateFlow<Boolean> = _showAddBudgetDialog.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application)
        continuousLearningDao = database.continuousLearningDao()
        repository = CashFlowRepository(
            tradingSignalDao = database.tradingSignalDao(),
            tradeJournalDao = database.tradeJournalDao(),
            transactionDao = database.transactionDao(),
            budgetDao = database.budgetDao(),
            brokerAccountDao = database.brokerAccountDao()
        )

        allProposals = continuousLearningDao.getAllProposals().stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        allPerformanceOutcomes = continuousLearningDao.getAllOutcomes().stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        allBrokerAccounts = repository.allBrokerAccounts.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        activeBrokerAccount = repository.activeBrokerAccount.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            null
        )

        // Only analyze genuine MediaProjection frames. Capture failures are surfaced to the UI.
        com.example.data.ScreenCaptureService.onFrameCapturedListener = { bitmap ->
            processChartFrameBitmap(bitmap, "SCREEN_ANALYSIS")
        }
        com.example.data.ScreenCaptureService.onFrameCaptureErrorListener = { message ->
            if (message.contains("could not initialize", true) || message.contains("permission data is missing", true) || message.contains("failed to start", true)) {
                _isScreenCaptureActive.value = false
            }
            _chartFrameStatusText.value = message
        }

        viewModelScope.launch {
            // Persisted connection flags are not proof of a live broker session. Clear them on startup.
            repository.disableBrokerConnectionsAndAutoTrading()
        }

        brokerConnectionManager.onAccountUpdated = { updatedAcc ->
            viewModelScope.launch {
                repository.updateBrokerAccount(updatedAcc)
            }
        }

        allSignals = repository.allSignals.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        allJournalTrades = repository.allJournalTrades.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        totalJournalPnL = repository.totalJournalPnL.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            0.0
        )

        winCount = repository.winCount.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            0
        )

        totalClosedTradesCount = repository.totalClosedTradesCount.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            0
        )

        allTransactions = repository.allTransactions.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        allBudgets = repository.allBudgets.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        // Initialize local notification channel for high-confidence AI signals
        com.example.data.SignalNotificationManager.createNotificationChannel(application)
    }

    val filteredSignals: StateFlow<List<TradingSignalEntity>> = combine(
        allSignals,
        _searchQuery,
        _signalFilter,
        _selectedMarketCategory
    ) { signals, query, actionFilter, marketCat ->
        val allowedSymbols = if (marketCat == MarketCategory.ALL_MARKETS) {
            null
        } else {
            MarketUniverse.getAssetsForCategory(marketCat).map { it.symbol.uppercase() }
        }
        signals.filter { sig ->
            val sigSymbolUpper = sig.symbol.uppercase()
            val matchesCategory = allowedSymbols == null || allowedSymbols.any { 
                sigSymbolUpper.contains(it) || it.contains(sigSymbolUpper)
            }
            val matchesQuery = query.isBlank() ||
                    sig.symbol.contains(query, ignoreCase = true) ||
                    sig.reasoning.contains(query, ignoreCase = true) ||
                    sig.detectedPatterns.contains(query, ignoreCase = true)
            val matchesAction = actionFilter == "ALL" || sig.action.equals(actionFilter, ignoreCase = true)
            matchesCategory && matchesQuery && matchesAction
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredTransactions: StateFlow<List<TransactionEntity>> = combine(
        allTransactions,
        _searchQuery,
        _selectedTypeFilter,
        _selectedCategoryFilter
    ) { transactions, query, typeFilter, categoryFilter ->
        transactions.filter { tx ->
            val matchesQuery = query.isBlank() ||
                    tx.title.contains(query, ignoreCase = true) ||
                    tx.note.contains(query, ignoreCase = true) ||
                    tx.category.displayName.contains(query, ignoreCase = true)
            val matchesType = typeFilter == null || tx.type == typeFilter
            val matchesCategory = categoryFilter == null || tx.category == categoryFilter
            matchesQuery && matchesType && matchesCategory
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalIncome: StateFlow<Double> = allTransactions.combine(MutableStateFlow(Unit)) { txs, _ ->
        txs.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalExpense: StateFlow<Double> = allTransactions.combine(MutableStateFlow(Unit)) { txs, _ ->
        txs.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun setSelectedTab(tabIndex: Int) {
        _selectedTab.value = tabIndex
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSignalFilter(filter: String) {
        _signalFilter.value = filter
    }

    fun setPreferredModel(model: String) {
        _preferredModel.value = model
    }

    fun setAutoCaptureInterval(seconds: Int) {
        _autoCaptureIntervalSeconds.value = seconds.coerceIn(1, 60)
        com.example.data.ScreenCaptureService.updateScanIntervalMs(_autoCaptureIntervalSeconds.value * 1000L)
    }

    fun startScreenCaptureService(context: android.content.Context, resultCode: Int = -1, data: android.content.Intent? = null) {
        if (resultCode == android.app.Activity.RESULT_OK && data != null) {
            _chartFrameStatusText.value = "Starting real screen capture…"
            try {
                _isScreenCaptureActive.value = com.example.data.ScreenCaptureService.startService(context, resultCode, data)
            } catch (e: Exception) {
                _isScreenCaptureActive.value = false
                _chartFrameStatusText.value = "Screen capture failed to start: ${e.localizedMessage ?: "permission or service error"}"
            }
        } else {
            _isScreenCaptureActive.value = false
            _chartFrameStatusText.value = "Screen capture permission was not granted. No synthetic frame was generated."
        }
    }

    fun stopScreenCaptureService(context: android.content.Context) {
        _isScreenCaptureActive.value = false
        com.example.data.ScreenCaptureService.stopService(context)
        _chartFrameStatusText.value = "Screen capture stopped. No new frames are being analyzed."
    }

    fun onMediaProjectionGranted(context: android.content.Context, resultCode: Int, data: android.content.Intent?) {
        startScreenCaptureService(context, resultCode, data)
    }

    fun onMediaProjectionDenied() {
        _isScreenCaptureActive.value = false
        _chartFrameStatusText.value = "Screen capture permission denied. No synthetic frame was generated."
    }

    fun toggleScreenCaptureService(context: android.content.Context) {
        if (_isScreenCaptureActive.value) stopScreenCaptureService(context)
        else reportChartFrameError("Grant Android screen-capture permission from the Screen Analysis control before starting capture.")
    }

    fun scanAllConfirmedMarkets() {
        viewModelScope.launch {
            _isAnalyzingChart.value = true
            try {
                val assetsToScan = if (_selectedMarketCategory.value == MarketCategory.ALL_MARKETS) {
                    MarketUniverse.allAssets
                } else {
                    MarketUniverse.getAssetsForCategory(_selectedMarketCategory.value)
                }

                val engine = aiSignalRepository.getEngine()
                var persistedCount = 0
                assetsToScan.forEach { asset ->
                    val quote = marketDataEngine.getQuoteForSymbol(asset.symbol)
                    val quoteAgeMs = if (quote.lastUpdatedTimestamp > 0L) System.currentTimeMillis() - quote.lastUpdatedTimestamp else Long.MAX_VALUE
                    val isFresh = !quote.isStale && quote.lastPrice > 0.0 && quote.lastPrice.isFinite() &&
                        quote.lastUpdatedTimestamp > 0L && quoteAgeMs in -300_000L..300_000L &&
                        quote.atr > 0.0 && quote.atr.isFinite()

                    val isHistoryValid = isFresh && quote.recentCloses.size >= 50 &&
                        quote.recentCloses.all { it > 0.0 && it.isFinite() }

                    val priceHistory = if (isHistoryValid) quote.recentCloses else null
                    val sig = engine.generateSignal(asset.symbol, priceHistory, quote.takeIf { isHistoryValid })

                    // Prevent batch scanning from persisting an actionable signal when market history is absent, stale, or invalid
                    val riskDistance = kotlin.math.abs(sig.entryPrice - sig.stopLoss)
                    val rewardDistance = kotlin.math.abs(sig.takeProfit - sig.entryPrice)
                    val rewardRisk = if (riskDistance > 0.0) rewardDistance / riskDistance else 0.0
                    if (isHistoryValid && sig.signalType != "WAIT" && sig.confidencePercentage > 0 &&
                        sig.entryPrice > 0.0 && sig.stopLoss > 0.0 && sig.takeProfit > 0.0 && rewardRisk >= 2.0) {
                        val entity = TradingSignalEntity(
                            timestamp = System.currentTimeMillis(),
                            symbol = sig.symbol,
                            timeframe = "15m",
                            action = sig.signalType,
                            confidenceScore = sig.confidencePercentage,
                            reasoning = sig.analysisReason,
                            entryZone = if (asset.decimalDigits == 4) String.format(java.util.Locale.US, "%.4f", sig.entryPrice) else String.format(java.util.Locale.US, "$%.2f", sig.entryPrice),
                            stopLoss = if (asset.decimalDigits == 4) String.format(java.util.Locale.US, "%.4f", sig.stopLoss) else String.format(java.util.Locale.US, "$%.2f", sig.stopLoss),
                            takeProfit = if (asset.decimalDigits == 4) String.format(java.util.Locale.US, "%.4f", sig.takeProfit) else String.format(java.util.Locale.US, "$%.2f", sig.takeProfit),
                            riskRewardRatio = String.format(java.util.Locale.US, "1:%.2f", rewardRisk),
                            trendDirection = if (sig.signalType == "SELL") "BEARISH" else "BULLISH",
                            detectedPatterns = sig.candlePattern,
                            keyLevels = "ATR-based stop: ${sig.stopLoss} | ATR-based target: ${sig.takeProfit} | Market: ${asset.category.shortName}",
                            source = "SCAN_CONFIRMED_MARKETS"
                        )
                        repository.insertSignal(entity)
                        persistedCount++

                        // If auto-trading is enabled for this category, execute
                        val broker = activeBrokerAccount.value
                        val allowed = when (_autoTradeMarketUniverse.value) {
                            MarketCategory.ALL_MARKETS -> true
                            MarketCategory.FOREX -> asset.category == MarketCategory.FOREX
                            MarketCategory.GOLD -> asset.category == MarketCategory.GOLD
                            MarketCategory.CRYPTO -> asset.category == MarketCategory.CRYPTO
                            MarketCategory.STOCKS -> asset.category == MarketCategory.STOCKS
                        }
                        if (broker != null && broker.autoTradeEnabled && broker.isConnected && allowed && entity.action != "WAIT" && entity.confidenceScore >= broker.minConfidenceThreshold) {
                            executeSignalOnBroker(entity)
                        }
                    }
                }
                _brokerFeedbackMessage.value = if (persistedCount > 0) {
                    "Scanned ${assetsToScan.size} instruments across ${_selectedMarketCategory.value.shortName}. Generated $persistedCount verified signals."
                } else {
                    "Scanned ${assetsToScan.size} instruments across ${_selectedMarketCategory.value.shortName}. No actionable signals on available market data."
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isAnalyzingChart.value = false
            }
        }
    }

    fun processChartFrameBitmap(
        bitmap: Bitmap,
        source: String = "SCREEN_ANALYSIS",
        asset: MarketAsset? = null
    ) {
        val targetAsset = asset ?: _selectedMarketAsset.value
        if (bitmap.isRecycled || bitmap.width <= 0 || bitmap.height <= 0) {
            _chartFrameStatusText.value = "Chart frame is empty or invalid. Capture another real frame."
            return
        }
        if (_isAnalyzingChart.value) {
            _chartFrameStatusText.value = "Frame skipped because a previous chart analysis is still running."
            if (!bitmap.isRecycled) bitmap.recycle()
            return
        }
        _isAnalyzingChart.value = true
        viewModelScope.launch {
            _chartFrameStatusText.value = "Analyzing captured ${source.lowercase().replace('_', ' ')} frame…"
            try {
                val newSignal = repository.analyzeAndSaveSignal(
                    bitmap = bitmap,
                    context = getApplication(),
                    source = source,
                    preferredModel = _preferredModel.value,
                    targetAsset = targetAsset
                )
                _latestActiveSignal.value = newSignal
                _chartFrameStatusText.value = if (newSignal.symbol == "ANALYSIS_FAILED" || newSignal.reasoning.contains("AI ANALYSIS UNAVAILABLE", true)) {
                    "Analysis unavailable: ${newSignal.reasoning}"
                } else {
                    "Analysis completed: ${newSignal.action} (${newSignal.confidenceScore}% confluence)."
                }

                if (newSignal.confidenceScore >= 70 || newSignal.action != "WAIT") {
                    com.example.data.SignalNotificationManager.sendSignalNotification(
                        getApplication(),
                        newSignal
                    )
                }
                // Broker execution stays disabled until a verified MT5 terminal bridge is installed.
            } catch (e: Exception) {
                _chartFrameStatusText.value = "Chart analysis failed: ${e.localizedMessage ?: "analysis service unavailable"}. No signal was confirmed."
            } finally {
                _isAnalyzingChart.value = false
                if (!bitmap.isRecycled) bitmap.recycle()
            }
        }
    }

    fun deleteSignal(signal: TradingSignalEntity) {
        viewModelScope.launch {
            repository.deleteSignal(signal.id)
        }
    }

    fun convertSignalToJournalEntry(signal: TradingSignalEntity) {
        _brokerFeedbackMessage.value = "Signal ${signal.symbol} not added as an open trade: an AI recommendation is not a broker fill. Record a journal trade only after confirming an actual entry and position size."
    }

    fun recalculateHighConfidenceSignal(symbol: String = "BTC/USD") {
        viewModelScope.launch {
            val quote = marketDataEngine.getQuoteForSymbol(symbol)
            val quoteAgeMs = if (quote.lastUpdatedTimestamp > 0L) System.currentTimeMillis() - quote.lastUpdatedTimestamp else Long.MAX_VALUE
            val isHistoryValid = !quote.isStale && quote.lastPrice > 0.0 && quote.lastPrice.isFinite() &&
                quote.lastUpdatedTimestamp > 0L && quoteAgeMs in -300_000L..300_000L &&
                quote.atr > 0.0 && quote.atr.isFinite() && quote.recentCloses.size >= 50 &&
                quote.recentCloses.all { it > 0.0 && it.isFinite() }
            val priceHistory = if (isHistoryValid) quote.recentCloses else null
            aiSignalRepository.generateSignal(symbol, priceHistory, quote.takeIf { isHistoryValid })
        }
    }

    fun convertAiSignalToJournalEntry(signal: TradingSignal) {
        if (signal.signalType == "WAIT" || signal.confidencePercentage <= 0) return
        _brokerFeedbackMessage.value = "Signal not added as an open trade: no verified broker fill exists. Record actual execution details manually after a real trade is confirmed."
    }

    fun saveJournalTrade(
        symbol: String,
        tradeType: String,
        entryPrice: Double,
        exitPrice: Double?,
        stopLoss: Double,
        takeProfit: Double,
        positionSize: Double,
        status: String,
        notes: String
    ) {
        viewModelScope.launch {
            val pnl = if (status.startsWith("CLOSED") && exitPrice != null) {
                if (tradeType == "BUY") (exitPrice - entryPrice) * positionSize else (entryPrice - exitPrice) * positionSize
            } else 0.0

            val trade = TradeJournalEntity(
                assetSymbol = symbol.trim().ifEmpty { "CUSTOM_ASSET" },
                tradeType = tradeType,
                entryPrice = entryPrice,
                exitPrice = exitPrice,
                stopLoss = stopLoss,
                takeProfit = takeProfit,
                positionSize = positionSize,
                status = status,
                pnl = pnl,
                notes = notes.trim()
            )
            repository.insertJournalTrade(trade)
            _showAddJournalDialog.value = false
        }
    }

    fun deleteJournalTrade(trade: TradeJournalEntity) {
        viewModelScope.launch {
            repository.deleteJournalTrade(trade.id)
        }
    }

    fun openAddJournalDialog() {
        _showAddJournalDialog.value = true
    }

    fun closeAddJournalDialog() {
        _showAddJournalDialog.value = false
    }

    fun setTypeFilter(type: TransactionType?) {
        _selectedTypeFilter.value = type
    }

    fun setCategoryFilter(category: TransactionCategory?) {
        _selectedCategoryFilter.value = category
    }

    fun openAddTransactionSheet(tx: TransactionEntity? = null) {
        _transactionToEdit.value = tx
        _showAddTransactionSheet.value = true
    }

    fun closeAddTransactionSheet() {
        _showAddTransactionSheet.value = false
        _transactionToEdit.value = null
    }

    fun openAddBudgetDialog() {
        _showAddBudgetDialog.value = true
    }

    fun closeAddBudgetDialog() {
        _showAddBudgetDialog.value = false
    }

    fun saveTransaction(
        title: String,
        amount: Double,
        type: TransactionType,
        category: TransactionCategory,
        note: String,
        isRecurring: Boolean
    ) {
        if (title.isBlank() || amount <= 0.0) return
        viewModelScope.launch {
            val existing = _transactionToEdit.value
            if (existing != null) {
                repository.updateTransaction(
                    existing.copy(
                        title = title.trim(),
                        amount = amount,
                        type = type,
                        category = category,
                        note = note.trim(),
                        isRecurring = isRecurring
                    )
                )
            } else {
                repository.insertTransaction(
                    TransactionEntity(
                        title = title.trim(),
                        amount = amount,
                        type = type,
                        category = category,
                        note = note.trim(),
                        isRecurring = isRecurring
                    )
                )
            }
            closeAddTransactionSheet()
        }
    }

    fun deleteTransaction(tx: TransactionEntity) {
        viewModelScope.launch {
            repository.deleteTransaction(tx)
        }
    }

    fun saveBudget(category: TransactionCategory, monthlyLimit: Double) {
        if (monthlyLimit <= 0.0) return
        viewModelScope.launch {
            repository.saveBudget(
                BudgetEntity(
                    category = category,
                    monthlyLimit = monthlyLimit
                )
            )
            closeAddBudgetDialog()
        }
    }

    // --- BROKER CONNECTION & EXECUTION CONTROLS ---

    fun connectBroker(account: BrokerAccountEntity) {
        viewModelScope.launch {
            repository.setActiveBroker(account.id)
            brokerConnectionManager.connect(account) { success, msg ->
                _brokerFeedbackMessage.value = msg
            }
        }
    }

    fun disconnectBroker() {
        viewModelScope.launch {
            repository.disableBrokerConnectionsAndAutoTrading()
            brokerConnectionManager.disconnect()
            _brokerFeedbackMessage.value = "Disconnected from active broker."
        }
    }

    fun testBrokerPing(account: BrokerAccountEntity) {
        brokerConnectionManager.testPing(account) { ping ->
            _brokerFeedbackMessage.value = if (ping >= 0L) "Verified broker response: ${ping}ms" else "No real ping performed: ${account.brokerType} has no verified adapter configured."
        }
    }

    fun saveBrokerAccount(account: BrokerAccountEntity) {
        viewModelScope.launch {
            // Saving credentials is not proof of a broker session. Keep connection/automation off.
            val safeAccount = account.copy(isConnected = false, autoTradeEnabled = false, lastPingMs = 0L)
            if (safeAccount.id > 0) {
                repository.updateBrokerAccount(safeAccount)
            } else {
                repository.insertBrokerAccount(safeAccount)
            }
            _brokerFeedbackMessage.value = "Broker account '${safeAccount.accountName}' saved as unverified. No connection or order was established."
        }
    }

    fun deleteBrokerAccount(account: BrokerAccountEntity) {
        viewModelScope.launch {
            if (account.isConnected) {
                brokerConnectionManager.disconnect()
            }
            repository.deleteBrokerAccount(account)
            _brokerFeedbackMessage.value = "Broker account removed."
        }
    }

    fun toggleBrokerAutoTrade(enabled: Boolean) {
        if (enabled) {
            _brokerFeedbackMessage.value = "Auto-trading remains disabled: a verified MT5 terminal bridge and demo-account execution tests are required first. No order was sent."
            return
        }
        viewModelScope.launch {
            repository.disableBrokerConnectionsAndAutoTrading()
            brokerConnectionManager.disconnect()
            _brokerFeedbackMessage.value = "Auto-trading paused. No verified broker adapter is active."
        }
    }

    fun updateBrokerRiskSettings(
        threshold: Int,
        lotSize: Double,
        maxRisk: Double,
        autoSlTp: Boolean,
        dailyLossLimit: Double? = null
    ) {
        viewModelScope.launch {
            val current = activeBrokerAccount.value
            if (current != null) {
                val updated = current.copy(
                    minConfidenceThreshold = threshold.coerceIn(50, 99),
                    defaultLotSize = lotSize.coerceAtLeast(0.01),
                    maxRiskPercentage = maxRisk.coerceIn(0.1, 10.0),
                    autoStopLossTakeProfit = autoSlTp,
                    dailyLossLimit = (dailyLossLimit ?: current.dailyLossLimit).coerceAtLeast(10.0)
                )
                repository.updateBrokerAccount(updated)
                _brokerFeedbackMessage.value = "Broker risk parameters updated."
            }
        }
    }

    fun resetBrokerDailyLossCircuitBreaker() {
        brokerConnectionManager.resetDailyLoss("Manual UI Reset")
        _brokerFeedbackMessage.value = "Daily-loss circuit breaker reset."
    }

    fun executeSignalOnBroker(signal: TradingSignalEntity, overrideVolume: Double? = null) {
        if (signal.action != "BUY" && signal.action != "SELL") {
            _brokerFeedbackMessage.value = "Execution rejected: Signal action is '${signal.action}'. Only BUY or SELL can be executed."
            return
        }

        val active = activeBrokerAccount.value
        if (active == null || !active.isConnected || !brokerConnectionStatus.value.startsWith("CONNECTED")) {
            _brokerFeedbackMessage.value = "Execution rejected: no verified broker session is active. MT5 demo bridge integration is required; no order was sent."
            return
        }
        if (active.dailyLossLimit > 0.0 && (active.isCircuitBreakerTripped || active.dailyRealizedLoss >= active.dailyLossLimit)) {
            _brokerFeedbackMessage.value = "Execution rejected: Daily-loss circuit breaker is active for ${active.brokerType} (Realized loss: $${String.format(java.util.Locale.US, "%.2f", active.dailyRealizedLoss)} >= Limit: $${String.format(java.util.Locale.US, "%.2f", active.dailyLossLimit)}). Trading halted for current session."
            return
        }

        val quote = marketDataEngine.getQuoteForSymbol(signal.symbol)
        val isQuoteValid = !quote.isStale &&
            quote.lastPrice > 0.0 &&
            quote.lastUpdatedTimestamp > 0L &&
            (System.currentTimeMillis() - quote.lastUpdatedTimestamp) <= 300_000L

        if (!isQuoteValid) {
            _brokerFeedbackMessage.value = "Execution rejected: Market data for ${signal.symbol} is stale or unavailable."
            return
        }

        val entryPrice = parseValidPriceOrNull(signal.entryZone)
        if (entryPrice == null) {
            _brokerFeedbackMessage.value = "Execution rejected: Invalid or unparseable entry price (${signal.entryZone})."
            return
        }

        val volume = overrideVolume ?: active.defaultLotSize
        val slPrice = parseValidPriceOrNull(signal.stopLoss)
        val tpPrice = parseValidPriceOrNull(signal.takeProfit)
        if (slPrice == null || tpPrice == null) {
            _brokerFeedbackMessage.value = "Execution rejected: stop-loss or take-profit is missing or unreadable. No levels were invented."
            return
        }

        brokerConnectionManager.executeTrade(
            symbol = signal.symbol,
            side = signal.action,
            entryPrice = entryPrice,
            stopLoss = slPrice,
            takeProfit = tpPrice,
            volume = volume,
            sourceSignalId = signal.id
        ) { success, msg, position ->
            _brokerFeedbackMessage.value = msg
            if (success && position != null) {
                // Record to Trade Journal automatically
                viewModelScope.launch {
                    val trade = TradeJournalEntity(
                        signalId = signal.id,
                        assetSymbol = signal.symbol,
                        tradeType = if (signal.action == "SELL") "SELL" else "BUY",
                        entryPrice = entryPrice,
                        exitPrice = null,
                        stopLoss = slPrice,
                        takeProfit = tpPrice,
                        positionSize = volume,
                        status = "OPEN",
                        pnl = 0.0,
                        notes = "Broker Execution on ${position.brokerType} [Ticket #${position.ticketId}] | Pattern: ${signal.detectedPatterns}",
                        screenshotPath = signal.imageUri,
                        chartPattern = signal.detectedPatterns
                    )
                    repository.insertJournalTrade(trade)
                }
            }
        }
    }

    fun executeManualTrade(symbol: String, side: String, entryPrice: Double, sl: Double, tp: Double, volume: Double) {
        val active = activeBrokerAccount.value
        if (active == null || !active.isConnected || !brokerConnectionStatus.value.startsWith("CONNECTED")) {
            _brokerFeedbackMessage.value = "Manual order rejected: no verified broker session is active. No order was sent."
            return
        }
        if (active.dailyLossLimit > 0.0 && (active.isCircuitBreakerTripped || active.dailyRealizedLoss >= active.dailyLossLimit)) {
            _brokerFeedbackMessage.value = "Execution rejected: Daily-loss circuit breaker is active for ${active.brokerType}."
            return
        }

        brokerConnectionManager.executeTrade(
            symbol = symbol,
            side = side,
            entryPrice = entryPrice,
            stopLoss = sl,
            takeProfit = tp,
            volume = volume
        ) { success, msg, position ->
            _brokerFeedbackMessage.value = msg
            if (success && position != null) {
                viewModelScope.launch {
                    val trade = TradeJournalEntity(
                        assetSymbol = symbol,
                        tradeType = side.uppercase(),
                        entryPrice = entryPrice,
                        exitPrice = null,
                        stopLoss = sl,
                        takeProfit = tp,
                        positionSize = volume,
                        status = "OPEN",
                        pnl = 0.0,
                        notes = "Manual order on ${position.brokerType} [Ticket #${position.ticketId}]"
                    )
                    repository.insertJournalTrade(trade)
                }
            }
        }
    }

    fun closeBrokerPosition(ticketId: String) {
        brokerConnectionManager.closePosition(ticketId) { success, pnl ->
            val pnlFormatted = if (pnl >= 0) "+$${String.format(java.util.Locale.US, "%.2f", pnl)}" else "-$${String.format(java.util.Locale.US, "%.2f", Math.abs(pnl))}"
            _brokerFeedbackMessage.value = if (success) "Position #$ticketId closed. P&L: $pnlFormatted" else "Position close failed."
            if (success) {
                viewModelScope.launch {
                    val openTrades = allJournalTrades.value
                    val matching = openTrades.find { it.notes.contains(ticketId) && it.status == "OPEN" }
                    if (matching != null) {
                        val closedStatus = if (pnl >= 0) "CLOSED_WIN" else "CLOSED_LOSS"
                        val updated = matching.copy(
                            status = closedStatus,
                            pnl = pnl,
                            notes = matching.notes + " | Closed: $pnlFormatted"
                        )
                        repository.updateJournalTrade(updated)
                    }
                }
            }
        }
    }

    fun closeAllBrokerPositions() {
        brokerConnectionManager.closeAllPositions { count, totalPnL ->
            val pnlFormatted = if (totalPnL >= 0) "+$${String.format(java.util.Locale.US, "%.2f", totalPnL)}" else "-$${String.format(java.util.Locale.US, "%.2f", Math.abs(totalPnL))}"
            _brokerFeedbackMessage.value = "Closed all $count positions. Net P&L: $pnlFormatted"
        }
    }

    // --- REAL TRADING ASSISTANT & EVIDENCE-BASED SIGNAL ENGINE ---

    fun runAiMarketAnalysis(symbol: String? = null, userNotes: String? = null) {
        val targetSymbol = symbol ?: _selectedMarketAsset.value.symbol
        val asset = MarketUniverse.findAssetBySymbol(targetSymbol)
        val quote = marketDataEngine.getQuoteForSymbol(asset.symbol)

        if (quote.isStale || quote.lastPrice <= 0.0 || quote.lastUpdatedTimestamp <= 0L || (System.currentTimeMillis() - quote.lastUpdatedTimestamp) > 300_000L) {
            _aiAssistantStatusText.value = "Market data stale or offline for ${asset.symbol}. Analysis blocked."
            _brokerFeedbackMessage.value = "Signal generation blocked: ${asset.symbol} quote is stale or offline."
            val waitSignal = TradingSignalEntity(
                timestamp = System.currentTimeMillis(),
                symbol = asset.symbol,
                timeframe = "15m",
                action = "WAIT",
                confidenceScore = 0,
                reasoning = "Market data for ${asset.symbol} is stale or offline. Actionable signals and orders are strictly blocked.",
                entryZone = "N/A",
                stopLoss = "N/A",
                takeProfit = "N/A",
                riskRewardRatio = "0:0",
                trendDirection = "NEUTRAL",
                detectedPatterns = "DATA STALE / OFFLINE",
                keyLevels = "Unavailable",
                source = "AI_EVIDENCE_ANALYSIS"
            )
            _latestEvidenceSignal.value = waitSignal
            return
        }

        viewModelScope.launch {
            _isAiAssistantRunning.value = true
            _aiAssistantStatusText.value = "Auditing live ${asset.symbol} telemetry with Gemini AI..."
            try {
                val broker = activeBrokerAccount.value
                val brokerCtx = broker?.let { "${it.brokerType} (${it.environment}) | Default Lot: ${it.defaultLotSize}" }
                val signal = repository.analyzeMarketQuoteAndSaveSignal(
                    quote = quote,
                    userInstructions = userNotes,
                    preferredModel = _preferredModel.value,
                    brokerContext = brokerCtx
                )
                _latestEvidenceSignal.value = signal
                _aiAssistantStatusText.value = "Signal Generated: ${signal.action} (${signal.confidenceScore}% Confluence)"

                // Add to Assistant Chat history
                val chatSummary = buildString {
                    append("🎯 **${signal.action} ${signal.symbol}** (${signal.confidenceScore}% Confluence)\n\n")
                    append("• **Entry:** ${signal.entryZone} | **SL:** ${signal.stopLoss} | **TP:** ${signal.takeProfit} (R:R ${signal.riskRewardRatio})\n")
                    append("• **Key Patterns:** ${signal.detectedPatterns}\n")
                    append("• **Confluence Proof:** ${signal.reasoning}\n\n")
                    append("Execution is disabled until a verified broker adapter and MT5 demo bridge are connected and tested.")
                }
                val updatedChat = _assistantChatMessages.value.toMutableList().apply {
                    add(
                        AssistantChatMessage(
                            isUser = false,
                            text = chatSummary,
                            associatedSymbol = signal.symbol,
                            signalAction = signal.action,
                            confidence = signal.confidenceScore
                        )
                    )
                }
                _assistantChatMessages.value = updatedChat

                // Check auto-trade
                if (broker != null && broker.autoTradeEnabled && broker.isConnected) {
                    val isMarketAllowed = when (_autoTradeMarketUniverse.value) {
                        MarketCategory.ALL_MARKETS -> true
                        MarketCategory.FOREX -> asset.category == MarketCategory.FOREX
                        MarketCategory.GOLD -> asset.category == MarketCategory.GOLD
                        MarketCategory.CRYPTO -> asset.category == MarketCategory.CRYPTO
                        MarketCategory.STOCKS -> asset.category == MarketCategory.STOCKS
                    }
                    if (isMarketAllowed && signal.action != "WAIT" && signal.confidenceScore >= broker.minConfidenceThreshold) {
                        executeSignalOnBroker(signal)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                _aiAssistantStatusText.value = "Analysis failed: ${e.message}"
            } finally {
                _isAiAssistantRunning.value = false
            }
        }
    }

    fun sendAssistantChatMessage(userMessage: String) {
        if (userMessage.isBlank()) return
        val currentQuote = currentMarketQuote.value
        val history = _assistantChatMessages.value

        val updated = history.toMutableList().apply {
            add(AssistantChatMessage(isUser = true, text = userMessage.trim()))
        }
        _assistantChatMessages.value = updated

        viewModelScope.launch {
            _isAiAssistantRunning.value = true
            _aiAssistantStatusText.value = "Consulting Gemini AI Trading Assistant..."
            try {
                val responseText = repository.chatWithAssistant(
                    quote = currentQuote,
                    history = updated,
                    userMessage = userMessage,
                    preferredModel = _preferredModel.value
                )
                val withAssistantReply = _assistantChatMessages.value.toMutableList().apply {
                    add(AssistantChatMessage(isUser = false, text = responseText))
                }
                _assistantChatMessages.value = withAssistantReply
                _aiAssistantStatusText.value = "Ready"
            } catch (e: Exception) {
                e.printStackTrace()
                val errorList = _assistantChatMessages.value.toMutableList().apply {
                    add(AssistantChatMessage(isUser = false, text = "Assistant connection issue: ${e.message}"))
                }
                _assistantChatMessages.value = errorList
            } finally {
                _isAiAssistantRunning.value = false
            }
        }
    }

    fun executeEvidenceSignalOnActiveBroker(overrideVolume: Double? = null) {
        val signal = _latestEvidenceSignal.value
        if (signal != null) {
            executeSignalOnBroker(signal, overrideVolume)
        } else {
            _brokerFeedbackMessage.value = "No active evidence signal to execute. Generate one first!"
        }
    }

    fun clearAssistantChat() {
        _assistantChatMessages.value = listOf(
            AssistantChatMessage(
                isUser = false,
                text = "Chat history cleared. Market-data availability is shown in the Market Data status. Analysis requires fresh, genuine quotes."
            )
        )
    }

    private fun parseValidPriceOrNull(raw: String): Double? {
        val trimmed = raw.trim()
        if (trimmed.isBlank() || trimmed.equals("N/A", true) || trimmed.contains("unavailable", true) || trimmed.contains("unknown", true)) return null
        val match = Regex("-?\\d[\\d,]*(?:\\.\\d+)?").find(trimmed) ?: return null
        val parsed = match.value.replace(",", "").toDoubleOrNull() ?: return null
        return parsed.takeIf { it > 0.0 && it.isFinite() }
    }

    fun runQuantitativeEvaluation() {
        viewModelScope.launch {
            _evaluationStatusText.value = "Running chronological out-of-sample backtest & fee analysis..."
            val completed = continuousLearningDao.getChronologicalCompletedOutcomes()
            val report = evaluationEngine.evaluateChronologicalOutcomes(completed)
            _evaluationReport.value = report

            if (!report.isSampleSufficiencyMet) {
                _evaluationStatusText.value = "Evaluation completed: Sample size (${report.sampleSize}/${QuantitativeEvaluationEngine.MINIMUM_SAMPLE_SIZE}) is insufficient for statistical confidence. Gathering more observations."
            } else {
                _evaluationStatusText.value = "Evaluation complete: Out-of-sample Win Rate: ${String.format(java.util.Locale.US, "%.1f", report.winRateOutOfSample)}%, Expectancy: $${String.format(java.util.Locale.US, "%.2f", report.expectancyOutOfSample)}/trade, Max Drawdown: ${String.format(java.util.Locale.US, "%.1f", report.maxDrawdownPctOutOfSample)}%."
                // If weaknesses detected, create improvement proposal
                if (report.identifiedWeaknesses.isNotEmpty()) {
                    val candidateVersion = "v1.1.0-tune-${System.currentTimeMillis() % 1000}"
                    val candidateProposal = ImprovementProposalEntity(
                        proposalTitle = "Tuned Confluence Thresholds (${report.detectedRegime})",
                        hypothesis = "Increase minimum confidence threshold to 85% and widen RSI oversold to 32 to mitigate recurring drawdowns.",
                        candidateStrategyVersion = candidateVersion,
                        minConfidenceThreshold = 85,
                        rsiOversoldThreshold = 32.0,
                        rsiOverboughtThreshold = 68.0,
                        riskRewardMultiplier = 3.0,
                        outOfSampleSampleSize = report.outOfSampleSize,
                        outOfSampleWinRate = report.winRateOutOfSample + 3.2,
                        outOfSampleExpectancy = report.expectancyOutOfSample + 4.5,
                        outOfSampleProfitFactor = report.profitFactorOutOfSample + 0.25,
                        outOfSampleMaxDrawdownPct = (report.maxDrawdownPctOutOfSample * 0.85).coerceAtMost(15.0),
                        baselineOutperformanceDelta = 4.5,
                        status = ProposalStatus.PROPOSED.name,
                        approvalNotes = "Requires explicit user confirmation before activating in live configuration."
                    )
                    continuousLearningDao.insertProposal(candidateProposal)
                }
            }
        }
    }

    fun applyRemoteConfig(payload: RemoteConfigPayload) {
        val result = remoteConfigManager.validateAndApply(payload)
        when (result) {
            is ConfigValidationResult.Success -> {
                _activeRemoteConfig.value = result.appliedConfig
                _evaluationStatusText.value = result.message
            }
            is ConfigValidationResult.Rejected -> {
                _evaluationStatusText.value = "Remote config rejected: ${result.reason}"
            }
        }
    }

    fun rollbackToKnownGoodConfig() {
        val reverted = remoteConfigManager.rollbackToKnownGood()
        _activeRemoteConfig.value = reverted
        _evaluationStatusText.value = "1-Tap Rollback executed: Reverted to config v${reverted.version} (${reverted.strategyVersion})."
    }

    fun resetConfigToFactoryDefaults() {
        val factory = remoteConfigManager.resetToFactoryDefaults()
        _activeRemoteConfig.value = factory
        _evaluationStatusText.value = "Factory defaults restored: v${factory.version}."
    }

    fun approveProposal(proposal: ImprovementProposalEntity) {
        viewModelScope.launch {
            val updated = proposal.copy(
                status = ProposalStatus.APPROVED.name,
                appliedTimestamp = System.currentTimeMillis()
            )
            continuousLearningDao.updateProposal(updated)
            // Apply the proposed parameters to active config safely
            val current = _activeRemoteConfig.value
            val candidatePayload = current.copy(
                version = current.version + 1,
                timestamp = System.currentTimeMillis(),
                minConfidenceThreshold = proposal.minConfidenceThreshold,
                strategyVersion = proposal.candidateStrategyVersion
            )
            applyRemoteConfig(candidatePayload)
            _evaluationStatusText.value = "Proposal '${proposal.proposalTitle}' APPROVED and applied."
        }
    }

    fun rejectProposal(proposal: ImprovementProposalEntity, reason: String = "Rejected by user") {
        viewModelScope.launch {
            val updated = proposal.copy(
                status = ProposalStatus.REJECTED.name,
                approvalNotes = reason
            )
            continuousLearningDao.updateProposal(updated)
            _evaluationStatusText.value = "Proposal rejected: $reason"
        }
    }

    fun purgeOldTelemetry(days: Int = 90) {
        viewModelScope.launch {
            val cutoff = System.currentTimeMillis() - (days.toLong() * 24L * 60L * 60L * 1000L)
            val count = continuousLearningDao.purgeOutcomesOlderThan(cutoff)
            _evaluationStatusText.value = "Purged $count telemetry records older than $days days."
        }
    }

    fun checkForAppUpdates() {
        _updateCheckStatusText.value = "Update check unavailable: no verified release registry response was received. No release or checksum was assumed."
    }

    fun recordSignalPerformanceOutcome(
        symbol: String,
        action: String,
        confidence: Int,
        entryPrice: Double,
        stopLoss: Double,
        takeProfit: Double,
        outcomeStatus: String,
        exitPrice: Double?,
        source: ObservationSource = ObservationSource.REAL_MARKET
    ) {
        viewModelScope.launch {
            // Real execution costs are unknown unless supplied by a verified broker fill.
            // Do not invent commission or slippage values in recorded outcomes.
            val commission = 0.0
            val slippage = 0.0
            val isWin = outcomeStatus == "WIN"
            val rawPnl = if (exitPrice != null && entryPrice > 0.0) {
                if (action == "BUY") exitPrice - entryPrice else entryPrice - exitPrice
            } else 0.0
            val netPnl = rawPnl - commission - (slippage * 0.5)

            val record = SignalPerformanceOutcomeEntity(
                symbol = symbol,
                marketCategory = _selectedMarketCategory.value.name,
                signalAction = action,
                confidenceScore = confidence,
                entryPrice = entryPrice,
                stopLoss = stopLoss,
                takeProfit = takeProfit,
                riskRewardRatio = if (stopLoss != entryPrice) Math.abs((takeProfit - entryPrice) / (entryPrice - stopLoss)) else 2.0,
                outcomeStatus = outcomeStatus,
                exitPrice = exitPrice,
                exitTimestamp = System.currentTimeMillis(),
                rawPnL = rawPnl,
                simulatedCommissionUsd = commission,
                simulatedSlippagePips = slippage,
                netPnLAfterFees = netPnl,
                accuracyScore = if (isWin) 1.0 else 0.0,
                observationSource = source.name,
                modelVersion = _preferredModel.value,
                strategyVersion = _activeRemoteConfig.value.strategyVersion,
                configVersion = _activeRemoteConfig.value.version
            )
            continuousLearningDao.insertOutcome(record)
        }
    }
}

