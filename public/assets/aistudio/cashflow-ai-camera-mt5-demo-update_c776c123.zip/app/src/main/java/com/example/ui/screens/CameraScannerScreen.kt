package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CenterFocusWeak
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.CashFlowViewModel
import com.example.ui.components.LiveSignalCard

@Composable
fun CameraScannerScreen(
    viewModel: CashFlowViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val isAnalyzing by viewModel.isAnalyzingChart.collectAsState()
    val latestSignal by viewModel.latestActiveSignal.collectAsState()
    val analysisStatus by viewModel.chartFrameStatusText.collectAsState()

    var hasCameraPermission by remember { mutableStateOf(false) }
    var cameraReady by remember { mutableStateOf(false) }
    var cameraError by remember { mutableStateOf<String?>(null) }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var cameraProvider by remember { mutableStateOf<ProcessCameraProvider?>(null) }
    var captureInProgress by remember { mutableStateOf(false) }

    val cameraPermissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
        if (!granted) cameraError = "Camera permission denied. Allow camera access to capture a real chart."
        else cameraError = null
    }

    LaunchedEffect(Unit) {
        val permissionGranted = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.CAMERA
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        hasCameraPermission = permissionGranted
        if (!permissionGranted) cameraError = "Camera permission is required to capture a real chart."
    }

    DisposableEffect(lifecycleOwner, cameraProvider) {
        onDispose {
            cameraProvider?.unbindAll()
            imageCapture = null
            cameraReady = false
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0B0E14))
            .testTag("camera_scanner_screen")
    ) {
        if (hasCameraPermission) {
            AndroidView(
                factory = { ctx ->
                    val previewView = PreviewView(ctx)
                    previewView.scaleType = PreviewView.ScaleType.FILL_CENTER
                    val providerFuture = ProcessCameraProvider.getInstance(ctx)
                    providerFuture.addListener({
                        try {
                            val provider = providerFuture.get()
                            val preview = Preview.Builder().build().also {
                                it.setSurfaceProvider(previewView.surfaceProvider)
                            }
                            val capture = ImageCapture.Builder()
                                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                                .build()
                            provider.unbindAll()
                            provider.bindToLifecycle(
                                lifecycleOwner,
                                CameraSelector.DEFAULT_BACK_CAMERA,
                                preview,
                                capture
                            )
                            cameraProvider = provider
                            imageCapture = capture
                            cameraReady = true
                            cameraError = null
                        } catch (e: Exception) {
                            cameraReady = false
                            val errorMessage = "Camera could not start: ${e.localizedMessage ?: "device camera unavailable"}"
                            cameraError = errorMessage
                            viewModel.reportChartFrameError(errorMessage)
                        }
                    }, ContextCompat.getMainExecutor(ctx))
                    previewView
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Box(
                modifier = Modifier.fillMaxSize().background(Color(0xFF070A0F)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.CenterFocusWeak,
                        contentDescription = null,
                        tint = Color(0xFF00E676),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "CAMERA CHART SCANNER",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        ),
                        color = Color.White
                    )
                    Text(
                        text = "Capture a real chart from an external monitor or tablet",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF90A4AE)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF00E676),
                            contentColor = Color.Black
                        ),
                        modifier = Modifier.testTag("grant_camera_permission_btn")
                    ) { Text("Grant Camera Permission", fontWeight = FontWeight.Bold) }
                }
            }
        }

        Box(
            modifier = Modifier
                .size(300.dp, 200.dp)
                .align(Alignment.Center)
                .border(2.dp, Color(0xFF00E676), RoundedCornerShape(16.dp))
                .background(Color(0x1A00E676))
        ) {
            Text(
                text = "ALIGN CHART IN FRAME",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                ),
                color = Color(0xFF00E676),
                modifier = Modifier.align(Alignment.TopCenter).padding(8.dp)
            )
        }

        Surface(
            color = Color(0xCC0D1117),
            modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "AI CAMERA VISION",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    ),
                    color = Color.White
                )
                Row {
                    IconButton(onClick = {
                        cameraError = "Flash control is not available on this camera configuration."
                    }) {
                        Icon(imageVector = Icons.Default.FlashOn, contentDescription = "Flash", tint = Color.White)
                    }
                    IconButton(onClick = {
                        cameraError = "Only the rear camera is currently configured for chart capture."
                    }) {
                        Icon(imageVector = Icons.Default.FlipCameraAndroid, contentDescription = "Switch Camera", tint = Color.White)
                    }
                }
            }
        }

        Column(
            modifier = Modifier.fillMaxWidth().align(Alignment.BottomCenter).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            latestSignal?.let { signal ->
                if (signal.source == "CAMERA_ANALYSIS") {
                    LiveSignalCard(
                        signal = signal,
                        onConvertToJournal = { viewModel.convertSignalToJournalEntry(it) },
                        onDelete = { viewModel.deleteSignal(it) }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }

            val visibleStatus = cameraError ?: analysisStatus
            Text(
                text = visibleStatus,
                color = if (cameraError != null || visibleStatus.contains("failed", true) || visibleStatus.contains("denied", true)) Color(0xFFFF8A80) else Color.White,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Button(
                onClick = {
                    val capture = imageCapture
                    if (!hasCameraPermission) {
                        cameraError = "Camera permission is required."
                        return@Button
                    }
                    if (!cameraReady || capture == null) {
                        cameraError = "Camera is not ready. Wait for the preview, then try again."
                        return@Button
                    }
                    if (captureInProgress || isAnalyzing) return@Button
                    captureInProgress = true
                    cameraError = null
                    capture.takePicture(
                        ContextCompat.getMainExecutor(context),
                        object : ImageCapture.OnImageCapturedCallback() {
                            override fun onCaptureSuccess(image: ImageProxy) {
                                var bitmap: Bitmap? = null
                                try {
                                    bitmap = decodeCapturedFrame(image)
                                } catch (e: Exception) {
                                    cameraError = "Captured frame could not be decoded: ${e.localizedMessage ?: "invalid image"}"
                                } finally {
                                    image.close()
                                    captureInProgress = false
                                }
                                if (bitmap != null) {
                                    cameraError = null
                                    viewModel.processChartFrameBitmap(bitmap, "CAMERA_ANALYSIS")
                                } else if (cameraError == null) {
                                    cameraError = "Camera returned an empty frame. No analysis was run."
                                }
                            }

                            override fun onError(exception: ImageCaptureException) {
                                captureInProgress = false
                                val errorMessage = "Camera capture failed: ${exception.message ?: "unknown camera error"}. No analysis was run."
                                cameraError = errorMessage
                                viewModel.reportChartFrameError(errorMessage)
                            }
                        }
                    )
                },
                enabled = hasCameraPermission && cameraReady && !captureInProgress && !isAnalyzing,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF00E676),
                    contentColor = Color.Black
                ),
                shape = CircleShape,
                modifier = Modifier.size(72.dp).testTag("snap_camera_chart_btn")
            ) {
                if (isAnalyzing || captureInProgress) {
                    CircularProgressIndicator(color = Color.Black, strokeWidth = 3.dp, modifier = Modifier.size(28.dp))
                } else {
                    Icon(imageVector = Icons.Default.CameraAlt, contentDescription = "Capture real chart", modifier = Modifier.size(32.dp))
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "CAPTURE A REAL CHART FRAME TO ANALYZE",
                style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                color = Color.White
            )
        }
    }
}

private fun decodeCapturedFrame(image: ImageProxy): Bitmap? {
    val plane = image.planes.firstOrNull() ?: return null
    val buffer = plane.buffer.duplicate()
    val bytes = ByteArray(buffer.remaining())
    buffer.get(bytes)
    val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
    val rotation = image.imageInfo.rotationDegrees
    val rotated = if (rotation == 0) decoded else {
        val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
        Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true).also {
            if (it !== decoded) decoded.recycle()
        }
    }
    return cropToGuideAspect(rotated, 1.5f)
}

private fun cropToGuideAspect(bitmap: Bitmap, targetAspect: Float): Bitmap {
    val width = bitmap.width
    val height = bitmap.height
    if (width <= 0 || height <= 0) return bitmap
    val sourceAspect = width.toFloat() / height.toFloat()
    val cropWidth: Int
    val cropHeight: Int
    if (sourceAspect > targetAspect) {
        cropHeight = height
        cropWidth = (height * targetAspect).toInt().coerceIn(1, width)
    } else {
        cropWidth = width
        cropHeight = (width / targetAspect).toInt().coerceIn(1, height)
    }
    val left = (width - cropWidth) / 2
    val top = (height - cropHeight) / 2
    if (left == 0 && top == 0 && cropWidth == width && cropHeight == height) return bitmap
    return Bitmap.createBitmap(bitmap, left, top, cropWidth, cropHeight).also {
        if (it !== bitmap) bitmap.recycle()
    }
}
