package com.example.data

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.abs

class BrokerConnectionManager(
    private val scope: CoroutineScope
) {
    private val _connectedAccount = MutableStateFlow<BrokerAccountEntity?>(null)
    val connectedAccount: StateFlow<BrokerAccountEntity?> = _connectedAccount.asStateFlow()

    private val _connectionStatus = MutableStateFlow("DISCONNECTED") // "DISCONNECTED", "CONNECTING", "ERROR"
    val connectionStatus: StateFlow<String> = _connectionStatus.asStateFlow()

    private val _currentPingMs = MutableStateFlow(0L)
    val currentPingMs: StateFlow<Long> = _currentPingMs.asStateFlow()

    private val _openPositions = MutableStateFlow<List<BrokerPosition>>(emptyList())
    val openPositions: StateFlow<List<BrokerPosition>> = _openPositions.asStateFlow()

    private val _executionLogs = MutableStateFlow<List<BrokerExecutionLog>>(emptyList())
    val executionLogs: StateFlow<List<BrokerExecutionLog>> = _executionLogs.asStateFlow()

    var onAccountUpdated: ((BrokerAccountEntity) -> Unit)? = null


    companion object {
        fun getUtcDayStartTimestamp(epochMillis: Long = System.currentTimeMillis()): Long {
            val calendar = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"))
            calendar.timeInMillis = epochMillis
            calendar.set(java.util.Calendar.HOUR_OF_DAY, 0)
            calendar.set(java.util.Calendar.MINUTE, 0)
            calendar.set(java.util.Calendar.SECOND, 0)
            calendar.set(java.util.Calendar.MILLISECOND, 0)
            return calendar.timeInMillis
        }

        fun checkAndRolloverDailyLoss(
            account: BrokerAccountEntity,
            currentTimeMillis: Long = System.currentTimeMillis()
        ): BrokerAccountEntity {
            val currentDayStart = getUtcDayStartTimestamp(currentTimeMillis)
            val accountDayStart = if (account.dailyLossResetTimestamp > 0L) {
                getUtcDayStartTimestamp(account.dailyLossResetTimestamp)
            } else {
                0L
            }

            return if (currentDayStart > accountDayStart) {
                account.copy(
                    dailyRealizedLoss = 0.0,
                    isCircuitBreakerTripped = false,
                    dailyLossResetTimestamp = currentDayStart
                )
            } else {
                account
            }
        }
    }

    init {
        // No sample positions are loaded. Position state is empty until a verified adapter supplies it.
        _openPositions.value = emptyList()
    }

    fun connect(account: BrokerAccountEntity, onComplete: (Boolean, String) -> Unit) {
        scope.launch {
            _connectionStatus.value = "CONNECTING"
            _connectedAccount.value = null
            _currentPingMs.value = 0L
            val message = if (account.brokerType.equals("METATRADER_5", ignoreCase = true)) {
                "MT5 connection not established: this Android app has no verified MT5 terminal bridge. An account number and server name do not authenticate with the MT5 trade server. Use a demo/practice terminal bridge before enabling account data or orders."
            } else {
                "Connection rejected: no verified ${account.brokerType} adapter is installed. No connection was established and no order can be sent."
            }
            _connectionStatus.value = "ERROR"
            addLog(account.brokerType, "CONNECT", message, false)
            onAccountUpdated?.invoke(account.copy(isConnected = false, autoTradeEnabled = false, lastPingMs = 0L))
            onComplete(false, message)
        }
    }

    fun disconnect() {
        val account = _connectedAccount.value
        if (account != null) {
            addLog(account.brokerType, "DISCONNECT", "Local broker state cleared; no verified broker session was active.", false)
        }
        _connectedAccount.value = null
        _connectionStatus.value = "DISCONNECTED"
        _currentPingMs.value = 0L
        _openPositions.value = emptyList()
    }

    fun testPing(account: BrokerAccountEntity, onResult: (Long) -> Unit) {
        _currentPingMs.value = 0L
        addLog(account.brokerType, "PING", "Ping unavailable: no verified broker adapter is configured; no latency was fabricated.", false)
        onResult(-1L)
    }

    /**
     * Executes a trade on the currently connected or specified broker account.
     */
    fun executeTrade(
        symbol: String,
        side: String, // "BUY" or "SELL"
        entryPrice: Double,
        stopLoss: Double,
        takeProfit: Double,
        volume: Double = 0.05,
        sourceSignalId: Long? = null,
        onComplete: (Boolean, String, BrokerPosition?) -> Unit
    ) {
        scope.launch {
            val rawAccount = _connectedAccount.value
            val account = if (rawAccount != null) {
                val rolled = checkAndRolloverDailyLoss(rawAccount)
                if (rolled != rawAccount) {
                    _connectedAccount.value = rolled
                    onAccountUpdated?.invoke(rolled)
                }
                rolled
            } else null

            val brokerName = account?.brokerType ?: "UNCONFIGURED"

            // Circuit Breaker: Enforce daily loss limit
            if (account != null && account.dailyLossLimit > 0.0) {
                val isTripped = account.isCircuitBreakerTripped || account.dailyRealizedLoss >= account.dailyLossLimit
                if (isTripped) {
                    val err = "Execution rejected: Daily-loss circuit breaker is active for $brokerName (Realized loss: $${String.format(java.util.Locale.US, "%.2f", account.dailyRealizedLoss)} >= Limit: $${String.format(java.util.Locale.US, "%.2f", account.dailyLossLimit)}). Trading halted for current session."
                    addLog(brokerName, "CIRCUIT_BREAKER_BLOCKED", err, false)
                    onComplete(false, err, null)
                    return@launch
                }
            }

            // 0. Duplicate order check within 5-second cooldown on same symbol and side
            val normalizedSide = side.trim().uppercase()
            val isDuplicate = _openPositions.value.any {
                it.symbol == symbol && it.side == normalizedSide && (System.currentTimeMillis() - it.openTime) < 5_000L
            }
            if (isDuplicate) {
                val err = "Execution rejected: Duplicate order detected on $symbol ($normalizedSide) within cooldown period."
                addLog(brokerName, "ORDER_REJECTED", err, false)
                onComplete(false, err, null)
                return@launch
            }

            // Check sufficient free margin if account is connected
            val requiredMargin = volume * 100.0
            if (account != null && account.freeMargin < requiredMargin) {
                val err = "Execution rejected: Insufficient free margin ($${String.format(java.util.Locale.US, "%.2f", account.freeMargin)} < required $${String.format(java.util.Locale.US, "%.2f", requiredMargin)})."
                addLog(brokerName, "ORDER_REJECTED", err, false)
                onComplete(false, err, null)
                return@launch
            }

            // 1. Validate entryPrice
            if (entryPrice <= 0.0 || entryPrice.isNaN() || entryPrice.isInfinite()) {
                val err = "Execution rejected: Invalid entry price ($entryPrice). Price must be positive and finite."
                addLog(brokerName, "ORDER_REJECTED", err, false)
                onComplete(false, err, null)
                return@launch
            }

            // 2. Validate volume
            if (volume <= 0.0 || volume.isNaN() || volume.isInfinite()) {
                val err = "Execution rejected: Invalid volume ($volume). Volume must be positive and finite."
                addLog(brokerName, "ORDER_REJECTED", err, false)
                onComplete(false, err, null)
                return@launch
            }

            // 3. Validate stop-loss and take-profit
            if (stopLoss <= 0.0 || stopLoss.isNaN() || stopLoss.isInfinite() ||
                takeProfit <= 0.0 || takeProfit.isNaN() || takeProfit.isInfinite()) {
                val err = "Execution rejected: Invalid stop-loss ($stopLoss) or take-profit ($takeProfit). Levels must be positive and finite."
                addLog(brokerName, "ORDER_REJECTED", err, false)
                onComplete(false, err, null)
                return@launch
            }

            // 4. Validate brackets per existing trade model
            if (normalizedSide == "BUY") {
                if (stopLoss >= entryPrice || takeProfit <= entryPrice) {
                    val err = "Execution rejected: Invalid BUY brackets. Stop-loss ($stopLoss) must be below entry ($entryPrice) and take-profit ($takeProfit) above entry."
                    addLog(brokerName, "ORDER_REJECTED", err, false)
                    onComplete(false, err, null)
                    return@launch
                }
            } else if (normalizedSide == "SELL") {
                if (stopLoss <= entryPrice || takeProfit >= entryPrice) {
                    val err = "Execution rejected: Invalid SELL brackets. Stop-loss ($stopLoss) must be above entry ($entryPrice) and take-profit ($takeProfit) below entry."
                    addLog(brokerName, "ORDER_REJECTED", err, false)
                    onComplete(false, err, null)
                    return@launch
                }
            } else {
                val err = "Execution rejected: Unsupported trade action ($side). Only BUY or SELL can be executed."
                addLog(brokerName, "ORDER_REJECTED", err, false)
                onComplete(false, err, null)
                return@launch
            }

            val err = if (account?.brokerType.equals("METATRADER_5", ignoreCase = true)) {
                "Execution rejected: no verified MT5 terminal bridge is connected. This request was not sent to any broker and no local ticket was created."
            } else {
                "Execution rejected: no verified broker execution adapter is connected. This request was not sent and no local ticket was created."
            }
            addLog(brokerName, "ORDER_REJECTED", err, false)
            onComplete(false, err, null)
        }
    }

    fun closePosition(ticketId: String, onComplete: (Boolean, Double) -> Unit) {
        scope.launch {
            val pos = _openPositions.value.find { it.ticketId == ticketId }
            if (pos != null) {
                val rawPnl = pos.unrealizedPnL
                val pnl = if (rawPnl.isNaN() || rawPnl.isInfinite()) 0.0 else rawPnl
                val updated = _openPositions.value.filter { it.ticketId != ticketId }
                _openPositions.value = updated

                // Credit PnL to connected account and update daily-loss tracking
                _connectedAccount.value?.let { currentAcc ->
                    val acc = checkAndRolloverDailyLoss(currentAcc)
                    val newBalance = acc.balance + pnl
                    val newEquity = acc.equity + pnl
                    val newMargin = acc.freeMargin + (pos.volume * 100) + pnl

                    // Only realized losses increase dailyRealizedLoss; winning trades never erase prior losses
                    val lossIncrement = if (pnl < 0.0) abs(pnl) else 0.0
                    val updatedRealizedLoss = acc.dailyRealizedLoss + lossIncrement
                    val circuitBreakerTripped = acc.isCircuitBreakerTripped || (acc.dailyLossLimit > 0.0 && updatedRealizedLoss >= acc.dailyLossLimit)

                    val updatedAcc = acc.copy(
                        balance = newBalance,
                        equity = newEquity,
                        freeMargin = newMargin,
                        dailyRealizedLoss = updatedRealizedLoss,
                        isCircuitBreakerTripped = circuitBreakerTripped,
                        dailyLossResetTimestamp = if (acc.dailyLossResetTimestamp <= 0L) getUtcDayStartTimestamp() else acc.dailyLossResetTimestamp
                    )
                    _connectedAccount.value = updatedAcc
                    onAccountUpdated?.invoke(updatedAcc)

                    if (circuitBreakerTripped && !acc.isCircuitBreakerTripped) {
                        addLog(
                            acc.brokerType,
                            "CIRCUIT_BREAKER_TRIPPED",
                            "Daily-loss circuit breaker TRIPPED! Realized loss $${String.format(java.util.Locale.US, "%.2f", updatedRealizedLoss)} >= Limit $${String.format(java.util.Locale.US, "%.2f", acc.dailyLossLimit)}. New orders blocked.",
                            false
                        )
                    }
                }

                val pnlText = if (pnl >= 0) "+$${String.format(java.util.Locale.US, "%.2f", pnl)}" else "-$${String.format(java.util.Locale.US, "%.2f", abs(pnl))}"
                addLog(pos.brokerType, "ORDER_CLOSED", "Closed ticket #${pos.ticketId} (${pos.symbol}) with P&L: $pnlText", true)
                onComplete(true, pnl)
            } else {
                onComplete(false, 0.0)
            }
        }
    }

    fun closeAllPositions(onComplete: (Int, Double) -> Unit) {
        scope.launch {
            val list = _openPositions.value
            val count = list.size
            if (count == 0) {
                onComplete(0, 0.0)
                return@launch
            }

            val totalPnL = list.sumOf {
                val p = it.unrealizedPnL
                if (p.isNaN() || p.isInfinite()) 0.0 else p
            }
            _openPositions.value = emptyList()

            _connectedAccount.value?.let { currentAcc ->
                val acc = checkAndRolloverDailyLoss(currentAcc)
                val totalLossIncrement = list.sumOf { pos ->
                    val p = pos.unrealizedPnL
                    val safeP = if (p.isNaN() || p.isInfinite()) 0.0 else p
                    if (safeP < 0.0) abs(safeP) else 0.0
                }
                val updatedRealizedLoss = acc.dailyRealizedLoss + totalLossIncrement
                val circuitBreakerTripped = acc.isCircuitBreakerTripped || (acc.dailyLossLimit > 0.0 && updatedRealizedLoss >= acc.dailyLossLimit)

                val updatedAcc = acc.copy(
                    balance = acc.balance + totalPnL,
                    equity = acc.equity + totalPnL,
                    freeMargin = acc.balance + totalPnL,
                    dailyRealizedLoss = updatedRealizedLoss,
                    isCircuitBreakerTripped = circuitBreakerTripped,
                    dailyLossResetTimestamp = if (acc.dailyLossResetTimestamp <= 0L) getUtcDayStartTimestamp() else acc.dailyLossResetTimestamp
                )
                _connectedAccount.value = updatedAcc
                onAccountUpdated?.invoke(updatedAcc)

                if (circuitBreakerTripped && !acc.isCircuitBreakerTripped) {
                    addLog(
                        acc.brokerType,
                        "CIRCUIT_BREAKER_TRIPPED",
                        "Daily-loss circuit breaker TRIPPED on Emergency Close All! Realized loss $${String.format(java.util.Locale.US, "%.2f", updatedRealizedLoss)} >= Limit $${String.format(java.util.Locale.US, "%.2f", acc.dailyLossLimit)}. New orders blocked.",
                        false
                    )
                }
            }

            addLog("BROKER", "CLOSE_ALL", "Emergency closed all $count open positions. Total PnL: $$totalPnL", true)
            onComplete(count, totalPnL)
        }
    }

    fun resetDailyLoss(reason: String = "Manual User Reset") {
        _connectedAccount.value?.let { acc ->
            val updated = acc.copy(
                dailyRealizedLoss = 0.0,
                isCircuitBreakerTripped = false,
                dailyLossResetTimestamp = getUtcDayStartTimestamp()
            )
            _connectedAccount.value = updated
            onAccountUpdated?.invoke(updated)
            addLog(
                acc.brokerType,
                "CIRCUIT_BREAKER_RESET",
                "Daily-loss circuit breaker reset ($reason). Previous realized loss: $${String.format(java.util.Locale.US, "%.2f", acc.dailyRealizedLoss)}.",
                true
            )
        }
    }

    private fun addLog(brokerType: String, action: String, message: String, success: Boolean = true) {
        val newLog = BrokerExecutionLog(
            id = UUID.randomUUID().toString(),
            timestamp = System.currentTimeMillis(),
            brokerType = brokerType,
            action = action,
            message = message,
            success = success
        )
        val logs = _executionLogs.value.toMutableList()
        logs.add(0, newLog)
        if (logs.size > 50) logs.removeAt(logs.size - 1)
        _executionLogs.value = logs
    }
}
