package com.example.data

import kotlin.math.abs

class SignalEngine {

    /**
     * Calculates Relative Strength Index (RSI) for a list of close prices over specified period (default 14).
     */
    fun calculateRSI(prices: List<Double>, period: Int = 14): Double {
        if (prices.size < period + 1) return 0.0

        var gains = 0.0
        var losses = 0.0

        for (i in 1..period) {
            val change = prices[i] - prices[i - 1]
            if (change >= 0) gains += change else losses += abs(change)
        }

        var avgGain = gains / period
        var avgLoss = losses / period

        for (i in (period + 1) until prices.size) {
            val change = prices[i] - prices[i - 1]
            if (change >= 0) {
                avgGain = (avgGain * (period - 1) + change) / period
                avgLoss = (avgLoss * (period - 1)) / period
            } else {
                avgGain = (avgGain * (period - 1)) / period
                avgLoss = (avgLoss * (period - 1) + abs(change)) / period
            }
        }

        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return (100.0 - (100.0 / (1.0 + rs))).coerceIn(0.0, 100.0)
    }

    /**
     * Calculates Exponential Moving Average (EMA).
     */
    fun calculateEMA(prices: List<Double>, period: Int): Double {
        if (prices.isEmpty()) return 0.0
        if (prices.size < period) return prices.average()

        val multiplier = 2.0 / (period + 1)
        var ema = prices.take(period).average()

        for (i in period until prices.size) {
            ema = (prices[i] - ema) * multiplier + ema
        }
        return ema
    }

    /**
     * Calculates MACD Line and Signal Line (12 Fast, 26 Slow, 9 Signal).
     */
    fun calculateMACD(prices: List<Double>): Pair<Double, Double> {
        if (prices.size < 26) return Pair(0.0, 0.0)

        val ema12 = calculateEMA(prices, 12)
        val ema26 = calculateEMA(prices, 26)
        val macdLine = ema12 - ema26

        // Calculate MACD history for signal line
        val macdHistory = mutableListOf<Double>()
        for (i in 26..prices.size) {
            val subList = prices.subList(0, i)
            val e12 = calculateEMA(subList, 12)
            val e26 = calculateEMA(subList, 26)
            macdHistory.add(e12 - e26)
        }

        val signalLine = if (macdHistory.isNotEmpty()) calculateEMA(macdHistory, 9) else 0.0
        return Pair(macdLine, signalLine)
    }

    /**
     * Detects Japanese Candlestick Patterns from OHLC lists.
     */
    fun detectCandlePattern(
        opens: List<Double>,
        highs: List<Double>,
        lows: List<Double>,
        closes: List<Double>
    ): String {
        val n = closes.size
        if (n < 2) return "STANDARD CANDLE"

        val currOpen = opens[n - 1]
        val currClose = closes[n - 1]
        val currHigh = highs[n - 1]
        val currLow = lows[n - 1]

        val prevOpen = opens[n - 2]
        val prevClose = closes[n - 2]

        val currBody = abs(currClose - currOpen)
        val currRange = currHigh - currLow

        val isCurrBullish = currClose > currOpen
        val isPrevBearish = prevClose < prevOpen
        val isPrevBullish = prevClose > prevOpen

        // Bullish Engulfing
        if (isCurrBullish && isPrevBearish && currClose >= prevOpen && currOpen <= prevClose) {
            return "BULLISH ENGULFING"
        }

        // Bearish Engulfing
        if (!isCurrBullish && isPrevBullish && currClose <= prevOpen && currOpen >= prevClose) {
            return "BEARISH ENGULFING"
        }

        // Hammer / Pin Bar
        val lowerWick = if (isCurrBullish) currOpen - currLow else currClose - currLow
        if (currRange > 0 && lowerWick / currRange >= 0.6 && currBody / currRange <= 0.3) {
            return "BULLISH HAMMER PINBAR"
        }

        // Shooting Star
        val upperWick = if (isCurrBullish) currHigh - currClose else currHigh - currOpen
        if (currRange > 0 && upperWick / currRange >= 0.6 && currBody / currRange <= 0.3) {
            return "BEARISH SHOOTING STAR"
        }

        // Doji
        if (currRange > 0 && currBody / currRange <= 0.1) {
            return "INDECISION DOJI"
        }

        return if (isCurrBullish) "BULLISH MOMENTUM CANDLE" else "BEARISH MOMENTUM CANDLE"
    }

    /**
     * Evaluates volume/price momentum confirmation.
     */
    fun evaluateMomentum(prices: List<Double>, rsi: Double): String {
        if (prices.size < 5) return "MODERATE MOMENTUM"
        val recentChange = (prices.last() - prices[prices.size - 5]) / prices[prices.size - 5] * 100.0

        return when {
            recentChange > 1.2 && rsi < 65 -> "STRONG BULLISH MOMENTUM SURGE"
            recentChange < -1.2 && rsi > 35 -> "STRONG BEARISH MOMENTUM DUMP"
            else -> "CONSOLIDATION MOMENTUM"
        }
    }

    /**
     * Generates a close-series signal only when a fresh genuine quote and ATR are available.
     */
    fun generateSignal(
        symbol: String = "BTC/USD",
        priceHistory: List<Double>? = null,
        quote: GenuineMarketQuote? = null
    ): TradingSignal {
        val asset = MarketUniverse.findAssetBySymbol(symbol)
        val prices = priceHistory
        if (prices == null || prices.size < 50 || prices.any { it <= 0.0 || it.isNaN() || it.isInfinite() }) {
            return createUnavailableWaitSignal(asset)
        }

        val liveQuote = quote ?: return createUnavailableWaitSignal(asset).copy(
            analysisReason = "Genuine quote required: close history alone cannot verify the current entry price or ATR-based trade levels."
        )
        val quoteAgeMs = if (liveQuote.lastUpdatedTimestamp > 0L) System.currentTimeMillis() - liveQuote.lastUpdatedTimestamp else Long.MAX_VALUE
        if (liveQuote.asset.symbol != asset.symbol || liveQuote.isStale ||
            liveQuote.lastPrice <= 0.0 || !liveQuote.lastPrice.isFinite() ||
            quoteAgeMs < -300_000L || quoteAgeMs > 300_000L ||
            liveQuote.atr <= 0.0 || !liveQuote.atr.isFinite()) {
            return createUnavailableWaitSignal(asset).copy(
                analysisReason = "Genuine market quote or ATR is missing, stale, or invalid. No actionable signal or trade levels were generated."
            )
        }

        val rsi = calculateRSI(prices)
        if (rsi <= 0.0 || !rsi.isFinite()) return createUnavailableWaitSignal(asset)

        val (macdLine, signalLine) = calculateMACD(prices)
        val macdSignalStr = when {
            macdLine > signalLine && macdLine > 0 -> "BULLISH CROSSOVER (ABOVE ZERO)"
            macdLine > signalLine -> "BULLISH MACD CROSSOVER"
            macdLine < signalLine && macdLine < 0 -> "BEARISH CROSSOVER (BELOW ZERO)"
            else -> "BEARISH MACD CROSSOVER"
        }

        val ema20 = calculateEMA(prices, 20)
        val ema50 = calculateEMA(prices, 50)
        val ema200 = if (prices.size >= 200) calculateEMA(prices, 200) else null
        val emaTrendStr = when {
            ema200 != null && ema20 > ema50 && ema50 > ema200 -> "STRONG UPTREND (20 > 50 > 200 EMA)"
            ema20 > ema50 -> if (ema200 == null) "BULLISH EMA ALIGNMENT (EMA200 UNAVAILABLE)" else "BULLISH EMA ALIGNMENT"
            ema200 != null && ema20 < ema50 && ema50 < ema200 -> "STRONG DOWNTREND (20 < 50 < 200 EMA)"
            ema20 < ema50 -> if (ema200 == null) "BEARISH EMA ALIGNMENT (EMA200 UNAVAILABLE)" else "BEARISH EMA ALIGNMENT"
            else -> "SIDEWAYS EMA CONSOLIDATION"
        }

        // The quote currently supplies close history, not per-candle OHLC. Do not synthesize
        // opens/highs/lows from closes or claim a candle pattern that was not observed.
        val candlePattern = "OHLC CANDLE PATTERN UNAVAILABLE"
        val momentumStr = evaluateMomentum(prices, rsi)

        var bullScore = 0
        var bearScore = 0
        if (rsi <= 38.0) bullScore += 25
        else if (rsi in 38.1..52.0) bullScore += 15
        else if (rsi >= 62.0) bearScore += 25
        else if (rsi in 48.0..61.9) bearScore += 15

        if (macdLine > signalLine) bullScore += 20 else bearScore += 20
        if (ema20 > ema50) bullScore += 20 else if (ema20 < ema50) bearScore += 20
        if (momentumStr.contains("BULLISH")) bullScore += 15
        else if (momentumStr.contains("BEARISH")) bearScore += 15

        val signalType: String
        val rawConfidence: Int
        if (bullScore >= 80) {
            signalType = "BUY"
            rawConfidence = (bullScore + 5).coerceAtMost(85)
        } else if (bearScore >= 80) {
            signalType = "SELL"
            rawConfidence = (bearScore + 5).coerceAtMost(85)
        } else if (bullScore >= 60) {
            signalType = "BUY"
            rawConfidence = bullScore.coerceAtMost(80)
        } else if (bearScore >= 60) {
            signalType = "SELL"
            rawConfidence = bearScore.coerceAtMost(80)
        } else {
            signalType = "WAIT"
            rawConfidence = 0
        }

        val entryPrice: Double
        val stopLoss: Double
        val takeProfit: Double
        if (signalType == "BUY" || signalType == "SELL") {
            val levels = calculateAtrTradeLevels(liveQuote.lastPrice, signalType, liveQuote.atr, asset.decimalDigits)
                ?: return createUnavailableWaitSignal(asset).copy(
                    analysisReason = "ATR-based entry/stop/target levels could not be validated. No actionable signal was generated."
                )
            entryPrice = levels.first
            stopLoss = levels.second
            takeProfit = levels.third
        } else {
            entryPrice = 0.0
            stopLoss = 0.0
            takeProfit = 0.0
        }

        val reason = buildString {
            append("[${asset.category.badgeLabel}] 4-indicator close-series confluence: ")
            append("1) RSI ${String.format(java.util.Locale.US, "%.1f", rsi)}. ")
            append("2) MACD $macdSignalStr. ")
            append("3) Trend $emaTrendStr. ")
            append("4) Momentum $momentumStr. ")
            append("OHLC candle patterns unavailable because verified per-candle OHLC was not supplied. ")
            if (signalType == "BUY" || signalType == "SELL") {
                append("Entry uses the current genuine quote; stop/target distances derive from genuine ATR (${liveQuote.atr}).")
            } else {
                append("Indicator confluence did not meet the action threshold.")
            }
        }

        return TradingSignal(
            symbol = asset.symbol,
            signalType = signalType,
            confidencePercentage = rawConfidence,
            entryPrice = entryPrice,
            stopLoss = stopLoss,
            takeProfit = takeProfit,
            analysisReason = reason,
            rsiValue = rsi,
            macdSignal = macdSignalStr,
            emaTrend = emaTrendStr,
            candlePattern = candlePattern,
            momentumConfirmation = momentumStr,
            isStrongSignal = rawConfidence >= 90
        )
    }

    private fun calculateAtrTradeLevels(
        currentPrice: Double,
        signalType: String,
        atr: Double,
        decimalDigits: Int
    ): Triple<Double, Double, Double>? {
        if (currentPrice <= 0.0 || !currentPrice.isFinite() || atr <= 0.0 || !atr.isFinite()) return null
        val multiplier = Math.pow(10.0, decimalDigits.toDouble())
        val riskDistance = atr * 1.5
        val rewardDistance = riskDistance * 2.0
        val entry = Math.round(currentPrice * multiplier) / multiplier
        val stop = when (signalType) {
            "BUY" -> Math.round((currentPrice - riskDistance) * multiplier) / multiplier
            "SELL" -> Math.round((currentPrice + riskDistance) * multiplier) / multiplier
            else -> return null
        }
        val target = when (signalType) {
            "BUY" -> Math.round((currentPrice + rewardDistance) * multiplier) / multiplier
            "SELL" -> Math.round((currentPrice - rewardDistance) * multiplier) / multiplier
            else -> return null
        }
        val validBrackets = when (signalType) {
            "BUY" -> stop > 0.0 && stop < entry && target > entry
            "SELL" -> stop > entry && target > 0.0 && target < entry
            else -> false
        }
        return if (validBrackets) Triple(entry, stop, target) else null
    }

    private fun createUnavailableWaitSignal(asset: MarketAsset): TradingSignal {
        return TradingSignal(
            symbol = asset.symbol,
            signalType = "WAIT",
            confidencePercentage = 0,
            entryPrice = 0.0,
            stopLoss = 0.0,
            takeProfit = 0.0,
            analysisReason = "Genuine market data unavailable: Insufficient or invalid price history for technical analysis.",
            timestamp = System.currentTimeMillis(),
            rsiValue = 0.0,
            macdSignal = "INSUFFICIENT DATA",
            emaTrend = "INSUFFICIENT DATA",
            candlePattern = "Awaiting Real Market Data",
            momentumConfirmation = "NO DATA",
            isStrongSignal = false
        )
    }

    @Deprecated("Synthetic price generation removed from production signal paths", ReplaceWith("emptyList()"))
    fun generatePriceSeriesForAsset(asset: MarketAsset): List<Double> {
        return emptyList()
    }

}
