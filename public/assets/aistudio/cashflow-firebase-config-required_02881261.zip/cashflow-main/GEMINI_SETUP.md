CASH FLOW AI — GEMINI API SETUP

SECURITY
- Do NOT put your real Gemini API key in source code, .env.example, or this ZIP.
- The key you pasted into chat should be considered exposed. Revoke/delete it in Google AI Studio and create a replacement.
- Do not upload a real API key to GitHub, even if the repository is private.

GITHUB ACTIONS SETUP
1. Open https://github.com/vybetone/cashflow
2. Go to Settings > Secrets and variables > Actions.
3. Choose New repository secret.
4. Name: GEMINI_API_KEY
5. Secret: paste your newly generated Gemini API key.
6. Save the secret.
7. Upload/commit the project files to the main branch, then open Actions and run
   "Build CashFlow AI APK" (or let a push trigger it).
8. Check the build logs. Never print the secret value in logs.

IMPORTANT
The workflow writes GitHub Actions secrets into a temporary .env file for the build.
The Android app currently reads the key through BuildConfig, which can make the key
extractable from the APK. For a production release, use a secure backend/proxy instead
of shipping a long-lived API key inside the Android APK.

FIREBASE
The workflow also expects GOOGLE_SERVICES_JSON unless app/google-services.json is
already included. Add it as a separate repository secret containing the full contents
of the Firebase google-services.json for application ID:
com.aistudio.cashflow.a3k9p

This ZIP does not contain your API key or Firebase private configuration.

BUILD BEHAVIOR UPDATE
The workflow no longer fails solely because google-services.json is absent.
It emits a warning so an APK build can proceed when the Google Services plugin permits
missing configuration. Firebase-backed features may still fail at runtime until valid
configuration is added. For a fully configured app, add GOOGLE_SERVICES_JSON as above.


FIREBASE CONFIGURATION (REQUIRED)
- The real Firebase file downloaded for project `cash-flow-5d539` and Android package
  `com.aistudio.cashflow.a3k9p` is included at `app/google-services.json`.
- The GitHub Actions workflow validates the file and fails the build if it is missing,
  invalid JSON, or belongs to a different Firebase project/package.
- Do not replace it with a guessed or manually fabricated file.
