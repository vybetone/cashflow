# CashFlow AI — Simulation Removal Report

## Outcome

The source has been changed to prefer genuine data or an explicit unavailable state over fabricated trading results. The existing Kotlin/Compose architecture and overall screen structure were retained; the chart presentation now states when no real chart frame is available instead of drawing a pretend market chart.

## Production paths changed

| Area | Change | Result / limitation |
|---|---|---|
| Screen capture | Removed generated-chart fallback | Only real MediaProjection frames are analyzed; empty capture cycles are skipped |
| Camera scanner | Removed generated camera chart | Preview remains; real CameraX frame capture is not yet implemented and is reported clearly |
| Market asset prices | Removed hardcoded base-price display | UI requests a live quote rather than showing a baked-in number |
| Market data parsing | Removed close-as-OHLC and missing-field price fallbacks; requires source timestamps/fields | Missing/invalid API data fails instead of being turned into a plausible quote |
| Close-only signal engine | Removed synthetic candle geometry and fixed percentage levels | Returns `WAIT` until genuine OHLC/ATR-based risk levels are wired in |
| Gemini parsing | Requires valid response fields and action/confidence ranges | Malformed or missing fields produce an analysis failure, not a default BUY |
| Broker manager | Removed sample positions, fake latency, random position prices/P&L, fake tickets and success state | All broker actions fail closed; no broker adapter currently exists |
| Auto-trading | Cannot be armed and stored connection flags are cleared | No orders can be sent by this build |
| Analytics | Removed hardcoded win-rate/sample-size/risk metrics and fabricated strategy uplift | Metrics show N/A until broker-confirmed outcomes and actual equity/fee data exist |
| Startup database | No new demo data is seeded; exact known sample rows from older versions are cleaned up | User journal entries and ambiguous budget rows are preserved |
| Update checker | Removed mock “up to date” result | Version status remains unverified until a real release registry is integrated |

## Database compatibility

Legacy Room columns such as `simulatedCommissionUsd` and `simulatedSlippagePips` remain in the schema to avoid an unnecessary destructive migration. Their new model defaults are zero; legacy simulated outcomes are excluded from verified performance evaluation. The `SIMULATED` provenance value remains for historical records only.

## Verification

- Source ZIP integrity: passed.
- Static delimiter scan of changed Kotlin files: passed.
- Kotlin compiler syntax-level scan: no parser diagnostics were found, but full compilation could not be performed because Android/Gradle dependencies are not available locally.
- `./gradlew testDebugUnitTest --no-daemon --offline`: **blocked**, because the wrapper attempted to download Gradle 9.3.1 and network DNS access to `services.gradle.org` failed.

Do not treat this report as a successful Android build or APK test. Run the full build and test suite in Android Studio or a network-enabled CI environment before installation.
