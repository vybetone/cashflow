package com.example

import com.example.data.BrokerAccountEntity
import com.example.data.BrokerConnectionManager
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class BrokerSafetyRegressionTest {
    private fun account() = BrokerAccountEntity(
        brokerType = "METATRADER_5",
        accountName = "Test account",
        accountId = "test-login",
        apiTokenOrPassword = "test-only-token",
        serverOrEndpoint = "test-endpoint",
        environment = "DEMO"
    )

    @Test
    fun connectionFailsClosedWhenNoRealAdapterExists() = runTest {
        val manager = BrokerConnectionManager(this)
        var success = true
        var message = ""
        manager.connect(account()) { result, text -> success = result; message = text }
        advanceUntilIdle()
        assertFalse(success)
        assertEquals("ERROR", manager.connectionStatus.value)
        assertTrue(message.contains("no verified"))
        assertTrue(manager.connectedAccount.value == null)
    }

    @Test
    fun tradeRequestNeverCreatesSyntheticTicketOrPosition() = runTest {
        val manager = BrokerConnectionManager(this)
        var success = true
        var message = ""
        var position: com.example.data.BrokerPosition? = null
        manager.executeTrade("EUR/USD", "BUY", 1.1, 1.09, 1.12, 0.1) { ok, text, pos ->
            success = ok; message = text; position = pos
        }
        advanceUntilIdle()
        assertFalse(success)
        assertTrue(message.contains("No order was submitted"))
        assertEquals(null, position)
        assertTrue(manager.openPositions.value.isEmpty())
    }

    @Test
    fun pingDoesNotInventLatency() = runTest {
        val manager = BrokerConnectionManager(this)
        var ping = 0L
        manager.testPing(account()) { ping = it }
        advanceUntilIdle()
        assertEquals(-1L, ping)
        assertEquals(-1L, manager.currentPingMs.value)
    }

    @Test
    fun noPositionsAreSeededAtStartup() = runTest {
        val manager = BrokerConnectionManager(this)
        assertTrue(manager.openPositions.value.isEmpty())
        assertEquals("DISCONNECTED", manager.connectionStatus.value)
    }

    @Test
    fun dailyLossRolloverResetsOnlyWhenUtcDayChanges() {
        val oldDay = 1_700_000_000_000L
        val account = account().copy(
            dailyLossLimit = 500.0,
            dailyRealizedLoss = 125.0,
            dailyLossResetTimestamp = oldDay,
            isCircuitBreakerTripped = true
        )
        val rolled = BrokerConnectionManager.checkAndRolloverDailyLoss(account, oldDay + 48L * 60L * 60L * 1000L)
        assertEquals(0.0, rolled.dailyRealizedLoss, 0.0001)
        assertFalse(rolled.isCircuitBreakerTripped)
    }
}
