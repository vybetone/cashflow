package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.testTag
import com.example.data.TradingSignalEntity

@Composable
fun LiveChartOverlayCanvas(
    signal: TradingSignalEntity?,
    isAnalyzing: Boolean,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .fillMaxSize()
            .testTag("live_chart_overlay_canvas")
    ) {
        val w = size.width
        val h = size.height

        if (w <= 0 || h <= 0) return@Canvas

        // Draw crosshair grid lines
        val gridColor = Color(0xFF263238)
        val dashedEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)

        // Draw horizontal grid lines
        for (i in 1..4) {
            val y = h * (i / 5f)
            drawLine(
                color = gridColor,
                start = Offset(0f, y),
                end = Offset(w, y),
                strokeWidth = 1f,
                pathEffect = dashedEffect
            )
        }

        // Draw vertical grid lines
        for (i in 1..4) {
            val x = w * (i / 5f)
            drawLine(
                color = gridColor,
                start = Offset(x, 0f),
                end = Offset(x, h),
                strokeWidth = 1f,
                pathEffect = dashedEffect
            )
        }

        // If currently analyzing, draw scanning laser line
        if (isAnalyzing) {
            val laserY = (System.currentTimeMillis() % 2000) / 2000f * h
            drawLine(
                color = Color(0xFF00E676),
                start = Offset(0f, laserY),
                end = Offset(w, laserY),
                strokeWidth = 3f
            )
        }

        // No price lines or target zones are drawn here because this canvas has no real chart scale.
        // Real chart content must come from the captured screen or a validated OHLC series.
    }
}
