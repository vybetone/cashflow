package com.example.data

import android.content.Context
import android.graphics.Bitmap
import kotlinx.coroutines.flow.Flow
import java.io.File
import java.io.FileOutputStream

class CashFlowRepository(
    private val tradingSignalDao: TradingSignalDao,
    private val tradeJournalDao: TradeJournalDao,
    private val transactionDao: TransactionDao,
    private val budgetDao: BudgetDao,
    private val brokerAccountDao: BrokerAccountDao
) {
    val allSignals: Flow<List<TradingSignalEntity>> = tradingSignalDao.getAllSignals()
    val allJournalTrades: Flow<List<TradeJournalEntity>> = tradeJournalDao.getAllTrades()
    val totalJournalPnL: Flow<Double?> = tradeJournalDao.getTotalPnL()
    val winCount: Flow<Int> = tradeJournalDao.getWinCount()
    val totalClosedTradesCount: Flow<Int> = tradeJournalDao.getTotalClosedTradesCount()

    val allTransactions: Flow<List<TransactionEntity>> = transactionDao.getAllTransactions()
    val allBudgets: Flow<List<BudgetEntity>> = budgetDao.getAllBudgets()
    val allBrokerAccounts: Flow<List<BrokerAccountEntity>> = brokerAccountDao.getAllAccounts()
    val activeBrokerAccount: Flow<BrokerAccountEntity?> = brokerAccountDao.getActiveConnectedAccount()

    private val geminiEngine = GeminiTradingEngine()

    suspend fun analyzeAndSaveSignal(
        bitmap: Bitmap,
        context: Context,
        source: String = "SCREEN_ANALYSIS",
        preferredModel: String = "gemini-3.5-flash",
        targetAsset: MarketAsset? = null
    ): TradingSignalEntity {
        val signal = geminiEngine.analyzeChartImage(bitmap, source, preferredModel, targetAsset)
        
        // Save image to internal storage
        val filename = "chart_${System.currentTimeMillis()}.jpg"
        val file = File(context.cacheDir, filename)
        try {
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val savedSignal = signal.copy(imageUri = file.absolutePath)
        val insertedId = tradingSignalDao.insertSignal(savedSignal)
        return savedSignal.copy(id = insertedId)
    }

    suspend fun analyzeMarketQuoteAndSaveSignal(
        quote: GenuineMarketQuote,
        userInstructions: String? = null,
        preferredModel: String = "gemini-3.5-flash",
        brokerContext: String? = null
    ): TradingSignalEntity {
        val signal = geminiEngine.analyzeMarketDataWithAi(quote, userInstructions, preferredModel, brokerContext)
        val insertedId = tradingSignalDao.insertSignal(signal)
        return signal.copy(id = insertedId)
    }

    suspend fun chatWithAssistant(
        quote: GenuineMarketQuote,
        history: List<AssistantChatMessage>,
        userMessage: String,
        preferredModel: String = "gemini-3.5-flash"
    ): String {
        return geminiEngine.chatWithTradingAssistant(quote, history, userMessage, preferredModel)
    }

    suspend fun insertSignal(signal: TradingSignalEntity): Long = tradingSignalDao.insertSignal(signal)
    suspend fun updateSignal(signal: TradingSignalEntity) = tradingSignalDao.updateSignal(signal)
    suspend fun deleteSignal(id: Long) = tradingSignalDao.deleteSignalById(id)

    suspend fun insertJournalTrade(trade: TradeJournalEntity): Long = tradeJournalDao.insertTrade(trade)
    suspend fun updateJournalTrade(trade: TradeJournalEntity) = tradeJournalDao.updateTrade(trade)
    suspend fun deleteJournalTrade(id: Long) = tradeJournalDao.deleteTradeById(id)

    suspend fun insertTransaction(transaction: TransactionEntity) = transactionDao.insertTransaction(transaction)
    suspend fun updateTransaction(transaction: TransactionEntity) = transactionDao.updateTransaction(transaction)
    suspend fun deleteTransaction(transaction: TransactionEntity) = transactionDao.deleteTransaction(transaction)

    suspend fun saveBudget(budget: BudgetEntity) = budgetDao.insertOrUpdateBudget(budget)

    suspend fun insertBrokerAccount(account: BrokerAccountEntity): Long = brokerAccountDao.insertAccount(account)
    suspend fun updateBrokerAccount(account: BrokerAccountEntity) = brokerAccountDao.updateAccount(account)
    suspend fun deleteBrokerAccount(account: BrokerAccountEntity) = brokerAccountDao.deleteAccount(account)
    suspend fun disconnectAllBrokers() = brokerAccountDao.disconnectAll()
    suspend fun setActiveBroker(id: Long) {
        brokerAccountDao.disconnectAll()
        brokerAccountDao.setActiveConnected(id)
    }

    suspend fun seedInitialDataIfNeeded() {
        // Cleanup only rows uniquely identified as samples inserted by older app versions.
        // Never wipe user-created transactions, budgets, journal entries, or genuine signals.
        tradingSignalDao.deleteKnownSeededSampleSignals()
        transactionDao.deleteKnownSeededSampleTransactions()
        brokerAccountDao.deleteKnownSeededSampleAccounts()
        brokerAccountDao.disconnectAll()
    }

}
