package com.example.data

data class TradingSignal(
    val symbol: String = "BTC/USD",
    val signalType: String = "WAIT", // "BUY", "SELL", "WAIT"
    val confidencePercentage: Int = 0, // 0 to 100
    val entryPrice: Double = 0.0,
    val stopLoss: Double = 0.0,
    val takeProfit: Double = 0.0,
    val analysisReason: String = "Analysis unavailable: no verified market evidence supplied.",
    val timestamp: Long = System.currentTimeMillis(),
    val rsiValue: Double = 0.0,
    val macdSignal: String = "INSUFFICIENT DATA",
    val emaTrend: String = "INSUFFICIENT DATA",
    val candlePattern: String = "UNAVAILABLE",
    val momentumConfirmation: String = "NO DATA",
    val isStrongSignal: Boolean = confidencePercentage >= 90
)
