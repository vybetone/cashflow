package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TradingSignalDao {
    @Query("SELECT * FROM trading_signals ORDER BY timestamp DESC")
    fun getAllSignals(): Flow<List<TradingSignalEntity>>

    @Query("SELECT * FROM trading_signals WHERE id = :id")
    suspend fun getSignalById(id: Long): TradingSignalEntity?

    @Query("SELECT * FROM trading_signals WHERE symbol LIKE '%' || :query || '%' OR action LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    fun searchSignals(query: String): Flow<List<TradingSignalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSignal(signal: TradingSignalEntity): Long

    @Update
    suspend fun updateSignal(signal: TradingSignalEntity)

    @Query("DELETE FROM trading_signals WHERE id = :id")
    suspend fun deleteSignalById(id: Long)

    @Query("SELECT COUNT(*) FROM trading_signals")
    fun getSignalCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM trading_signals")
    suspend fun getSignalCountSync(): Int

    @Query("DELETE FROM trading_signals WHERE reasoning LIKE '%Bullish order block defense at 1.0850%' OR reasoning LIKE '%Clean bullish flag breakout above 1.3030 resistance%' OR reasoning LIKE '%Rejection at key psychological resistance 153.20%' OR reasoning LIKE '%Major safe haven accumulation bounce off $2,648 demand zone%' OR reasoning LIKE '%High probability liquidity sweep below $64,800%' OR reasoning LIKE '%Ethereum holding multi-day ascending trendline%' OR reasoning LIKE '%Classic 1h Double Bottom formation resting on key 200 EMA%' OR reasoning LIKE '%High-momentum breakout above $245 resistance shelf%' OR reasoning LIKE '%Symmetrical triangle breakout towards $234 level%')")
    suspend fun deleteKnownSeededSampleSignals()
}
