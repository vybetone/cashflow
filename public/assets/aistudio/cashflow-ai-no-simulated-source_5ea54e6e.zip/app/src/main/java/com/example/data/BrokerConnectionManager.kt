package com.example.data

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * Broker gateway that fails closed until a real broker-specific adapter is installed.
 * It intentionally does not invent connection state, ping times, order tickets, prices, or P&L.
 */
class BrokerConnectionManager(private val scope: CoroutineScope) {
    private val _connectedAccount = MutableStateFlow<BrokerAccountEntity?>(null)
    val connectedAccount: StateFlow<BrokerAccountEntity?> = _connectedAccount.asStateFlow()

    private val _connectionStatus = MutableStateFlow("DISCONNECTED")
    val connectionStatus: StateFlow<String> = _connectionStatus.asStateFlow()

    private val _currentPingMs = MutableStateFlow(-1L)
    val currentPingMs: StateFlow<Long> = _currentPingMs.asStateFlow()

    private val _openPositions = MutableStateFlow<List<BrokerPosition>>(emptyList())
    val openPositions: StateFlow<List<BrokerPosition>> = _openPositions.asStateFlow()

    private val _executionLogs = MutableStateFlow<List<BrokerExecutionLog>>(emptyList())
    val executionLogs: StateFlow<List<BrokerExecutionLog>> = _executionLogs.asStateFlow()

    var onAccountUpdated: ((BrokerAccountEntity) -> Unit)? = null

    companion object {
        fun getUtcDayStartTimestamp(epochMillis: Long = System.currentTimeMillis()): Long {
            val calendar = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"))
            calendar.timeInMillis = epochMillis
            calendar.set(java.util.Calendar.HOUR_OF_DAY, 0)
            calendar.set(java.util.Calendar.MINUTE, 0)
            calendar.set(java.util.Calendar.SECOND, 0)
            calendar.set(java.util.Calendar.MILLISECOND, 0)
            return calendar.timeInMillis
        }

        fun checkAndRolloverDailyLoss(
            account: BrokerAccountEntity,
            currentTimeMillis: Long = System.currentTimeMillis()
        ): BrokerAccountEntity {
            val currentDayStart = getUtcDayStartTimestamp(currentTimeMillis)
            val accountDayStart = if (account.dailyLossResetTimestamp > 0L) {
                getUtcDayStartTimestamp(account.dailyLossResetTimestamp)
            } else 0L
            return if (currentDayStart > accountDayStart) account.copy(
                dailyRealizedLoss = 0.0,
                isCircuitBreakerTripped = false,
                dailyLossResetTimestamp = currentDayStart
            ) else account
        }
    }

    fun connect(account: BrokerAccountEntity, onComplete: (Boolean, String) -> Unit) {
        scope.launch {
            _connectionStatus.value = "ERROR"
            _connectedAccount.value = null
            _currentPingMs.value = -1L
            val message = "Connection unavailable: no verified ${account.brokerType} broker adapter is implemented. No broker handshake occurred and no trading account is connected."
            addLog(account.brokerType, "CONNECT_REJECTED", message, false)
            onComplete(false, message)
        }
    }

    fun disconnect() {
        _connectedAccount.value = null
        _connectionStatus.value = "DISCONNECTED"
        _currentPingMs.value = -1L
    }

    fun testPing(account: BrokerAccountEntity, onResult: (Long) -> Unit) {
        scope.launch {
            _currentPingMs.value = -1L
            addLog(account.brokerType, "PING_UNAVAILABLE", "Ping unavailable: no real broker connection is configured.", false)
            onResult(-1L)
        }
    }

    fun executeTrade(
        symbol: String,
        side: String,
        entryPrice: Double,
        stopLoss: Double,
        takeProfit: Double,
        volume: Double = 0.05,
        sourceSignalId: Long? = null,
        onComplete: (Boolean, String, BrokerPosition?) -> Unit
    ) {
        scope.launch {
            val brokerName = _connectedAccount.value?.brokerType ?: "BROKER_UNAVAILABLE"
            val message = "Execution rejected: no verified broker adapter is connected. No order was submitted and no ticket was created."
            addLog(brokerName, "ORDER_REJECTED", message, false)
            onComplete(false, message, null)
        }
    }

    fun closePosition(ticketId: String, onComplete: (Boolean, Double) -> Unit) {
        scope.launch {
            val message = "Position close unavailable: positions are only shown when loaded from a verified broker adapter."
            addLog("BROKER", "CLOSE_REJECTED", message, false)
            onComplete(false, 0.0)
        }
    }

    /** Test-only helper retained for existing regression tests; no production positions are seeded. */
    fun updatePositionPnLForTesting(ticketId: String, pnl: Double) {
        val list = _openPositions.value.toMutableList()
        val idx = list.indexOfFirst { it.ticketId == ticketId }
        if (idx >= 0) {
            list[idx] = list[idx].copy(unrealizedPnL = pnl)
            _openPositions.value = list
        }
    }

    fun closeAllPositions(onComplete: (Int, Double) -> Unit) {
        scope.launch {
            addLog("BROKER", "CLOSE_ALL_UNAVAILABLE", "No verified broker adapter is connected; no positions were changed.", false)
            onComplete(0, 0.0)
        }
    }

    fun resetDailyLoss(reason: String = "Manual User Reset") {
        _connectedAccount.value?.let { acc ->
            val updated = acc.copy(
                dailyRealizedLoss = 0.0,
                isCircuitBreakerTripped = false,
                dailyLossResetTimestamp = getUtcDayStartTimestamp()
            )
            _connectedAccount.value = updated
            onAccountUpdated?.invoke(updated)
            addLog(acc.brokerType, "CIRCUIT_BREAKER_RESET", "Daily-loss circuit breaker reset ($reason).", true)
        }
    }

    private fun addLog(brokerType: String, action: String, message: String, success: Boolean) {
        val newLog = BrokerExecutionLog(
            id = UUID.randomUUID().toString(),
            timestamp = System.currentTimeMillis(),
            brokerType = brokerType,
            action = action,
            message = message,
            success = success
        )
        val logs = _executionLogs.value.toMutableList()
        logs.add(0, newLog)
        if (logs.size > 50) logs.removeAt(logs.lastIndex)
        _executionLogs.value = logs
    }
}
