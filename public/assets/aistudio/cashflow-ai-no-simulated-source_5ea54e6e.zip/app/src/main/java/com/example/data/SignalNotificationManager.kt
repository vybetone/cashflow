package com.example.data

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity

object SignalNotificationManager {

    const val CHANNEL_ID = "cash_flow_ai_high_confidence_signals"
    const val CHANNEL_NAME = "AI Evidence Signals"
    const val CHANNEL_DESC = "Notifications for AI analysis results; evidence scores are not win probabilities."

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = CHANNEL_DESC
                enableVibration(true)
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun sendSignalNotification(context: Context, signal: TradingSignalEntity) {
        if (!hasNotificationPermission(context)) return

        createNotificationChannel(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("OPEN_SCREEN", "HUD")
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            signal.id.toInt().coerceAtLeast(0),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = "⚡ AI Evidence Alert: ${signal.symbol} [${signal.action} ${signal.confidenceScore}/100]"
        val summaryText = "${signal.detectedPatterns} • Entry: ${signal.entryZone}"
        val expandedText = "Asset: ${signal.symbol} (${signal.timeframe})\n" +
                "Action: ${signal.action} (Evidence Score ${signal.confidenceScore}/100)\n" +
                "Pattern: ${signal.detectedPatterns}\n" +
                "Entry Zone: ${signal.entryZone} | SL: ${signal.stopLoss} | TP: ${signal.takeProfit}\n" +
                "Reasoning: ${signal.reasoning}"

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(summaryText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(expandedText))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notificationId = if (signal.id > 0) (signal.id % 10000).toInt() else (System.currentTimeMillis() % 10000).toInt()
        manager.notify(notificationId, builder.build())
    }

    fun sendSignalNotification(context: Context, signal: TradingSignal) {
        if (!hasNotificationPermission(context)) return

        createNotificationChannel(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            (System.currentTimeMillis() % 10000).toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = "⚡ AI Evidence Signal: ${signal.symbol} [${signal.signalType} ${signal.confidencePercentage}/100]"
        val summaryText = "${signal.candlePattern} • Entry: ${signal.entryPrice}"
        val expandedText = "Asset: ${signal.symbol}\n" +
                "Signal: ${signal.signalType} (Evidence Score ${signal.confidencePercentage}/100)\n" +
                "Pattern: ${signal.candlePattern}\n" +
                "Entry: ${signal.entryPrice} | SL: ${signal.stopLoss} | TP: ${signal.takeProfit}\n" +
                "Reasoning: ${signal.analysisReason}"

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(summaryText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(expandedText))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify((System.currentTimeMillis() % 10000).toInt(), builder.build())
    }
}
