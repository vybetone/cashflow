package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.BrokerAccountEntity
import com.example.data.BrokerConnectionManager
import com.example.data.BrokerExecutionLog
import com.example.data.BrokerPosition
import com.example.data.BudgetEntity
import com.example.data.CashFlowRepository
import com.example.data.MarketAsset
import com.example.data.MarketCategory
import com.example.data.MarketUniverse
import com.example.data.SignalRepository
import com.example.data.TradingSignal
import com.example.data.TradeJournalEntity
import com.example.data.AssistantChatMessage
import com.example.data.GenuineMarketQuote
import com.example.data.MarketConnectionState
import com.example.data.RealMarketDataEngine
import com.example.data.TradingSignalEntity
import com.example.data.TransactionCategory
import com.example.data.TransactionEntity
import com.example.data.TransactionType
import com.example.data.ContinuousLearningDao
import com.example.data.SignalPerformanceOutcomeEntity
import com.example.data.ImprovementProposalEntity
import com.example.data.ObservationSource
import com.example.data.ProposalStatus
import com.example.data.RemoteConfigPayload
import com.example.data.QuantitativeEvaluationEngine
import com.example.data.EvaluationReport
import com.example.data.CandidateComparisonResult
import com.example.data.SecureRemoteConfigManager
import com.example.data.ConfigValidationResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class CashFlowViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CashFlowRepository
    private val aiSignalRepository: SignalRepository = SignalRepository()
    private val brokerConnectionManager: BrokerConnectionManager = BrokerConnectionManager(viewModelScope)
    private val marketDataEngine: RealMarketDataEngine = RealMarketDataEngine(viewModelScope)
    private val continuousLearningDao: ContinuousLearningDao
    private val evaluationEngine: QuantitativeEvaluationEngine = QuantitativeEvaluationEngine()
    private val remoteConfigManager: SecureRemoteConfigManager = SecureRemoteConfigManager()

    private val _activeRemoteConfig = MutableStateFlow(remoteConfigManager.getActiveConfig())
    val activeRemoteConfig: StateFlow<RemoteConfigPayload> = _activeRemoteConfig.asStateFlow()

    private val _evaluationReport = MutableStateFlow<EvaluationReport?>(null)
    val evaluationReport: StateFlow<EvaluationReport?> = _evaluationReport.asStateFlow()

    val allProposals: StateFlow<List<ImprovementProposalEntity>>
    val allPerformanceOutcomes: StateFlow<List<SignalPerformanceOutcomeEntity>>

    private val _evaluationStatusText = MutableStateFlow<String?>("Awaiting evaluation run")
    val evaluationStatusText: StateFlow<String?> = _evaluationStatusText.asStateFlow()

    private val _updateCheckStatusText = MutableStateFlow<String?>("Update status not verified: no live release-registry check has completed.")
    val updateCheckStatusText: StateFlow<String?> = _updateCheckStatusText.asStateFlow()

    val liveMarketQuotes: StateFlow<Map<String, GenuineMarketQuote>> = marketDataEngine.marketQuotes
    val marketConnectionState: StateFlow<MarketConnectionState> = marketDataEngine.connectionState
    val isMarketDataLoading: StateFlow<Boolean> = marketDataEngine.isLoading
    val marketDataErrorMessage: StateFlow<String?> = marketDataEngine.lastErrorMessage

    fun refreshMarketData() {
        marketDataEngine.refreshNow()
    }

    val highConfidenceAiSignal: StateFlow<TradingSignal?> = aiSignalRepository.latestHighConfidenceSignal

    val allSignals: StateFlow<List<TradingSignalEntity>>
    val allJournalTrades: StateFlow<List<TradeJournalEntity>>
    val totalJournalPnL: StateFlow<Double?>
    val winCount: StateFlow<Int>
    val totalClosedTradesCount: StateFlow<Int>

    val allTransactions: StateFlow<List<TransactionEntity>>
    val allBudgets: StateFlow<List<BudgetEntity>>

    val allBrokerAccounts: StateFlow<List<BrokerAccountEntity>>
    val activeBrokerAccount: StateFlow<BrokerAccountEntity?>
    val brokerConnectionStatus: StateFlow<String> = brokerConnectionManager.connectionStatus
    val brokerPingMs: StateFlow<Long> = brokerConnectionManager.currentPingMs
    val openBrokerPositions: StateFlow<List<BrokerPosition>> = brokerConnectionManager.openPositions
    val brokerExecutionLogs: StateFlow<List<BrokerExecutionLog>> = brokerConnectionManager.executionLogs

    private val _brokerFeedbackMessage = MutableStateFlow<String?>(null)
    val brokerFeedbackMessage: StateFlow<String?> = _brokerFeedbackMessage.asStateFlow()

    fun clearBrokerFeedbackMessage() {
        _brokerFeedbackMessage.value = null
    }

    // Confirmed Trade Universe (1 FOREX, 2 GOLD, 3 CRYPTO, 4 STOCKS, 5 ALL OF THEM)
    private val _selectedMarketCategory = MutableStateFlow(MarketCategory.ALL_MARKETS)
    val selectedMarketCategory: StateFlow<MarketCategory> = _selectedMarketCategory.asStateFlow()

    private val _selectedMarketAsset = MutableStateFlow(MarketUniverse.EUR_USD)
    val selectedMarketAsset: StateFlow<MarketAsset> = _selectedMarketAsset.asStateFlow()

    private val _autoTradeMarketUniverse = MutableStateFlow(MarketCategory.ALL_MARKETS)
    val autoTradeMarketUniverse: StateFlow<MarketCategory> = _autoTradeMarketUniverse.asStateFlow()

    fun setMarketCategory(category: MarketCategory) {
        _selectedMarketCategory.value = category
        val categoryAssets = MarketUniverse.getAssetsForCategory(category)
        if (categoryAssets.isNotEmpty() && _selectedMarketAsset.value !in categoryAssets) {
            _selectedMarketAsset.value = categoryAssets.first()
        }
    }

    fun setSelectedMarketAsset(asset: MarketAsset) {
        _selectedMarketAsset.value = asset
        _selectedMarketCategory.value = asset.category
        recalculateHighConfidenceSignal(asset.symbol)
    }

    fun setAutoTradeMarketUniverse(category: MarketCategory) {
        _autoTradeMarketUniverse.value = category
        val account = activeBrokerAccount.value
        if (account != null) {
            _brokerFeedbackMessage.value = "Auto-Trade filter updated: ${category.badgeLabel}"
        }
    }

    val currentMarketQuote: StateFlow<GenuineMarketQuote> = combine(
        marketDataEngine.marketQuotes,
        _selectedMarketAsset
    ) { quotes, asset ->
        quotes[asset.symbol] ?: marketDataEngine.getQuoteForSymbol(asset.symbol)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        marketDataEngine.getQuoteForSymbol("EUR/USD")
    )

    private val _latestEvidenceSignal = MutableStateFlow<TradingSignalEntity?>(null)
    val latestEvidenceSignal: StateFlow<TradingSignalEntity?> = _latestEvidenceSignal.asStateFlow()

    private val _isAiAssistantRunning = MutableStateFlow(false)
    val isAiAssistantRunning: StateFlow<Boolean> = _isAiAssistantRunning.asStateFlow()

    private val _aiAssistantStatusText = MutableStateFlow<String?>("Ready for Gemini quantitative analysis")
    val aiAssistantStatusText: StateFlow<String?> = _aiAssistantStatusText.asStateFlow()

    private val _assistantChatMessages = MutableStateFlow<List<AssistantChatMessage>>(
        listOf(
            AssistantChatMessage(
                isUser = false,
                text = "👋 Welcome to CASH FLOW AI Real Trading Assistant!\n\nI can analyze verified market telemetry when a live quote is available. If data or Gemini is unavailable, I will say so instead of inventing prices or signals. Broker execution is disabled until a verified broker-specific adapter is installed and tested."
            )
        )
    )
    val assistantChatMessages: StateFlow<List<AssistantChatMessage>> = _assistantChatMessages.asStateFlow()

    private val _selectedTab = MutableStateFlow(0)
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _signalFilter = MutableStateFlow("ALL") // "ALL", "BUY", "SELL", "WAIT"
    val signalFilter: StateFlow<String> = _signalFilter.asStateFlow()

    private val _isAnalyzingChart = MutableStateFlow(false)
    val isAnalyzingChart: StateFlow<Boolean> = _isAnalyzingChart.asStateFlow()

    private val _latestActiveSignal = MutableStateFlow<TradingSignalEntity?>(null)
    val latestActiveSignal: StateFlow<TradingSignalEntity?> = _latestActiveSignal.asStateFlow()

    private val _appThemeMode = MutableStateFlow(com.example.ui.theme.AppThemeMode.DARK)
    val appThemeMode: StateFlow<com.example.ui.theme.AppThemeMode> = _appThemeMode.asStateFlow()

    fun setAppThemeMode(mode: com.example.ui.theme.AppThemeMode) {
        _appThemeMode.value = mode
    }

    private val _preferredModel = MutableStateFlow("gemini-3.5-flash")
    val preferredModel: StateFlow<String> = _preferredModel.asStateFlow()

    private val _autoCaptureIntervalSeconds = MutableStateFlow(5)
    val autoCaptureIntervalSeconds: StateFlow<Int> = _autoCaptureIntervalSeconds.asStateFlow()

    private val _isScreenCaptureActive = MutableStateFlow(false)
    val isScreenCaptureActive: StateFlow<Boolean> = _isScreenCaptureActive.asStateFlow()

    private val _showAddJournalDialog = MutableStateFlow(false)
    val showAddJournalDialog: StateFlow<Boolean> = _showAddJournalDialog.asStateFlow()

    private val _selectedTypeFilter = MutableStateFlow<TransactionType?>(null)
    val selectedTypeFilter: StateFlow<TransactionType?> = _selectedTypeFilter.asStateFlow()

    private val _selectedCategoryFilter = MutableStateFlow<TransactionCategory?>(null)
    val selectedCategoryFilter: StateFlow<TransactionCategory?> = _selectedCategoryFilter.asStateFlow()

    private val _showAddTransactionSheet = MutableStateFlow(false)
    val showAddTransactionSheet: StateFlow<Boolean> = _showAddTransactionSheet.asStateFlow()

    private val _transactionToEdit = MutableStateFlow<TransactionEntity?>(null)
    val transactionToEdit: StateFlow<TransactionEntity?> = _transactionToEdit.asStateFlow()

    private val _showAddBudgetDialog = MutableStateFlow(false)
    val showAddBudgetDialog: StateFlow<Boolean> = _showAddBudgetDialog.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application)
        continuousLearningDao = database.continuousLearningDao()
        repository = CashFlowRepository(
            tradingSignalDao = database.tradingSignalDao(),
            tradeJournalDao = database.tradeJournalDao(),
            transactionDao = database.transactionDao(),
            budgetDao = database.budgetDao(),
            brokerAccountDao = database.brokerAccountDao()
        )

        allProposals = continuousLearningDao.getAllProposals().stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        allPerformanceOutcomes = continuousLearningDao.getAllOutcomes().stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        allBrokerAccounts = repository.allBrokerAccounts.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        activeBrokerAccount = repository.activeBrokerAccount.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            null
        )

        // Setup real-time continuous screen capture listener
        com.example.data.ScreenCaptureService.onFrameCapturedListener = { bitmap ->
            processChartFrameBitmap(bitmap, "SCREEN_ANALYSIS")
        }

        viewModelScope.launch {
            repository.seedInitialDataIfNeeded()
            continuousLearningDao.deleteKnownSyntheticImprovementProposals()
            // Auto connect only when a stored account is flagged connected; startup cleanup clears stale flags.
            repository.activeBrokerAccount.collect { acc ->
                if (acc != null && acc.isConnected && brokerConnectionManager.connectionStatus.value == "DISCONNECTED") {
                    brokerConnectionManager.connect(acc) { _, _ -> }
                }
            }
        }

        brokerConnectionManager.onAccountUpdated = { updatedAcc ->
            viewModelScope.launch {
                repository.updateBrokerAccount(updatedAcc)
            }
        }

        allSignals = repository.allSignals.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        allJournalTrades = repository.allJournalTrades.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        totalJournalPnL = repository.totalJournalPnL.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            0.0
        )

        winCount = repository.winCount.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            0
        )

        totalClosedTradesCount = repository.totalClosedTradesCount.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            0
        )

        allTransactions = repository.allTransactions.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        allBudgets = repository.allBudgets.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        // Initialize local notification channel for high-confidence AI signals
        com.example.data.SignalNotificationManager.createNotificationChannel(application)
    }

    val filteredSignals: StateFlow<List<TradingSignalEntity>> = combine(
        allSignals,
        _searchQuery,
        _signalFilter,
        _selectedMarketCategory
    ) { signals, query, actionFilter, marketCat ->
        val allowedSymbols = if (marketCat == MarketCategory.ALL_MARKETS) {
            null
        } else {
            MarketUniverse.getAssetsForCategory(marketCat).map { it.symbol.uppercase() }
        }
        signals.filter { sig ->
            val sigSymbolUpper = sig.symbol.uppercase()
            val matchesCategory = allowedSymbols == null || allowedSymbols.any { 
                sigSymbolUpper.contains(it) || it.contains(sigSymbolUpper)
            }
            val matchesQuery = query.isBlank() ||
                    sig.symbol.contains(query, ignoreCase = true) ||
                    sig.reasoning.contains(query, ignoreCase = true) ||
                    sig.detectedPatterns.contains(query, ignoreCase = true)
            val matchesAction = actionFilter == "ALL" || sig.action.equals(actionFilter, ignoreCase = true)
            matchesCategory && matchesQuery && matchesAction
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredTransactions: StateFlow<List<TransactionEntity>> = combine(
        allTransactions,
        _searchQuery,
        _selectedTypeFilter,
        _selectedCategoryFilter
    ) { transactions, query, typeFilter, categoryFilter ->
        transactions.filter { tx ->
            val matchesQuery = query.isBlank() ||
                    tx.title.contains(query, ignoreCase = true) ||
                    tx.note.contains(query, ignoreCase = true) ||
                    tx.category.displayName.contains(query, ignoreCase = true)
            val matchesType = typeFilter == null || tx.type == typeFilter
            val matchesCategory = categoryFilter == null || tx.category == categoryFilter
            matchesQuery && matchesType && matchesCategory
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalIncome: StateFlow<Double> = allTransactions.combine(MutableStateFlow(Unit)) { txs, _ ->
        txs.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalExpense: StateFlow<Double> = allTransactions.combine(MutableStateFlow(Unit)) { txs, _ ->
        txs.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun setSelectedTab(tabIndex: Int) {
        _selectedTab.value = tabIndex
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSignalFilter(filter: String) {
        _signalFilter.value = filter
    }

    fun setPreferredModel(model: String) {
        _preferredModel.value = model
    }


    fun setAutoCaptureInterval(seconds: Int) {
        _autoCaptureIntervalSeconds.value = seconds
        com.example.data.ScreenCaptureService.updateScanIntervalMs(seconds * 1000L)
    }

    fun startScreenCaptureService(context: android.content.Context, resultCode: Int = -1, data: android.content.Intent? = null) {
        _isScreenCaptureActive.value = true
        if (resultCode != -1 && data != null) {
            com.example.data.ScreenCaptureService.startService(context, resultCode, data)
        } else {
            _isScreenCaptureActive.value = false
            _brokerFeedbackMessage.value = "Screen capture not started: grant Android screen-capture permission first. No generated chart will be analyzed."
        }
    }

    fun stopScreenCaptureService(context: android.content.Context) {
        _isScreenCaptureActive.value = false
        com.example.data.ScreenCaptureService.stopService(context)
    }

    fun onMediaProjectionGranted(context: android.content.Context, resultCode: Int, data: android.content.Intent?) {
        startScreenCaptureService(context, resultCode, data)
    }

    fun onMediaProjectionDenied() {
        _isScreenCaptureActive.value = false
    }

    fun toggleScreenCaptureService(context: android.content.Context) {
        if (_isScreenCaptureActive.value) {
            stopScreenCaptureService(context)
        } else {
            _isScreenCaptureActive.value = false
            _brokerFeedbackMessage.value = "Screen capture requires Android screen-capture permission. No generated chart will be analyzed."
        }
    }

    /** Legacy entry point retained for callers; synthetic chart generation is intentionally disabled. */




    fun reportChartInputUnavailable(message: String) {
        _isAnalyzingChart.value = false
        _brokerFeedbackMessage.value = message
    }

    fun scanAllConfirmedMarkets() {
        viewModelScope.launch {
            _isAnalyzingChart.value = true
            try {
                val assetsToScan = if (_selectedMarketCategory.value == MarketCategory.ALL_MARKETS) {
                    MarketUniverse.allAssets
                } else {
                    MarketUniverse.getAssetsForCategory(_selectedMarketCategory.value)
                }

                val engine = aiSignalRepository.getEngine()
                var persistedCount = 0
                assetsToScan.forEach { asset ->
                    val quote = marketDataEngine.getQuoteForSymbol(asset.symbol)
                    val isFresh = !quote.isStale &&
                        quote.lastPrice > 0.0 &&
                        quote.lastUpdatedTimestamp > 0L &&
                        (System.currentTimeMillis() - quote.lastUpdatedTimestamp) <= 300_000L

                    val isHistoryValid = isFresh &&
                        quote.recentCloses.size >= 5 &&
                        quote.recentCloses.all { it > 0.0 && !it.isNaN() && !it.isInfinite() }

                    val priceHistory = if (isHistoryValid) quote.recentCloses else null
                    val sig = engine.generateSignal(asset.symbol, priceHistory)

                    // Prevent batch scanning from persisting an actionable signal when market history is absent, stale, or invalid
                    if (isHistoryValid && sig.signalType != "WAIT" && sig.confidencePercentage > 0 && sig.entryPrice > 0.0) {
                        val entity = TradingSignalEntity(
                            timestamp = System.currentTimeMillis(),
                            symbol = sig.symbol,
                            timeframe = "15m",
                            action = sig.signalType,
                            confidenceScore = sig.confidencePercentage,
                            reasoning = sig.analysisReason,
                            entryZone = if (asset.decimalDigits == 4) String.format(java.util.Locale.US, "%.4f", sig.entryPrice) else String.format(java.util.Locale.US, "$%.2f", sig.entryPrice),
                            stopLoss = if (asset.decimalDigits == 4) String.format(java.util.Locale.US, "%.4f", sig.stopLoss) else String.format(java.util.Locale.US, "$%.2f", sig.stopLoss),
                            takeProfit = if (asset.decimalDigits == 4) String.format(java.util.Locale.US, "%.4f", sig.takeProfit) else String.format(java.util.Locale.US, "$%.2f", sig.takeProfit),
                            riskRewardRatio = "1:2.8",
                            trendDirection = if (sig.signalType == "SELL") "BEARISH" else "BULLISH",
                            detectedPatterns = sig.candlePattern,
                            keyLevels = "Support: ${sig.stopLoss} | Resistance: ${sig.takeProfit} | Market: ${asset.category.shortName}",
                            source = "SCAN_CONFIRMED_MARKETS"
                        )
                        repository.insertSignal(entity)
                        persistedCount++

                        // If auto-trading is enabled for this category, execute
                        val broker = activeBrokerAccount.value
                        val allowed = when (_autoTradeMarketUniverse.value) {
                            MarketCategory.ALL_MARKETS -> true
                            MarketCategory.FOREX -> asset.category == MarketCategory.FOREX
                            MarketCategory.GOLD -> asset.category == MarketCategory.GOLD
                            MarketCategory.CRYPTO -> asset.category == MarketCategory.CRYPTO
                            MarketCategory.STOCKS -> asset.category == MarketCategory.STOCKS
                        }
                        if (broker != null && broker.autoTradeEnabled && broker.isConnected && brokerConnectionManager.connectionStatus.value in listOf("CONNECTED_LIVE", "CONNECTED_DEMO") && allowed && entity.action != "WAIT" && entity.confidenceScore >= broker.minConfidenceThreshold) {
                            executeSignalOnBroker(entity)
                        }
                    }
                }
                _brokerFeedbackMessage.value = if (persistedCount > 0) {
                    "Scanned ${assetsToScan.size} instruments across ${_selectedMarketCategory.value.shortName}. Generated $persistedCount verified signals."
                } else {
                    "Scanned ${assetsToScan.size} instruments across ${_selectedMarketCategory.value.shortName}. No actionable signal was generated: the close-only engine is disabled until genuine OHLC and volatility-based risk levels are wired through."
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isAnalyzingChart.value = false
            }
        }
    }



    fun processChartFrameBitmap(
        bitmap: Bitmap,
        source: String = "SCREEN_ANALYSIS",
        asset: MarketAsset? = null
    ) {
        val targetAsset = asset ?: _selectedMarketAsset.value
        viewModelScope.launch {
            _isAnalyzingChart.value = true
            try {
                val newSignal = repository.analyzeAndSaveSignal(
                    bitmap = bitmap,
                    context = getApplication(),
                    source = source,
                    preferredModel = _preferredModel.value,
                    targetAsset = targetAsset
                )
                _latestActiveSignal.value = newSignal

                // Trigger local notification for high-confidence patterns
                if (newSignal.confidenceScore >= 70 || newSignal.action != "WAIT") {
                    com.example.data.SignalNotificationManager.sendSignalNotification(
                        getApplication(),
                        newSignal
                    )
                }

                // If auto-trading is enabled on active broker, auto-execute order matching the universe
                val broker = activeBrokerAccount.value
                val isMarketAllowed = when (_autoTradeMarketUniverse.value) {
                    MarketCategory.ALL_MARKETS -> true
                    MarketCategory.FOREX -> targetAsset.category == MarketCategory.FOREX
                    MarketCategory.GOLD -> targetAsset.category == MarketCategory.GOLD
                    MarketCategory.CRYPTO -> targetAsset.category == MarketCategory.CRYPTO
                    MarketCategory.STOCKS -> targetAsset.category == MarketCategory.STOCKS
                }
                if (broker != null && broker.autoTradeEnabled && broker.isConnected && brokerConnectionManager.connectionStatus.value in listOf("CONNECTED_LIVE", "CONNECTED_DEMO") && isMarketAllowed && newSignal.action != "WAIT" && newSignal.confidenceScore >= broker.minConfidenceThreshold) {
                    executeSignalOnBroker(newSignal)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isAnalyzingChart.value = false
            }
        }
    }

    fun sendTestSignalNotification() {
        _brokerFeedbackMessage.value = "Sample BUY notifications are disabled. Notifications are generated only from actual analysis results."
    }

    fun deleteSignal(signal: TradingSignalEntity) {
        viewModelScope.launch {
            repository.deleteSignal(signal.id)
        }
    }

    fun convertSignalToJournalEntry(signal: TradingSignalEntity) {
        val entryPrice = parseValidPriceOrNull(signal.entryZone)
        val slPrice = parseValidPriceOrNull(signal.stopLoss)
        val tpPrice = parseValidPriceOrNull(signal.takeProfit)
        if (signal.action !in listOf("BUY", "SELL") || entryPrice == null || slPrice == null || tpPrice == null) {
            _brokerFeedbackMessage.value = "Journal conversion skipped: signal lacks valid entry, stop-loss, or take-profit prices. No example values were inserted."
            return
        }
        viewModelScope.launch {
            val trade = TradeJournalEntity(
                signalId = signal.id,
                assetSymbol = signal.symbol,
                tradeType = signal.action,
                entryPrice = entryPrice,
                exitPrice = null,
                stopLoss = slPrice,
                takeProfit = tpPrice,
                positionSize = 0.0,
                status = "PLANNED",
                pnl = 0.0,
                notes = "Planned setup only; not broker-executed and no position size supplied. Pattern: ${signal.detectedPatterns}",
                screenshotPath = signal.imageUri,
                chartPattern = signal.detectedPatterns
            )
            repository.insertJournalTrade(trade)
        }
    }

    fun recalculateHighConfidenceSignal(symbol: String = "BTC/USD") {
        viewModelScope.launch {
            val quote = marketDataEngine.getQuoteForSymbol(symbol)
            val isHistoryValid = !quote.isStale && quote.lastPrice > 0.0 &&
                quote.lastUpdatedTimestamp > 0L &&
                (System.currentTimeMillis() - quote.lastUpdatedTimestamp) <= 300_000L &&
                quote.recentCloses.size >= 5 &&
                quote.recentCloses.all { it > 0.0 && !it.isNaN() && !it.isInfinite() }
            val priceHistory = if (isHistoryValid) quote.recentCloses else null
            aiSignalRepository.generateSignal(symbol, priceHistory)
        }
    }

    fun convertAiSignalToJournalEntry(signal: TradingSignal) {
        if (signal.signalType == "WAIT" || signal.confidencePercentage <= 0 || signal.entryPrice <= 0.0) {
            return
        }
        viewModelScope.launch {
            val trade = TradeJournalEntity(
                assetSymbol = signal.symbol,
                tradeType = if (signal.signalType == "SELL") "SELL" else "BUY",
                entryPrice = signal.entryPrice,
                exitPrice = null,
                stopLoss = signal.stopLoss,
                takeProfit = signal.takeProfit,
                positionSize = 0.0,
                status = "PLANNED",
                pnl = 0.0,
                notes = "Planned setup only; not broker-executed and no position size supplied. Evidence Score ${signal.confidencePercentage}/100: ${signal.analysisReason}",
                chartPattern = signal.candlePattern
            )
            repository.insertJournalTrade(trade)
        }
    }

    fun saveJournalTrade(
        symbol: String,
        tradeType: String,
        entryPrice: Double,
        exitPrice: Double?,
        stopLoss: Double,
        takeProfit: Double,
        positionSize: Double,
        status: String,
        notes: String
    ) {
        viewModelScope.launch {
            val pnl = if (status.startsWith("CLOSED") && exitPrice != null) {
                if (tradeType == "BUY") (exitPrice - entryPrice) * positionSize else (entryPrice - exitPrice) * positionSize
            } else 0.0

            val trade = TradeJournalEntity(
                assetSymbol = symbol.trim().ifEmpty { "CUSTOM_ASSET" },
                tradeType = tradeType,
                entryPrice = entryPrice,
                exitPrice = exitPrice,
                stopLoss = stopLoss,
                takeProfit = takeProfit,
                positionSize = positionSize,
                status = status,
                pnl = pnl,
                notes = notes.trim()
            )
            repository.insertJournalTrade(trade)
            _showAddJournalDialog.value = false
        }
    }

    fun deleteJournalTrade(trade: TradeJournalEntity) {
        viewModelScope.launch {
            repository.deleteJournalTrade(trade.id)
        }
    }

    fun openAddJournalDialog() {
        _showAddJournalDialog.value = true
    }

    fun closeAddJournalDialog() {
        _showAddJournalDialog.value = false
    }

    fun setTypeFilter(type: TransactionType?) {
        _selectedTypeFilter.value = type
    }

    fun setCategoryFilter(category: TransactionCategory?) {
        _selectedCategoryFilter.value = category
    }

    fun openAddTransactionSheet(tx: TransactionEntity? = null) {
        _transactionToEdit.value = tx
        _showAddTransactionSheet.value = true
    }

    fun closeAddTransactionSheet() {
        _showAddTransactionSheet.value = false
        _transactionToEdit.value = null
    }

    fun openAddBudgetDialog() {
        _showAddBudgetDialog.value = true
    }

    fun closeAddBudgetDialog() {
        _showAddBudgetDialog.value = false
    }

    fun saveTransaction(
        title: String,
        amount: Double,
        type: TransactionType,
        category: TransactionCategory,
        note: String,
        isRecurring: Boolean
    ) {
        if (title.isBlank() || amount <= 0.0) return
        viewModelScope.launch {
            val existing = _transactionToEdit.value
            if (existing != null) {
                repository.updateTransaction(
                    existing.copy(
                        title = title.trim(),
                        amount = amount,
                        type = type,
                        category = category,
                        note = note.trim(),
                        isRecurring = isRecurring
                    )
                )
            } else {
                repository.insertTransaction(
                    TransactionEntity(
                        title = title.trim(),
                        amount = amount,
                        type = type,
                        category = category,
                        note = note.trim(),
                        isRecurring = isRecurring
                    )
                )
            }
            closeAddTransactionSheet()
        }
    }

    fun deleteTransaction(tx: TransactionEntity) {
        viewModelScope.launch {
            repository.deleteTransaction(tx)
        }
    }

    fun saveBudget(category: TransactionCategory, monthlyLimit: Double) {
        if (monthlyLimit <= 0.0) return
        viewModelScope.launch {
            repository.saveBudget(
                BudgetEntity(
                    category = category,
                    monthlyLimit = monthlyLimit
                )
            )
            closeAddBudgetDialog()
        }
    }

    // --- BROKER CONNECTION & EXECUTION CONTROLS ---

    fun connectBroker(account: BrokerAccountEntity) {
        viewModelScope.launch {
            // Do not mark a database account connected before a real broker handshake succeeds.
            repository.disconnectAllBrokers()
            brokerConnectionManager.connect(account) { success, msg ->
                if (!success) repository.disconnectAllBrokers()
                _brokerFeedbackMessage.value = msg
            }
        }
    }

    fun disconnectBroker() {
        viewModelScope.launch {
            repository.disconnectAllBrokers()
            brokerConnectionManager.disconnect()
            _brokerFeedbackMessage.value = "Disconnected from active broker."
        }
    }

    fun testBrokerPing(account: BrokerAccountEntity) {
        brokerConnectionManager.testPing(account) { ping ->
            _brokerFeedbackMessage.value = if (ping >= 0L) "Ping to ${account.brokerType}: ${ping}ms" else "Ping unavailable: no verified broker connection is configured."
        }
    }

    fun saveBrokerAccount(account: BrokerAccountEntity) {
        viewModelScope.launch {
            if (account.id > 0) {
                repository.updateBrokerAccount(account)
            } else {
                repository.insertBrokerAccount(account)
            }
            _brokerFeedbackMessage.value = "Broker account '${account.accountName}' saved."
        }
    }

    fun deleteBrokerAccount(account: BrokerAccountEntity) {
        viewModelScope.launch {
            if (account.isConnected) {
                brokerConnectionManager.disconnect()
            }
            repository.deleteBrokerAccount(account)
            _brokerFeedbackMessage.value = "Broker account removed."
        }
    }

    fun toggleBrokerAutoTrade(enabled: Boolean) {
        viewModelScope.launch {
            if (enabled) {
                _brokerFeedbackMessage.value = "Auto-trading cannot be armed: no verified broker adapter is implemented or connected."
                return@launch
            }
            val current = activeBrokerAccount.value
            if (current != null) {
                repository.updateBrokerAccount(current.copy(autoTradeEnabled = false))
            }
            _brokerFeedbackMessage.value = "Auto-trading is disabled until a verified broker adapter is implemented and tested."
        }
    }

    fun updateBrokerRiskSettings(
        threshold: Int,
        lotSize: Double,
        maxRisk: Double,
        autoSlTp: Boolean,
        dailyLossLimit: Double? = null
    ) {
        viewModelScope.launch {
            val current = activeBrokerAccount.value
            if (current != null) {
                val updated = current.copy(
                    minConfidenceThreshold = threshold.coerceIn(50, 99),
                    defaultLotSize = lotSize.coerceAtLeast(0.01),
                    maxRiskPercentage = maxRisk.coerceIn(0.1, 10.0),
                    autoStopLossTakeProfit = autoSlTp,
                    dailyLossLimit = (dailyLossLimit ?: current.dailyLossLimit).coerceAtLeast(10.0)
                )
                repository.updateBrokerAccount(updated)
                _brokerFeedbackMessage.value = "Broker risk parameters updated."
            }
        }
    }

    fun resetBrokerDailyLossCircuitBreaker() {
        if (activeBrokerAccount.value == null) {
            _brokerFeedbackMessage.value = "Circuit breaker reset unavailable: no verified broker account is connected."
            return
        }
        brokerConnectionManager.resetDailyLoss("Manual UI Reset")
        _brokerFeedbackMessage.value = "Daily-loss circuit breaker reset for the active account."
    }

    fun executeSignalOnBroker(signal: TradingSignalEntity, overrideVolume: Double? = null) {
        if (signal.action != "BUY" && signal.action != "SELL") {
            _brokerFeedbackMessage.value = "Execution rejected: Signal action is '${signal.action}'. Only BUY or SELL can be executed."
            return
        }

        val active = activeBrokerAccount.value
        if (active != null && active.dailyLossLimit > 0.0 && (active.isCircuitBreakerTripped || active.dailyRealizedLoss >= active.dailyLossLimit)) {
            _brokerFeedbackMessage.value = "Execution rejected: Daily-loss circuit breaker is active for ${active.brokerType} (Realized loss: $${String.format(java.util.Locale.US, "%.2f", active.dailyRealizedLoss)} >= Limit: $${String.format(java.util.Locale.US, "%.2f", active.dailyLossLimit)}). Trading halted for current session."
            return
        }

        val quote = marketDataEngine.getQuoteForSymbol(signal.symbol)
        val isQuoteValid = !quote.isStale &&
            quote.lastPrice > 0.0 &&
            quote.lastUpdatedTimestamp > 0L &&
            (System.currentTimeMillis() - quote.lastUpdatedTimestamp) <= 300_000L &&
            !quote.isBidAskEstimated

        if (!isQuoteValid) {
            _brokerFeedbackMessage.value = "Execution rejected: market data for ${signal.symbol} is stale, unavailable, or uses indicative estimated bid/ask values."
            return
        }

        if (active == null || !active.isConnected || brokerConnectionManager.connectionStatus.value !in listOf("CONNECTED_LIVE", "CONNECTED_DEMO")) {
            _brokerFeedbackMessage.value = "Execution rejected: no verified broker connection is active. No order was submitted."
            return
        }

        val entryPrice = parseValidPriceOrNull(signal.entryZone)
        if (entryPrice == null) {
            _brokerFeedbackMessage.value = "Execution rejected: Invalid or unparseable entry price (${signal.entryZone})."
            return
        }

        val volume = overrideVolume ?: active?.defaultLotSize ?: 0.10
        val slPrice = parseValidPriceOrNull(signal.stopLoss)
        val tpPrice = parseValidPriceOrNull(signal.takeProfit)
        if (slPrice == null || tpPrice == null) {
            _brokerFeedbackMessage.value = "Execution rejected: the signal does not contain validated stop-loss and take-profit prices. No levels were invented."
            return
        }

        brokerConnectionManager.executeTrade(
            symbol = signal.symbol,
            side = signal.action,
            entryPrice = entryPrice,
            stopLoss = slPrice,
            takeProfit = tpPrice,
            volume = volume,
            sourceSignalId = signal.id
        ) { success, msg, position ->
            _brokerFeedbackMessage.value = msg
            if (success && position != null) {
                // Record to Trade Journal automatically
                viewModelScope.launch {
                    val trade = TradeJournalEntity(
                        signalId = signal.id,
                        assetSymbol = signal.symbol,
                        tradeType = if (signal.action == "SELL") "SELL" else "BUY",
                        entryPrice = entryPrice,
                        exitPrice = null,
                        stopLoss = slPrice,
                        takeProfit = tpPrice,
                        positionSize = volume,
                        status = "OPEN",
                        pnl = 0.0,
                        notes = "Broker Execution on ${position.brokerType} [Ticket #${position.ticketId}] | Pattern: ${signal.detectedPatterns}",
                        screenshotPath = signal.imageUri,
                        chartPattern = signal.detectedPatterns
                    )
                    repository.insertJournalTrade(trade)
                }
            }
        }
    }

    fun executeManualTrade(symbol: String, side: String, entryPrice: Double, sl: Double, tp: Double, volume: Double) {
        val active = activeBrokerAccount.value
        if (active != null && active.dailyLossLimit > 0.0 && (active.isCircuitBreakerTripped || active.dailyRealizedLoss >= active.dailyLossLimit)) {
            _brokerFeedbackMessage.value = "Execution rejected: Daily-loss circuit breaker is active for ${active.brokerType}."
            return
        }

        brokerConnectionManager.executeTrade(
            symbol = symbol,
            side = side,
            entryPrice = entryPrice,
            stopLoss = sl,
            takeProfit = tp,
            volume = volume
        ) { success, msg, position ->
            _brokerFeedbackMessage.value = msg
            if (success && position != null) {
                viewModelScope.launch {
                    val trade = TradeJournalEntity(
                        assetSymbol = symbol,
                        tradeType = side.uppercase(),
                        entryPrice = entryPrice,
                        exitPrice = null,
                        stopLoss = sl,
                        takeProfit = tp,
                        positionSize = volume,
                        status = "OPEN",
                        pnl = 0.0,
                        notes = "Manual order on ${position.brokerType} [Ticket #${position.ticketId}]"
                    )
                    repository.insertJournalTrade(trade)
                }
            }
        }
    }

    fun closeBrokerPosition(ticketId: String) {
        brokerConnectionManager.closePosition(ticketId) { success, pnl ->
            val pnlFormatted = if (pnl >= 0) "+$${String.format(java.util.Locale.US, "%.2f", pnl)}" else "-$${String.format(java.util.Locale.US, "%.2f", Math.abs(pnl))}"
            _brokerFeedbackMessage.value = if (success) "Position #$ticketId closed. P&L: $pnlFormatted" else "Position close failed."
            if (success) {
                viewModelScope.launch {
                    val openTrades = allJournalTrades.value
                    val matching = openTrades.find { it.notes.contains(ticketId) && it.status == "OPEN" }
                    if (matching != null) {
                        val closedStatus = if (pnl >= 0) "CLOSED_WIN" else "CLOSED_LOSS"
                        val updated = matching.copy(
                            status = closedStatus,
                            pnl = pnl,
                            notes = matching.notes + " | Closed: $pnlFormatted"
                        )
                        repository.updateJournalTrade(updated)
                    }
                }
            }
        }
    }

    fun closeAllBrokerPositions() {
        brokerConnectionManager.closeAllPositions { count, totalPnL ->
            _brokerFeedbackMessage.value = if (count == 0) {
                "No verified broker adapter is connected. No positions were closed and no P&L was calculated."
            } else {
                val pnlFormatted = if (totalPnL >= 0) "+$${String.format(java.util.Locale.US, "%.2f", totalPnL)}" else "-$${String.format(java.util.Locale.US, "%.2f", Math.abs(totalPnL))}"
                "Closed $count broker-confirmed positions. Reported P&L: $pnlFormatted"
            }
        }
    }

    // --- REAL TRADING ASSISTANT & EVIDENCE-BASED SIGNAL ENGINE ---

    fun runAiMarketAnalysis(symbol: String? = null, userNotes: String? = null) {
        val targetSymbol = symbol ?: _selectedMarketAsset.value.symbol
        val asset = MarketUniverse.findAssetBySymbol(targetSymbol)
        val quote = marketDataEngine.getQuoteForSymbol(asset.symbol)

        if (quote.isStale || quote.lastPrice <= 0.0 || quote.lastUpdatedTimestamp <= 0L || (System.currentTimeMillis() - quote.lastUpdatedTimestamp) > 300_000L) {
            _aiAssistantStatusText.value = "Market data stale or offline for ${asset.symbol}. Analysis blocked."
            _brokerFeedbackMessage.value = "Signal generation blocked: ${asset.symbol} quote is stale or offline."
            val waitSignal = TradingSignalEntity(
                timestamp = System.currentTimeMillis(),
                symbol = asset.symbol,
                timeframe = "15m",
                action = "WAIT",
                confidenceScore = 0,
                reasoning = "Market data for ${asset.symbol} is stale or offline. Actionable signals and orders are strictly blocked.",
                entryZone = "N/A",
                stopLoss = "N/A",
                takeProfit = "N/A",
                riskRewardRatio = "0:0",
                trendDirection = "NEUTRAL",
                detectedPatterns = "DATA STALE / OFFLINE",
                keyLevels = "Unavailable",
                source = "AI_EVIDENCE_ANALYSIS"
            )
            _latestEvidenceSignal.value = waitSignal
            return
        }

        viewModelScope.launch {
            _isAiAssistantRunning.value = true
            _aiAssistantStatusText.value = "Auditing live ${asset.symbol} telemetry with Gemini AI..."
            try {
                val broker = activeBrokerAccount.value
                val brokerCtx = broker?.let { "${it.brokerType} (${it.environment}) | Default Lot: ${it.defaultLotSize}" }
                val signal = repository.analyzeMarketQuoteAndSaveSignal(
                    quote = quote,
                    userInstructions = userNotes,
                    preferredModel = _preferredModel.value,
                    brokerContext = brokerCtx
                )
                _latestEvidenceSignal.value = signal
                _aiAssistantStatusText.value = "Signal Generated: ${signal.action} (Evidence Score ${signal.confidenceScore}/100)"

                // Add to Assistant Chat history
                val chatSummary = buildString {
                    append("🎯 **${signal.action} ${signal.symbol}** (Evidence Score ${signal.confidenceScore}/100)\n\n")
                    append("• **Entry:** ${signal.entryZone} | **SL:** ${signal.stopLoss} | **TP:** ${signal.takeProfit} (R:R ${signal.riskRewardRatio})\n")
                    append("• **Key Patterns:** ${signal.detectedPatterns}\n")
                    append("• **Confluence Proof:** ${signal.reasoning}\n\n")
                    if (broker != null && broker.isConnected && brokerConnectionManager.connectionStatus.value in listOf("CONNECTED_LIVE", "CONNECTED_DEMO")) {
                        append("⚡ **Ready to execute on ${broker.brokerType}**.")
                    } else {
                        append("ℹ️ Broker execution is disabled until a verified broker-specific adapter is implemented and tested.")
                    }
                }
                val updatedChat = _assistantChatMessages.value.toMutableList().apply {
                    add(
                        AssistantChatMessage(
                            isUser = false,
                            text = chatSummary,
                            associatedSymbol = signal.symbol,
                            signalAction = signal.action,
                            confidence = signal.confidenceScore
                        )
                    )
                }
                _assistantChatMessages.value = updatedChat

                // Check auto-trade
                if (broker != null && broker.autoTradeEnabled && broker.isConnected && brokerConnectionManager.connectionStatus.value in listOf("CONNECTED_LIVE", "CONNECTED_DEMO")) {
                    val isMarketAllowed = when (_autoTradeMarketUniverse.value) {
                        MarketCategory.ALL_MARKETS -> true
                        MarketCategory.FOREX -> asset.category == MarketCategory.FOREX
                        MarketCategory.GOLD -> asset.category == MarketCategory.GOLD
                        MarketCategory.CRYPTO -> asset.category == MarketCategory.CRYPTO
                        MarketCategory.STOCKS -> asset.category == MarketCategory.STOCKS
                    }
                    if (isMarketAllowed && signal.action != "WAIT" && signal.confidenceScore >= broker.minConfidenceThreshold) {
                        executeSignalOnBroker(signal)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                _aiAssistantStatusText.value = "Analysis failed: ${e.message}"
            } finally {
                _isAiAssistantRunning.value = false
            }
        }
    }

    fun sendAssistantChatMessage(userMessage: String) {
        if (userMessage.isBlank()) return
        val currentQuote = currentMarketQuote.value
        val history = _assistantChatMessages.value

        val updated = history.toMutableList().apply {
            add(AssistantChatMessage(isUser = true, text = userMessage.trim()))
        }
        _assistantChatMessages.value = updated

        viewModelScope.launch {
            _isAiAssistantRunning.value = true
            _aiAssistantStatusText.value = "Consulting Gemini AI Trading Assistant..."
            try {
                val responseText = repository.chatWithAssistant(
                    quote = currentQuote,
                    history = updated,
                    userMessage = userMessage,
                    preferredModel = _preferredModel.value
                )
                val withAssistantReply = _assistantChatMessages.value.toMutableList().apply {
                    add(AssistantChatMessage(isUser = false, text = responseText))
                }
                _assistantChatMessages.value = withAssistantReply
                _aiAssistantStatusText.value = "Ready"
            } catch (e: Exception) {
                e.printStackTrace()
                val errorList = _assistantChatMessages.value.toMutableList().apply {
                    add(AssistantChatMessage(isUser = false, text = "Assistant connection issue: ${e.message}"))
                }
                _assistantChatMessages.value = errorList
            } finally {
                _isAiAssistantRunning.value = false
            }
        }
    }

    fun executeEvidenceSignalOnActiveBroker(overrideVolume: Double? = null) {
        val signal = _latestEvidenceSignal.value
        if (signal != null) {
            executeSignalOnBroker(signal, overrideVolume)
        } else {
            _brokerFeedbackMessage.value = "No active evidence signal to execute. Generate one first!"
        }
    }

    fun clearAssistantChat() {
        _assistantChatMessages.value = listOf(
            AssistantChatMessage(
                isUser = false,
                text = "Chat history cleared. Live market telemetry will be used only when a verified quote is available. Ask a question or request analysis; unavailable data will be reported explicitly."
            )
        )
    }

    private fun parseValidPriceOrNull(raw: String): Double? {
        return try {
            val trimmed = raw.trim()
            if (trimmed.startsWith("-")) return null
            val token = Regex("\\d[\\d,]*(?:\\.\\d+)?").find(trimmed)?.value ?: return null
            val parsed = token.replace(",", "").toDoubleOrNull()
            if (parsed != null && parsed > 0.0 && !parsed.isNaN() && !parsed.isInfinite()) parsed else null
        } catch (_: Exception) {
            null
        }
    }

    fun runQuantitativeEvaluation() {
        viewModelScope.launch {
            _evaluationStatusText.value = "Evaluating broker-confirmed trade outcomes; no synthetic backtest or assumed fees are used..."
            val completed = continuousLearningDao.getChronologicalCompletedOutcomes()
            val report = evaluationEngine.evaluateChronologicalOutcomes(completed)
            _evaluationReport.value = report

            if (!report.isSampleSufficiencyMet) {
                _evaluationStatusText.value = "Evaluation completed: Sample size (${report.sampleSize}/${QuantitativeEvaluationEngine.MINIMUM_SAMPLE_SIZE}) is insufficient for statistical confidence. Gathering more observations."
            } else {
                _evaluationStatusText.value = "Evaluation complete: Out-of-sample Win Rate: ${String.format(java.util.Locale.US, "%.1f", report.winRateOutOfSample)}%, Expectancy: $${String.format(java.util.Locale.US, "%.2f", report.expectancyOutOfSample)}/trade, Max Drawdown: ${if (report.maxDrawdownPctOutOfSample.isFinite()) String.format(java.util.Locale.US, "%.1f", report.maxDrawdownPctOutOfSample) + "%" else "N/A (verified starting equity unavailable)"}."
                // Candidate performance is not estimated. A strategy proposal is not created
                // until a candidate has been evaluated on a separate verified outcome set.
            }
        }
    }

    fun applyRemoteConfig(payload: RemoteConfigPayload) {
        val result = remoteConfigManager.validateAndApply(payload)
        when (result) {
            is ConfigValidationResult.Success -> {
                _activeRemoteConfig.value = result.appliedConfig
                _evaluationStatusText.value = result.message
            }
            is ConfigValidationResult.Rejected -> {
                _evaluationStatusText.value = "Remote config rejected: ${result.reason}"
            }
        }
    }

    fun rollbackToKnownGoodConfig() {
        val reverted = remoteConfigManager.rollbackToKnownGood()
        _activeRemoteConfig.value = reverted
        _evaluationStatusText.value = "1-Tap Rollback executed: Reverted to config v${reverted.version} (${reverted.strategyVersion})."
    }

    fun resetConfigToFactoryDefaults() {
        val factory = remoteConfigManager.resetToFactoryDefaults()
        _activeRemoteConfig.value = factory
        _evaluationStatusText.value = "Factory defaults restored: v${factory.version}."
    }

    fun approveProposal(proposal: ImprovementProposalEntity) {
        viewModelScope.launch {
            val updated = proposal.copy(
                status = ProposalStatus.APPROVED.name,
                appliedTimestamp = System.currentTimeMillis()
            )
            continuousLearningDao.updateProposal(updated)
            // Apply the proposed parameters to active config safely
            val current = _activeRemoteConfig.value
            val candidatePayload = current.copy(
                version = current.version + 1,
                timestamp = System.currentTimeMillis(),
                minConfidenceThreshold = proposal.minConfidenceThreshold,
                strategyVersion = proposal.candidateStrategyVersion
            )
            applyRemoteConfig(candidatePayload)
            _evaluationStatusText.value = "Proposal '${proposal.proposalTitle}' APPROVED and applied."
        }
    }

    fun rejectProposal(proposal: ImprovementProposalEntity, reason: String = "Rejected by user") {
        viewModelScope.launch {
            val updated = proposal.copy(
                status = ProposalStatus.REJECTED.name,
                approvalNotes = reason
            )
            continuousLearningDao.updateProposal(updated)
            _evaluationStatusText.value = "Proposal rejected: $reason"
        }
    }

    fun purgeOldTelemetry(days: Int = 90) {
        viewModelScope.launch {
            val cutoff = System.currentTimeMillis() - (days.toLong() * 24L * 60L * 60L * 1000L)
            val count = continuousLearningDao.purgeOutcomesOlderThan(cutoff)
            _evaluationStatusText.value = "Purged $count telemetry records older than $days days."
        }
    }

    fun checkForAppUpdates() {
        _updateCheckStatusText.value = "Update check unavailable: no live release-registry fetch is configured. The installed version has not been verified as current."
    }

    fun recordSignalPerformanceOutcome(
        symbol: String,
        action: String,
        confidence: Int,
        entryPrice: Double,
        stopLoss: Double,
        takeProfit: Double,
        outcomeStatus: String,
        exitPrice: Double?,
        source: ObservationSource = ObservationSource.CONFIRMED_BROKER
    ) {
        _evaluationStatusText.value = "Performance outcome not recorded: this build does not yet ingest broker-confirmed fills, actual position size, realized P&L, and actual fees. No estimated costs or synthetic performance were stored."
    }
}

