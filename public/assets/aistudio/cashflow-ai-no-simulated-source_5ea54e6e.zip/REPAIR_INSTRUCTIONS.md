# CashFlow AI — Current Repair and Safety Status

## Current scope

This source package is a Kotlin/Android Jetpack Compose project. The changes in this version focus on removing fabricated trading data and ensuring unavailable integrations fail closed. The project has **not** been verified as a production automated-trading system.

## Simulation-removal changes

- Removed startup seeding of sample signals, sample finance transactions, demo broker accounts, and fake balances.
- Added narrowly targeted cleanup for known seeded sample signals, transactions, accounts, and automatically generated proposals from older versions. Existing user journal entries and ambiguous budgets are not deleted.
- Removed generated candlestick images from the screen-capture and camera-analysis paths. Screen analysis requires a real Android MediaProjection frame; the camera screen currently shows a preview but explicitly reports that real camera-frame capture is not implemented.
- Removed the synthetic close-only signal generator. It now returns `WAIT` until genuine OHLC candles and volatility-based trade levels are available through the signal pipeline.
- Hardened Gemini response parsing: missing or malformed required fields do not become default BUY signals, invented prices, patterns, or confidence values.
- Removed arbitrary chart support/resistance/target overlays and hardcoded pattern win rates, sample counts, profit factor, risk/reward, drawdown, and trade-duration claims.
- Removed fake broker positions, random P&L movement, invented ping times, generated order tickets, and simulated successful broker connections.
- Broker connect, order, close, and ping actions fail closed because no verified broker-specific adapter is implemented. Auto-trading cannot be armed.
- Quantitative evaluation uses broker-confirmed outcomes only. It does not invent a starting balance, fee assumptions, out-of-sample uplift, or candidate-strategy results.
- Update-check status now says unverified unless a real release-registry integration is added.

## Important capability limitations

1. **Broker execution is unavailable.** The app does not currently implement a verified Deriv, MT5, OANDA, or IBKR connection adapter. Entering credentials will not connect or place orders.
2. **Camera frame analysis is unavailable.** Camera preview is real, but capturing and passing an actual CameraX frame to the analyzer remains to be implemented. The app no longer substitutes a generated chart.
3. **Close-only signal generation is intentionally disabled.** It must be wired to genuine OHLC and ATR data before it can produce actionable BUY/SELL levels.
4. **Indicative bid/ask values are not executable quotes.** Execution checks reject quotes whose bid/ask values are estimated.
5. AI analysis can still make mistakes even when the API response passes structural validation. Treat it as advisory, not as a guarantee of returns.

## Configuration and build verification

- `.env.example` contains placeholder variable names only. Do not upload a real `.env`, API key, signing key, or credential file to a public repository.
- `app/google-services.json` is not included in this package. Configure Firebase only if the selected build variant requires it.
- The Gradle wrapper is configured for Gradle 9.3.1. A unit-test/build attempt in the current environment could not run because `services.gradle.org` was unreachable (`UnknownHostException`). **This ZIP is not build-verified.** Build and run tests in Android Studio or a connected build environment before installing it.

## Recommended next steps

1. Import this source project into Android Studio or the intended AI Studio workspace.
2. Run `./gradlew testDebugUnitTest` and `./gradlew assembleDebug` in an environment that can download the Gradle distribution and dependencies.
3. Resolve any compile/test failures before building an APK.
4. Implement and test a broker-specific adapter against an official demo environment before enabling any real-money execution. Keep live execution disabled until order acknowledgement, fills, fees, margin, position reconciliation, disconnect handling, and risk limits are verified.
